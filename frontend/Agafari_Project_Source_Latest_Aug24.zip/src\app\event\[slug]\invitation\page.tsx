'use client';

import { useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

export default function RedirectInvitationPage({ params }: { params: { slug: string } }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const codeParam = searchParams.get('code');

  useEffect(() => {
    // The invitation page has been merged into the master wedding celebration hub
    const targetUrl = codeParam 
      ? `/event/${params.slug}?code=${codeParam}` 
      : `/event/${params.slug}`;
    router.replace(targetUrl);
  }, [params.slug, codeParam, router]);

  return (
    <div className="min-h-screen bg-neutral flex items-center justify-center">
      <div className="text-center">
        <div className="w-10 h-10 border-4 border-metallic border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="font-serif text-sage-dark text-sm">Opening Unified Wedding Celebration Hub...</p>
      </div>
    </div>
  );
}
