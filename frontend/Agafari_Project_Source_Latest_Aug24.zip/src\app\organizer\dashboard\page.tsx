'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Briefcase, 
  Calendar, 
  Users, 
  Video, 
  QrCode, 
  CheckCircle2, 
  XCircle, 
  ExternalLink, 
  KeyRound, 
  Film, 
  ShieldCheck, 
  LogOut, 
  Sparkles, 
  ChevronRight, 
  Clock, 
  Archive, 
  Search, 
  Plus, 
  Copy, 
  Check, 
  MapPin, 
  Crown, 
  ScanLine, 
  Share2, 
  Lock, 
  Radio, 
  Send, 
  Eye, 
  EyeOff, 
  AlertCircle,
  Menu,
  X,
  Layers,
  Upload
} from 'lucide-react';
import { useTranslation, LanguageSwitcher } from '@/lib/i18n';

interface EventCredential {
  fullName: string;
  email: string;
  temporaryPassword?: string;
  role: string;
}

interface EventData {
  id: string;
  slug: string;
  title: string;
  brideName: string;
  groomName: string;
  eventDate: string;
  startTime?: string;
  venueName: string;
  venueAddress: string;
  dressCode?: string;
  coverImageUrl?: string;
  status: 'DRAFT' | 'COMING_SOON' | 'LIVE' | 'COMPLETED' | 'ARCHIVED';
  adminApprovalStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  coupleCredentials?: {
    email: string;
    temporaryPassword?: string;
  };
  credentials?: {
    couple: EventCredential;
    organizer: EventCredential;
    streamer: EventCredential;
    scanner: EventCredential;
  };
  stats?: {
    totalInvites: number;
    totalWishes: number;
    totalMedia: number;
  };
}

interface MediaAssetData {
  id: string;
  eventId: string;
  uploaderName: string;
  mediaType: 'VIDEO' | 'IMAGE';
  cdnUrl: string;
  caption: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

export default function OrganizerDashboardPage() {
  const { t } = useTranslation();
  // Navigation: 'WEDDINGS' (Pillar 2) | 'CREDENTIALS' (Pillar 1) | 'MEDIA'
  const [activeTab, setActiveTab] = useState<'WEDDINGS' | 'CREDENTIALS' | 'MEDIA'>('WEDDINGS');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const [events, setEvents] = useState<EventData[]>([]);
  const [mediaAssets, setMediaAssets] = useState<MediaAssetData[]>([]);
  const [loading, setLoading] = useState(true);

  // Selected Wedding for Deep Inspection (Pillar 2)
  const [selectedEvent, setSelectedEvent] = useState<EventData | null>(null);

  // Wedding Fleet Directory Filters
  const [fleetFilter, setFleetFilter] = useState<'ALL' | 'ACTIVE' | 'ARCHIVE' | 'PENDING'>('ALL');
  const [searchFleetQuery, setSearchFleetQuery] = useState('');

  // Pillar 1: Request Admin Approval & Provision Couple Credentials Form State
  const [brideName, setBrideName] = useState('');
  const [groomName, setGroomName] = useState('');
  const [coupleEmail, setCoupleEmail] = useState('');
  const [eventDate, setEventDate] = useState('2026-10-15');
  const [venueName, setVenueName] = useState('');
  const [requestingApproval, setRequestingApproval] = useState(false);
  const [provisionSuccessMsg, setProvisionSuccessMsg] = useState('');
  const [newlyProvisionedCreds, setNewlyProvisionedCreds] = useState<{ email: string; pass: string; slug: string } | null>(null);

  // Password Visibility State & Copied feedback
  const [copiedKey, setCopiedKey] = useState<string>('');
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});

  useEffect(() => {
    async function loadOrganizerData() {
      try {
        const [eventsRes, mediaRes] = await Promise.all([
          fetch('/api/organizer/events'),
          fetch('/api/organizer/media'),
        ]);

        if (eventsRes.ok) {
          const eventsData = await eventsRes.json();
          const loadedEvents: EventData[] = eventsData.events || [];
          setEvents(loadedEvents);
          if (loadedEvents.length > 0) {
            setSelectedEvent(loadedEvents[0]);
          }
        }

        if (mediaRes.ok) {
          const mediaData = await mediaRes.json();
          setMediaAssets(mediaData.mediaAssets || []);
        }
      } catch (err) {
        console.error('Failed to load organizer data:', err);
      } finally {
        setLoading(false);
      }
    }

    loadOrganizerData();
  }, []);

  // Pillar 1 Handler: Request Admin Approval & Provision Couple Credentials
  const handleRequestCoupleCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brideName.trim() || !groomName.trim() || !coupleEmail.trim() || !venueName.trim()) return;

    setRequestingApproval(true);
    try {
      const res = await fetch('/api/organizer/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          brideName,
          groomName,
          coupleEmail,
          eventDate,
          venueName,
        }),
      });

      const data = await res.json();
      if (res.ok && data.event) {
        setEvents((prev) => [data.event, ...prev]);
        setSelectedEvent(data.event);
        setNewlyProvisionedCreds({
          email: data.event.coupleCredentials?.email || coupleEmail,
          pass: data.event.coupleCredentials?.temporaryPassword || 'couple123',
          slug: data.event.slug,
        });
        setProvisionSuccessMsg(
          `Wedding "${data.event.title}" registered! Couple credentials generated & admin verification request dispatched.`
        );
        setBrideName('');
        setGroomName('');
        setCoupleEmail('');
        setVenueName('');
      }
    } catch (err) {
      console.error('Failed to provision couple credentials:', err);
    } finally {
      setRequestingApproval(false);
    }
  };

  // Admin Approval Simulator (Toggle between PENDING & APPROVED)
  const handleToggleAdminApproval = async (eventId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'APPROVED' ? 'PENDING' : 'APPROVED';
    try {
      const res = await fetch('/api/organizer/events', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId, adminApprovalStatus: nextStatus }),
      });

      if (res.ok) {
        setEvents((prev) =>
          prev.map((e) => (e.id === eventId ? { ...e, adminApprovalStatus: nextStatus } : e))
        );
        if (selectedEvent && selectedEvent.id === eventId) {
          setSelectedEvent((prev) => prev ? { ...prev, adminApprovalStatus: nextStatus } : null);
        }
      }
    } catch (err) {
      console.error('Failed to toggle approval:', err);
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(''), 3000);
  };

  const toggleShowPassword = (key: string) => {
    setShowPasswords((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Metrics Calculations
  const activeHostingEvents = events.filter((e) => e.status !== 'COMPLETED' && e.status !== 'ARCHIVED');
  const hostedArchiveEvents = events.filter((e) => e.status === 'COMPLETED' || e.status === 'ARCHIVED');
  const pendingAdminEvents = events.filter((e) => e.adminApprovalStatus === 'PENDING');

  // Filtered Events according to Fleet filter
  const filteredEvents = events.filter((evt) => {
    const matchesSearch = evt.title.toLowerCase().includes(searchFleetQuery.toLowerCase()) ||
                          evt.venueName.toLowerCase().includes(searchFleetQuery.toLowerCase()) ||
                          evt.brideName.toLowerCase().includes(searchFleetQuery.toLowerCase()) ||
                          evt.groomName.toLowerCase().includes(searchFleetQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (fleetFilter === 'ALL') return true;
    if (fleetFilter === 'ACTIVE') return evt.status !== 'COMPLETED' && evt.status !== 'ARCHIVED';
    if (fleetFilter === 'ARCHIVE') return evt.status === 'COMPLETED' || evt.status === 'ARCHIVED';
    if (fleetFilter === 'PENDING') return evt.adminApprovalStatus === 'PENDING';
    return true;
  });

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white text-gray-900 flex font-sans selection:bg-gold-500 selection:text-black">
      
      {/* =========================================================================
          1. ORGANIZER STRUCTURED EXECUTIVE SIDEBAR
         ========================================================================= */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-72 bg-gray-950 text-white flex flex-col justify-between border-r border-gold-500/30 transition-transform duration-300 ease-in-out
        md:translate-x-0 ${mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div>
          {/* Brand Header */}
          <div className="p-6 border-b border-gold-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src="/branding/artboard-13.png"
                  alt="Agafari (አጋፋሪ) Logo"
                  className="h-10 w-auto object-contain"
                />
                <div>
                  <h2 className="font-serif font-bold text-base text-gold-400 tracking-wide">
                    {t('organizerDashboard.brand')}
                  </h2>
                  <span className="text-[10px] text-gold-500/80 font-semibold uppercase tracking-widest block">
                    {t('organizerDashboard.subtitle')}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setMobileSidebarOpen(false)}
                className="md:hidden p-1 text-white/70 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="mt-4 grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2.5 rounded-xl bg-black/20 border border-white/5">
                <div className="text-emerald-400 font-bold text-base">{activeHostingEvents.length}</div>
                <div className="text-white/70 text-[10px]">{t('organizerDashboard.kpiHosting')}</div>
              </div>
              <div className="p-2.5 rounded-xl bg-black/20 border border-white/5">
                <div className="text-[#D4AF37] font-bold text-base">{hostedArchiveEvents.length}</div>
                <div className="text-white/70 text-[10px]">{t('organizerDashboard.kpiArchive')}</div>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="p-4 space-y-1.5 text-xs font-semibold">
            
            {/* Pillar 2: Hosted & Active Weddings */}
            <button
              onClick={() => { setActiveTab('WEDDINGS'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'WEDDINGS'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Layers className="w-4 h-4 text-gold-400" />
                <span>{t('organizerDashboard.tabs.weddings')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {events.length}
              </span>
            </button>

            {/* Pillar 1: Couple Credentials Provisioning */}
            <button
              onClick={() => { setActiveTab('CREDENTIALS'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'CREDENTIALS'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <KeyRound className="w-4 h-4 text-gold-400" />
                <span>{t('organizerDashboard.tabs.credentials')}</span>
              </div>
              {pendingAdminEvents.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-400 text-amber-950 font-bold">
                  {pendingAdminEvents.length}
                </span>
              )}
            </button>

            {/* Pillar 3: Media Vault Moderation */}
            <button
              onClick={() => { setActiveTab('MEDIA'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'MEDIA'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Film className="w-4 h-4 text-gold-400" />
                <span>{t('organizerDashboard.tabs.media')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {mediaAssets.length}
              </span>
            </button>
          </nav>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 space-y-2">
          <Link
            href="/organizer/login"
            className="w-full py-2.5 px-3 rounded-xl hover:bg-rose-950/40 text-rose-300 text-xs font-medium flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>{t('nav.signOut')}</span>
          </Link>
        </div>
      </aside>

      {/* Mobile Drawer Backdrop */}
      {mobileSidebarOpen && (
        <div
          onClick={() => setMobileSidebarOpen(false)}
          className="md:hidden fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
        />
      )}

      {/* =========================================================================
          2. MAIN WORKSPACE
         ========================================================================= */}
      <div className="flex-1 md:pl-72 flex flex-col min-w-0">
        
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-gold-500/30 px-6 py-4 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="md:hidden p-2 rounded-xl bg-gray-50 border border-gold-500/30 text-gray-900"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              <div className="text-[11px] text-gold-600 font-semibold uppercase tracking-wider">
                {t('organizerDashboard.header.tag')}
              </div>
              <h1 className="font-serif font-bold text-lg sm:text-xl text-gray-900">
                {activeTab === 'WEDDINGS' && t('organizerDashboard.header.title')}
                {activeTab === 'CREDENTIALS' && t('organizerDashboard.credentials.title')}
                {activeTab === 'MEDIA' && t('coupleDashboard.media.title')}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 ml-auto">
            <button
              onClick={() => setActiveTab('CREDENTIALS')}
              className="px-4 py-2 rounded-xl bg-black hover:bg-gray-800 text-gold-400 text-xs font-bold shadow-md transition-all flex items-center gap-1.5 border border-gold-500/40"
            >
              <Plus className="w-3.5 h-3.5 text-gold-400" />
              <span className="hidden sm:inline">{t('organizerDashboard.header.requestBtn')}</span>
            </button>

            <LanguageSwitcher />
          </div>
        </header>

        {/* Workspace Body */}
        <main className="p-6 max-w-7xl w-full mx-auto space-y-6">
          
          {/* =========================================================================
              PILLAR 2: HOSTED & ACTIVE WEDDINGS DIRECTORY & 1-CLICK ROLE LAUNCH
             ========================================================================= */}
          {activeTab === 'WEDDINGS' && (
            <div className="space-y-6">
              
              {/* Filter Pills & Search */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-gold-500/30 shadow-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setFleetFilter('ALL')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      fleetFilter === 'ALL'
                        ? 'bg-black text-gold-400 shadow-sm'
                        : 'bg-gray-50 text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    {t('organizerDashboard.fleet.all')} ({events.length})
                  </button>

                  <button
                    onClick={() => setFleetFilter('ACTIVE')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      fleetFilter === 'ACTIVE'
                        ? 'bg-emerald-800 text-white shadow-sm'
                        : 'bg-gray-50 text-emerald-900 hover:bg-emerald-50'
                    }`}
                  >
                    {t('organizerDashboard.fleet.active')} ({activeHostingEvents.length})
                  </button>

                  <button
                    onClick={() => setFleetFilter('ARCHIVE')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      fleetFilter === 'ARCHIVE'
                        ? 'bg-blue-800 text-white shadow-sm'
                        : 'bg-gray-50 text-blue-900 hover:bg-blue-50'
                    }`}
                  >
                    {t('organizerDashboard.fleet.archive')} ({hostedArchiveEvents.length})
                  </button>

                  <button
                    onClick={() => setFleetFilter('PENDING')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      fleetFilter === 'PENDING'
                        ? 'bg-amber-800 text-white shadow-sm'
                        : 'bg-gray-50 text-amber-900 hover:bg-amber-50'
                    }`}
                  >
                    {t('organizerDashboard.fleet.pending')} ({pendingAdminEvents.length})
                  </button>
                </div>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-gold-600 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchFleetQuery}
                    onChange={(e) => setSearchFleetQuery(e.target.value)}
                    placeholder={t('organizerDashboard.fleet.searchPlaceholder')}
                    className="pl-8 pr-4 py-1.5 rounded-xl border border-gold-500/30 text-xs text-gray-900 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gold-500"
                  />
                </div>
              </div>

              {/* Event Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredEvents.map((evt) => {
                  const isSelected = selectedEvent?.id === evt.id;
                  const isArchive = evt.status === 'COMPLETED' || evt.status === 'ARCHIVED';

                  return (
                    <div
                      key={evt.id}
                      onClick={() => setSelectedEvent(evt)}
                      className={`
                        rounded-3xl p-5 border cursor-pointer transition-all flex flex-col justify-between relative overflow-hidden bg-white
                        ${isSelected ? 'border-gold-500 ring-2 ring-gold-500/50 shadow-lg' : 'border-gold-500/30 hover:border-gold-500 shadow-sm'}
                      `}
                    >
                      <div>
                        {/* Status Badges */}
                        <div className="flex items-center justify-between mb-3">
                          {evt.adminApprovalStatus === 'PENDING' ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                              🟡 Pending Admin
                            </span>
                          ) : isArchive ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-800 text-[10px] font-bold">
                              📜 Hosted Archive
                            </span>
                          ) : evt.status === 'LIVE' ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-900 text-[10px] font-bold animate-pulse">
                              🔴 LIVE NOW
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                              🟢 Active Hosting
                            </span>
                          )}

                          <span className="text-[10px] font-mono text-gold-700 font-bold">
                            {new Date(evt.eventDate).toLocaleDateString()}
                          </span>
                        </div>

                        {/* Image / Header */}
                        <div className="h-32 rounded-2xl overflow-hidden mb-3 relative bg-black/10">
                          {evt.coverImageUrl ? (
                            <img
                              src={evt.coverImageUrl}
                              alt={evt.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-black text-gold-400 font-serif font-bold">
                              {evt.brideName} & {evt.groomName}
                            </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3 text-white">
                            <div>
                              <div className="font-serif font-bold text-sm">{evt.brideName} & {evt.groomName}</div>
                              <div className="text-[10px] text-gold-400 flex items-center gap-1">
                                <MapPin className="w-3 h-3" /> {evt.venueName}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Summary Stats */}
                        <div className="grid grid-cols-3 gap-2 text-center text-[10px] bg-gray-50 p-2 rounded-xl mb-3 border border-gold-500/20">
                          <div>
                            <div className="font-bold text-gray-900">{evt.stats?.totalInvites || 120}</div>
                            <div className="text-gray-500">Invited</div>
                          </div>
                          <div>
                            <div className="font-bold text-emerald-800">{evt.stats?.totalWishes || 24}</div>
                            <div className="text-gray-500">Wishes</div>
                          </div>
                          <div>
                            <div className="font-bold text-gold-600">{evt.stats?.totalMedia || 15}</div>
                            <div className="text-gray-500">Reels</div>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-gray-100 flex items-center justify-between text-xs font-bold">
                        <span className="text-gray-900">
                          {isSelected ? '✓ Selected in Command Room' : 'Click to View Credentials'}
                        </span>
                        <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'rotate-90 text-gold-500' : 'text-gray-400'}`} />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* =========================================================================
                  DRILL-DOWN COMMAND ROOM FOR SELECTED WEDDING
                 ========================================================================= */}
              {selectedEvent && (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-6 sm:p-8 rounded-3xl bg-white border-2 border-gold-500 shadow-xl space-y-6"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gold-500/20">
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black text-gold-400 text-xs font-bold mb-2">
                        <Sparkles className="w-3.5 h-3.5 text-gold-400" />
                        {t('organizerDashboard.fleet.selectedRoom')}
                      </div>
                      <h2 className="font-serif font-bold text-2xl text-gray-900">
                        {selectedEvent.title}
                      </h2>
                      <div className="text-xs text-gray-600 flex flex-wrap items-center gap-3 mt-1">
                        <span>Date: <strong>{new Date(selectedEvent.eventDate).toLocaleDateString()}</strong></span>
                        <span>•</span>
                        <span>Venue: <strong>{selectedEvent.venueName}</strong></span>
                        <span>•</span>
                        <span>Slug: <strong>/event/{selectedEvent.slug}</strong></span>
                      </div>
                    </div>

                    {/* Admin Approval Toggle Simulation */}
                    <div className="flex items-center gap-3">
                      <div className="text-right text-xs">
                        <div className="text-gray-500 text-[10px] uppercase font-bold">{t('organizerDashboard.fleet.adminStatus')}</div>
                        {selectedEvent.adminApprovalStatus === 'APPROVED' ? (
                          <span className="text-emerald-800 font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Approved & Licensed
                          </span>
                        ) : (
                          <span className="text-amber-800 font-bold flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-amber-600" /> Awaiting Verification
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => handleToggleAdminApproval(selectedEvent.id, selectedEvent.adminApprovalStatus)}
                        className="px-3 py-1.5 rounded-xl border border-gold-500/30 bg-gray-50 hover:bg-gray-100 text-[11px] font-bold text-gray-900"
                      >
                        {selectedEvent.adminApprovalStatus === 'APPROVED' ? 'Simulate Revoke' : 'Simulate Admin Approve'}
                      </button>
                    </div>
                  </div>

                  {/* 3 Dedicated Role Launch Cards */}
                  <div>
                    <h3 className="font-serif font-bold text-base text-gray-900 mb-2 flex items-center gap-2">
                      <KeyRound className="w-4 h-4 text-gold-500" />
                      {t('organizerDashboard.fleet.roleCredentialsTitle')}
                    </h3>
                    <p className="text-xs text-gray-600 mb-4">
                      {t('organizerDashboard.fleet.roleCredentialsSubtitle')}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                      
                      {/* 1. Couple Dashboard Card */}
                      <div className="p-5 rounded-2xl border border-gold-500/30 bg-gray-50 flex flex-col justify-between space-y-4">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="w-9 h-9 rounded-xl bg-black text-gold-400 flex items-center justify-center font-bold shadow-sm">
                              <Crown className="w-5 h-5" />
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-950">
                              👑 Primary Role
                            </span>
                          </div>

                          <h4 className="font-serif font-bold text-sm text-gray-900">
                            {t('organizerDashboard.fleet.coupleRole')} ({selectedEvent.brideName} & {selectedEvent.groomName})
                          </h4>
                          <p className="text-[11px] text-gray-600 mt-1">
                            {t('organizerDashboard.fleet.coupleDesc')}
                          </p>

                          <div className="mt-3 p-3 rounded-xl bg-white border border-gold-500/20 text-xs space-y-1">
                            <div className="flex justify-between">
                              <span className="text-gray-500 text-[10px]">Login:</span>
                              <span className="font-mono font-bold text-gray-900">
                                {selectedEvent.credentials?.couple.email || selectedEvent.coupleCredentials?.email || `couple@${selectedEvent.slug}.com`}
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-500 text-[10px]">Password:</span>
                              <span className="font-mono text-gray-900 font-bold">
                                {showPasswords['couple'] ? (selectedEvent.credentials?.couple.temporaryPassword || selectedEvent.coupleCredentials?.temporaryPassword || 'couple123') : '••••••••'}
                              </span>
                              <button onClick={() => toggleShowPassword('couple')} className="text-gold-600 hover:text-gray-900">
                                {showPasswords['couple'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Link
                            href="/couple/dashboard"
                            className="w-full py-2.5 px-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all border border-gold-500/40"
                          >
                            <span>{t('organizerDashboard.fleet.launchCouple')}</span>
                            <ExternalLink className="w-3.5 h-3.5 text-gold-400" />
                          </Link>

                          <button
                            onClick={() => handleCopy(
                              `Couple Portal: ${window.location.origin}/couple/login\nEmail: ${selectedEvent.credentials?.couple.email || selectedEvent.coupleCredentials?.email}\nPassword: ${selectedEvent.credentials?.couple.temporaryPassword || selectedEvent.coupleCredentials?.temporaryPassword || 'couple123'}`,
                              'couple'
                            )}
                            className="w-full py-1.5 px-3 rounded-lg border border-gold-500/30 bg-white hover:bg-gray-50 text-gray-900 text-[11px] font-bold flex items-center justify-center gap-1"
                          >
                            {copiedKey === 'couple' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-gold-600" />}
                            <span>{copiedKey === 'couple' ? t('common.copied') : t('organizerDashboard.fleet.copyCouple')}</span>
                          </button>
                        </div>
                      </div>

                      {/* 2. Live Streamer Card */}
                      <div className="p-5 rounded-2xl border border-gold-500/30 bg-gray-50 flex flex-col justify-between space-y-4">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="w-9 h-9 rounded-xl bg-black text-gold-400 flex items-center justify-center font-bold shadow-sm">
                              <Video className="w-5 h-5" />
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-950">
                              📹 Video Crew
                            </span>
                          </div>

                          <h4 className="font-serif font-bold text-sm text-gray-900">
                            {t('organizerDashboard.fleet.streamerRole')}
                          </h4>
                          <p className="text-[11px] text-gray-600 mt-1">
                            {t('organizerDashboard.fleet.streamerDesc')}
                          </p>

                          <div className="mt-3 p-3 rounded-xl bg-white border border-gold-500/20 text-xs space-y-1">
                            <div className="flex justify-between">
                              <span className="text-gray-500 text-[10px]">Login:</span>
                              <span className="font-mono font-bold text-gray-900">
                                {selectedEvent.credentials?.streamer.email || `streamer@${selectedEvent.slug}.com`}
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-500 text-[10px]">Password:</span>
                              <span className="font-mono text-gray-900 font-bold">
                                {showPasswords['streamer'] ? (selectedEvent.credentials?.streamer.temporaryPassword || 'stream123') : '••••••••'}
                              </span>
                              <button onClick={() => toggleShowPassword('streamer')} className="text-gold-600 hover:text-gray-900">
                                {showPasswords['streamer'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Link
                            href={`/event/${selectedEvent.slug}`}
                            target="_blank"
                            className="w-full py-2.5 px-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all border border-gold-500/40"
                          >
                            <span>{t('organizerDashboard.fleet.launchStreamer')}</span>
                            <ExternalLink className="w-3.5 h-3.5 text-gold-400" />
                          </Link>

                          <button
                            onClick={() => handleCopy(
                              `Streamer Portal: ${window.location.origin}/event/${selectedEvent.slug}\nEmail: ${selectedEvent.credentials?.streamer.email}\nPassword: ${selectedEvent.credentials?.streamer.temporaryPassword || 'stream123'}`,
                              'streamer'
                            )}
                            className="w-full py-1.5 px-3 rounded-lg border border-gold-500/30 bg-white hover:bg-gray-50 text-gray-900 text-[11px] font-bold flex items-center justify-center gap-1"
                          >
                            {copiedKey === 'streamer' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-gold-600" />}
                            <span>{copiedKey === 'streamer' ? t('common.copied') : t('organizerDashboard.fleet.copyStreamer')}</span>
                          </button>
                        </div>
                      </div>

                      {/* 3. Gate Scanner Card */}
                      <div className="p-5 rounded-2xl border border-gold-500/30 bg-gray-50 flex flex-col justify-between space-y-4">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="w-9 h-9 rounded-xl bg-black text-gold-400 flex items-center justify-center font-bold shadow-sm">
                              <ScanLine className="w-5 h-5" />
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-950">
                              📱 Security Terminal
                            </span>
                          </div>

                          <h4 className="font-serif font-bold text-sm text-gray-900">
                            {t('organizerDashboard.fleet.scannerRole')}
                          </h4>
                          <p className="text-[11px] text-gray-600 mt-1">
                            {t('organizerDashboard.fleet.scannerDesc')}
                          </p>

                          <div className="mt-3 p-3 rounded-xl bg-white border border-gold-500/20 text-xs space-y-1">
                            <div className="flex justify-between">
                              <span className="text-gray-500 text-[10px]">Login:</span>
                              <span className="font-mono font-bold text-gray-900">
                                {selectedEvent.credentials?.scanner.email || `scanner@${selectedEvent.slug}.com`}
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-500 text-[10px]">Password:</span>
                              <span className="font-mono text-gray-900 font-bold">
                                {showPasswords['scanner'] ? (selectedEvent.credentials?.scanner.temporaryPassword || 'scan123') : '••••••••'}
                              </span>
                              <button onClick={() => toggleShowPassword('scanner')} className="text-gold-600 hover:text-gray-900">
                                {showPasswords['scanner'] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Link
                            href="/scanner"
                            target="_blank"
                            className="w-full py-2.5 px-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all border border-gold-500/40"
                          >
                            <span>{t('organizerDashboard.fleet.launchScanner')}</span>
                            <ExternalLink className="w-3.5 h-3.5 text-gold-400" />
                          </Link>

                          <button
                            onClick={() => handleCopy(
                              `Gate Terminal: ${window.location.origin}/scanner\nEmail: ${selectedEvent.credentials?.scanner.email}\nPassword: ${selectedEvent.credentials?.scanner.temporaryPassword || 'scan123'}`,
                              'scanner'
                            )}
                            className="w-full py-1.5 px-3 rounded-lg border border-gold-500/30 bg-white hover:bg-gray-50 text-gray-900 text-[11px] font-bold flex items-center justify-center gap-1"
                          >
                            {copiedKey === 'scanner' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-gold-600" />}
                            <span>{copiedKey === 'scanner' ? t('common.copied') : t('organizerDashboard.fleet.copyScanner')}</span>
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          )}

          {/* =========================================================================
              PILLAR 1: PROVISION COUPLE CREDENTIALS & REQUEST ADMIN APPROVAL
             ========================================================================= */}
          {activeTab === 'CREDENTIALS' && (
            <div className="space-y-6">
              
              {/* Form Card */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-gold-500/20">
                  <div>
                    <h2 className="font-serif font-bold text-lg sm:text-xl text-gray-900 flex items-center gap-2">
                      <KeyRound className="w-5 h-5 text-gold-500" />
                      {t('organizerDashboard.credentials.title')}
                    </h2>
                    <p className="text-xs text-gray-600 font-light mt-0.5">
                      {t('organizerDashboard.credentials.subtitle')}
                    </p>
                  </div>
                </div>

                {provisionSuccessMsg && (
                  <div className="mb-6 p-5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs space-y-3">
                    <div className="flex items-center gap-2 font-bold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      <span>{t('organizerDashboard.credentials.successTitle')}</span>
                    </div>
                    {newlyProvisionedCreds && (
                      <div className="p-3 bg-white rounded-xl border border-emerald-200 font-mono text-xs space-y-1">
                        <div>Bride & Groom Login: <strong>{newlyProvisionedCreds.email}</strong></div>
                        <div>Temporary Pass: <strong>{newlyProvisionedCreds.pass}</strong></div>
                        <div>Dedicated Event URL: <strong>{typeof window !== 'undefined' ? window.location.origin : ''}/event/{newlyProvisionedCreds.slug}</strong></div>
                      </div>
                    )}
                  </div>
                )}

                <form onSubmit={handleRequestCoupleCredentials} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('organizerDashboard.credentials.brideName')}
                    </label>
                    <input
                      type="text"
                      required
                      value={brideName}
                      onChange={(e) => setBrideName(e.target.value)}
                      placeholder="e.g. Bethlehem Assefa"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('organizerDashboard.credentials.groomName')}
                    </label>
                    <input
                      type="text"
                      required
                      value={groomName}
                      onChange={(e) => setGroomName(e.target.value)}
                      placeholder="e.g. Henok Girma"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('organizerDashboard.credentials.email')}
                    </label>
                    <input
                      type="email"
                      required
                      value={coupleEmail}
                      onChange={(e) => setCoupleEmail(e.target.value)}
                      placeholder="couple@bethlehem-henok.com"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('organizerDashboard.credentials.date')}
                    </label>
                    <input
                      type="date"
                      required
                      value={eventDate}
                      onChange={(e) => setEventDate(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('organizerDashboard.credentials.venue')}
                    </label>
                    <input
                      type="text"
                      required
                      value={venueName}
                      onChange={(e) => setVenueName(e.target.value)}
                      placeholder="e.g. Skylight Hotel Grand Ballroom, Addis Ababa"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div className="sm:col-span-2 flex justify-end pt-3">
                    <button
                      type="submit"
                      disabled={requestingApproval}
                      className="px-8 py-3.5 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-md transition-all flex items-center gap-2 border border-gold-500/40"
                    >
                      <Send className="w-4 h-4 text-gold-400" />
                      <span>{requestingApproval ? t('organizerDashboard.credentials.submittingBtn') : t('organizerDashboard.credentials.submitBtn')}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Status Tracking Table */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-4">
                <h3 className="font-serif font-bold text-lg text-gray-900">
                  {t('organizerDashboard.credentials.trackerTitle')}
                </h3>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-gold-500/20 text-[10px] text-gold-700 font-bold uppercase tracking-wider bg-gray-50">
                        <th className="py-3 px-4 rounded-l-xl">Wedding Title</th>
                        <th className="py-3 px-4">Couple Contact Login</th>
                        <th className="py-3 px-4">Admin Verification</th>
                        <th className="py-3 px-4 text-right rounded-r-xl">1-Click Portal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {events.map((evt) => (
                        <tr key={evt.id} className="hover:bg-gray-50 transition-colors">
                          <td className="py-3 px-4 font-serif font-bold text-gray-900">
                            {evt.title}
                          </td>
                          <td className="py-3 px-4 font-mono text-gray-600">
                            {evt.coupleCredentials?.email || `couple@${evt.slug}.com`}
                          </td>
                          <td className="py-3 px-4">
                            {evt.adminApprovalStatus === 'APPROVED' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                                <CheckCircle2 className="w-3 h-3 text-emerald-700" /> Approved
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                                <Clock className="w-3 h-3 text-amber-700" /> Pending Admin
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <Link
                              href="/couple/dashboard"
                              className="px-3 py-1.5 rounded-lg bg-black hover:bg-gray-800 text-gold-400 text-xs font-bold shadow-sm inline-flex items-center gap-1 border border-gold-500/30"
                            >
                              <span>Launch Couple Suite</span>
                              <ExternalLink className="w-3 h-3 text-gold-400" />
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* =========================================================================
              PILLAR 3: GLOBAL MEDIA MODERATION
             ========================================================================= */}
          {activeTab === 'MEDIA' && (
            <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-6">
              <div className="pb-4 border-b border-gold-500/20">
                <h2 className="font-serif font-bold text-xl text-gray-900">
                  {t('coupleDashboard.media.title')} ({mediaAssets.length})
                </h2>
                <p className="text-xs text-gray-600 font-light mt-0.5">
                  {t('coupleDashboard.media.subtitle')}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {mediaAssets.map((asset) => (
                  <div
                    key={asset.id}
                    className="p-4 rounded-2xl border border-gold-500/20 bg-gray-50 flex flex-col justify-between shadow-sm"
                  >
                    <div>
                      <div className="h-44 rounded-xl overflow-hidden bg-black mb-3 flex items-center justify-center">
                        {asset.mediaType === 'VIDEO' || asset.cdnUrl.includes('.mp4') ? (
                          <video
                            src={asset.cdnUrl}
                            controls
                            playsInline
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <img
                            src={asset.cdnUrl}
                            alt={asset.caption}
                            className="w-full h-full object-cover"
                          />
                        )}
                      </div>
                      <div className="font-serif font-bold text-sm text-gray-900">{asset.uploaderName}</div>
                      <p className="text-xs text-gray-600 italic mt-1 line-clamp-2">"{asset.caption}"</p>
                    </div>

                    <div className="mt-3 pt-3 border-t border-gray-200 flex items-center justify-between text-xs font-bold">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px]">
                        🟢 {t('coupleDashboard.media.tabPosted')}
                      </span>
                      <span className="text-[10px] text-gray-500">
                        {new Date(asset.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </main>
      </div>

    </div>
  );
}
