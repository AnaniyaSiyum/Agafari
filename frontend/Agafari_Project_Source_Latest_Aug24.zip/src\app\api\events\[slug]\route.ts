export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { mockStore, EventData } from '@/lib/mockData';

// GET: Fetch event details
export async function GET(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const { slug } = params;
  const event = mockStore.events.find((e) => e.slug === slug);

  if (!event) {
    return NextResponse.json(
      { error: `Event with slug '${slug}' not found` },
      { status: 404 }
    );
  }

  return NextResponse.json({ event });
}

// PUT / PATCH: Couple creates or updates their wedding celebration details
export async function PUT(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const { slug } = params;
  const event = mockStore.events.find((e) => e.slug === slug);

  if (!event) {
    return NextResponse.json(
      { error: `Event with slug '${slug}' not found` },
      { status: 404 }
    );
  }

  try {
    const body = await req.json();
    const {
      brideName,
      groomName,
      coverImageUrl,
      venueName,
      venueAddress,
      venueMapUrl,
      eventDate,
      startTime,
      secondEventDate,
      dressCode,
      welcomeMessage,
      backgroundMusicUrl,
      backgroundMusicTitle,
    } = body;

    if (brideName) event.brideName = brideName.trim();
    if (groomName) event.groomName = groomName.trim();
    if (brideName && groomName) {
      event.title = `${event.brideName} & ${event.groomName}'s Royal Wedding`;
    }
    if (coverImageUrl) event.coverImageUrl = coverImageUrl.trim();
    if (venueName) event.venueName = venueName.trim();
    if (venueAddress) event.venueAddress = venueAddress.trim();
    if (venueMapUrl) event.venueMapUrl = venueMapUrl.trim();
    if (eventDate) event.eventDate = eventDate;
    if (startTime) event.startTime = startTime;
    if (secondEventDate) event.secondEventDate = secondEventDate;
    if (dressCode) event.dressCode = dressCode.trim();
    if (welcomeMessage) event.welcomeMessage = welcomeMessage.trim();
    if (backgroundMusicUrl !== undefined) event.backgroundMusicUrl = backgroundMusicUrl.trim();
    if (backgroundMusicTitle !== undefined) event.backgroundMusicTitle = backgroundMusicTitle.trim();

    return NextResponse.json({
      success: true,
      message: 'Wedding celebration details updated successfully!',
      event,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update event details.' },
      { status: 500 }
    );
  }
}
