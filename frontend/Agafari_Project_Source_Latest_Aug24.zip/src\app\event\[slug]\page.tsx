'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  Heart, 
  Send, 
  Calendar, 
  MapPin, 
  Video, 
  QrCode, 
  Film, 
  CheckCircle, 
  MessageSquareHeart, 
  ArrowLeft, 
  ArrowRight, 
  Navigation, 
  Crown, 
  Shirt, 
  Music, 
  CheckCircle2, 
  Users, 
  Building2, 
  X, 
  Radio, 
  Share2, 
  HelpCircle, 
  User, 
  Upload, 
  Play, 
  Camera, 
  ShieldCheck, 
  Download, 
  Copy, 
  Check, 
  ExternalLink,
  Home
} from 'lucide-react';
import { useTranslation, LanguageSwitcher } from '@/lib/i18n';

interface MezmurItem {
  id: string;
  title: string;
  artist: string;
  category: 'MEZMUR' | 'TRADITIONAL' | 'DANCE' | 'SLOW';
}

interface EventData {
  id: string;
  slug: string;
  title: string;
  brideName: string;
  groomName: string;
  eventDate: string;
  venueName: string;
  venueAddress: string;
  venueMapUrl: string;
  dressCode?: string;
  welcomeMessage: string;
  coverImageUrl: string;
  youtubeStreamUrl?: string;
  youtubeVideoId?: string;
  isLive?: boolean;
  backgroundMusicUrl?: string;
  backgroundMusicTitle?: string;
  mezmurPlaylist?: MezmurItem[];
}

interface WishData {
  id: string;
  eventId: string;
  senderName: string;
  message: string;
  mediaType?: 'TEXT' | 'VIDEO';
  videoUrl?: string;
  createdAt: string;
}

interface InvitationRecord {
  id: string;
  inviteCode: string;
  guestName: string;
  maxGuests: number;
  inviteType: 'CARD' | 'LINK';
  tableNumber?: string;
}

export default function PublicWeddingCelebrationPage({
  params,
}: {
  params: { slug: string };
}) {
  const { t, locale } = useTranslation();
  const { slug } = params;
  const searchParams = useSearchParams();
  const codeParam = searchParams.get('code');

  const [event, setEvent] = useState<EventData | null>(null);
  const [wishes, setWishes] = useState<WishData[]>([]);
  const [invitation, setInvitation] = useState<InvitationRecord | null>(null);
  const [loading, setLoading] = useState(true);

  // Active Guest Profile State
  const [activeInviteCode, setActiveInviteCode] = useState<string>(codeParam || 'INV-SD2026-001');
  const [rsvpGuestName, setRsvpGuestName] = useState<string>('Abebe Kebede & Guest');
  const [invitationSource, setInvitationSource] = useState<'CARD' | 'LINK'>('CARD');

  // Interactive Wish State (VIDEO BLESSING DEFAULT)
  const [wishType, setWishType] = useState<'TEXT' | 'VIDEO'>('VIDEO');
  const [senderName, setSenderName] = useState('');
  const [wishMessage, setWishMessage] = useState('');
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [submittingWish, setSubmittingWish] = useState(false);
  const [wishSubmittedSuccess, setWishSubmittedSuccess] = useState(false);

  // Guest Song Suggestion
  const [guestSongTitle, setGuestSongTitle] = useState('');
  const [guestSongArtist, setGuestSongArtist] = useState('');
  const [songSubmittedSuccess, setSongSubmittedSuccess] = useState(false);

  // Attendance RSVP Modal State (5-Second Prompt)
  const [rsvpModalOpen, setRsvpModalOpen] = useState(false);
  const [hasAnsweredRsvp, setHasAnsweredRsvp] = useState(false);
  const [attendanceChoice, setAttendanceChoice] = useState<'ATTENDING' | 'DECLINED' | 'MAYBE'>('ATTENDING');
  const [guestAttendanceType, setGuestAttendanceType] = useState<'SINGLE' | 'COUPLE'>('COUPLE');
  const [recommendedSong, setRecommendedSong] = useState('');
  const [submittingRsvp, setSubmittingRsvp] = useState(false);
  const [rsvpSuccessMessage, setRsvpSuccessMessage] = useState('');
  const [copiedPass, setCopiedPass] = useState(false);

  // State for Bottom Dock Active Tab Modals & Audio Toggle
  const [activeTabModal, setActiveTabModal] = useState<'NONE' | 'HISTORY' | 'PROGRAM' | 'GALLERY'>('NONE');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);

  const toggleAudio = () => {
    if (!audioRef.current) return;
    if (isPlayingAudio) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlayingAudio(true);
      }).catch((err) => {
        console.error('Audio playback error:', err);
      });
    }
  };

  // Real-time Countdown Timer State
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    async function loadEventHub() {
      try {
        const [eventRes, wishesRes] = await Promise.all([
          fetch(`/api/events/${slug}`),
          fetch(`/api/events/${slug}/wishes`),
        ]);

        if (eventRes.ok) {
          const eventData = await eventRes.json();
          setEvent(eventData.event);
        }

        if (wishesRes.ok) {
          const wishesData = await wishesRes.json();
          setWishes(wishesData.wishes || []);
        }

        // 1. Check if guest query param is present in URL
        const guestQuery = searchParams.get('guest') || searchParams.get('name');
        if (guestQuery) {
          const decodedGuest = decodeURIComponent(guestQuery).trim();
          if (decodedGuest) {
            setRsvpGuestName(decodedGuest);
            setSenderName(decodedGuest);
          }
        }

        // 2. Check if specific invite code was passed
        if (codeParam) {
          try {
            const inviteRes = await fetch(`/api/events/${slug}/invitations?code=${codeParam}`);
            if (inviteRes.ok) {
              const inviteData = await inviteRes.json();
              if (inviteData.invitation) {
                setInvitation(inviteData.invitation);
                setActiveInviteCode(inviteData.invitation.inviteCode);
                if (inviteData.invitation.guestName) {
                  setRsvpGuestName(inviteData.invitation.guestName);
                  setSenderName(inviteData.invitation.guestName);
                }
                setInvitationSource(inviteData.invitation.inviteType || 'LINK');
              }
            }
          } catch (e) {}
        }
      } catch (err) {
        console.error('Failed to load event celebration hub:', err);
      } finally {
        setLoading(false);
      }
    }

    loadEventHub();

    // Trigger RSVP Modal
    const timer = setTimeout(() => {
      setRsvpModalOpen(true);
    }, 4500);

    return () => clearTimeout(timer);
  }, [slug, codeParam]);

  // Real-time Countdown Clock Tick
  useEffect(() => {
    if (!event?.eventDate) return;

    const target = new Date(event.eventDate).getTime();

    const updateCountdown = () => {
      const now = new Date().getTime();
      const difference = target - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [event?.eventDate]);

  // Submit RSVP Attendance Directly (1-Click Instant Automatic Submit)
  const handleDirectRsvpSelect = async (choice: 'ATTENDING' | 'MAYBE' | 'DECLINED') => {
    setAttendanceChoice(choice);
    setSubmittingRsvp(true);

    try {
      const res = await fetch(`/api/events/${slug}/rsvp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestName: rsvpGuestName,
          status: choice,
          inviteCode: activeInviteCode,
        }),
      });

      if (res.ok) {
        setHasAnsweredRsvp(true);
        const data = await res.json();
        setRsvpSuccessMessage(
          data.message || (
            choice === 'ATTENDING'
              ? (locale === 'am' ? '✓ በደስታ እንጠብቅዎታለን! (Attending Confirmed)' : '✓ Wonderful! Your attendance is confirmed. See you at the celebration!')
              : choice === 'MAYBE'
              ? (locale === 'am' ? '✓ እናመሰግናለን! ምላሽዎ ተመዝግቧል።' : '✓ Thank you! We have recorded your response.')
              : (locale === 'am' ? '✓ እናመሰግናለን! የሙሽሮቹ መልካም ምኞት ከእርስዎ ጋር ይሁን።' : '✓ Thank you for letting us know. You will be missed!')
          )
        );
        setTimeout(() => {
          setRsvpModalOpen(false);
          setRsvpSuccessMessage('');
        }, 1800);
      }
    } catch (err) {
      console.error('Failed to submit RSVP:', err);
    } finally {
      setSubmittingRsvp(false);
    }
  };

  // Submit Wish or Video Blessing
  const handleWishSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderName.trim() || (!wishMessage.trim() && !videoFile && !videoPreviewUrl)) return;

    setSubmittingWish(true);
    try {
      const payloadMessage = wishType === 'VIDEO'
        ? `[📹 Video Blessing Uploaded]: ${wishMessage.trim() || 'Heartfelt video blessing for the couple!'}`
        : wishMessage;

      const fallbackVideo = 'https://assets.mixkit.co/videos/preview/mixkit-bride-and-groom-smiling-and-holding-hands-43183-large.mp4';
      const res = await fetch(`/api/events/${slug}/wishes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          senderName, 
          message: payloadMessage,
          mediaType: wishType,
          videoUrl: wishType === 'VIDEO' ? (videoPreviewUrl || fallbackVideo) : undefined,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.wish) {
          setWishes((prev) => [data.wish, ...prev]);
        }
        setWishSubmittedSuccess(true);
        setSenderName('');
        setWishMessage('');
        setVideoFile(null);
        setVideoPreviewUrl(null);
        setTimeout(() => setWishSubmittedSuccess(false), 5000);
      }
    } catch (err) {
      console.error('Failed to submit wish:', err);
    } finally {
      setSubmittingWish(false);
    }
  };

  // Handle Video File Selection
  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoFile(file);
      const url = URL.createObjectURL(file);
      setVideoPreviewUrl(url);
    }
  };

  // Submit Guest Song Recommendation
  const handleSongRecommendation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestSongTitle.trim()) return;

    setSongSubmittedSuccess(true);
    setGuestSongTitle('');
    setGuestSongArtist('');
    setTimeout(() => setSongSubmittedSuccess(false), 5000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="font-serif text-gold-400 text-sm">{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center px-6">
        <div className="glass-panel-dark p-8 rounded-3xl text-center max-w-md border-2 border-gold-500/40 shadow-2xl">
          <h2 className="font-serif text-xl font-bold text-gold-400 mb-2">Wedding Not Found</h2>
          <p className="text-white/70 text-xs mb-6">The requested wedding link is invalid or expired.</p>
          <Link href="/" className="px-5 py-2 rounded-full bg-gold-500 text-black font-bold text-xs shadow-md">
            {t('common.back')}
          </Link>
        </div>
      </div>
    );
  }

  // Dynamic Unique QR Code Payload Generator
  const currentQuota = guestAttendanceType === 'COUPLE' ? 2 : 1;
  const currentTable = invitation?.tableNumber || (currentQuota === 2 ? 'Table 1: VIP Couples' : 'Table 4: Individual VIP');

  const qrPayload = JSON.stringify({
    code: activeInviteCode,
    guest: rsvpGuestName,
    quota: currentQuota,
    event: event.slug,
  });

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(
    qrPayload
  )}`;

  // Standardized Professional 800x1200 Digital Pass Card Generator
  const downloadVerificationCard = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 1200;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Dark Gold Luxury Background
    ctx.fillStyle = '#09090B';
    ctx.fillRect(0, 0, 800, 1200);

    // Outer & Inner Gold Foil Borders
    ctx.strokeStyle = '#D4AF37';
    ctx.lineWidth = 10;
    ctx.strokeRect(25, 25, 750, 1150);

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.strokeRect(35, 35, 730, 1130);

    // Couple Image Banner (Top Half)
    const coupleImg = new Image();
    coupleImg.crossOrigin = 'anonymous';
    coupleImg.onload = () => {
      ctx.drawImage(coupleImg, 45, 45, 710, 360);

      // Dark Overlay Gradient over image
      const gradient = ctx.createLinearGradient(0, 45, 0, 405);
      gradient.addColorStop(0, 'rgba(0,0,0,0.1)');
      gradient.addColorStop(1, 'rgba(0,0,0,0.85)');
      ctx.fillStyle = gradient;
      ctx.fillRect(45, 45, 710, 360);

      // Header Text over Image Banner
      ctx.fillStyle = '#D4AF37';
      ctx.font = 'bold 15px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('AGAFARI ROYAL ENTRANCE PASS', 400, 100);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 38px serif';
      ctx.fillText(`${event.brideName} & ${event.groomName}`, 400, 165);

      ctx.fillStyle = '#F3F4F6';
      ctx.font = '16px serif';
      ctx.fillText('ROYAL WEDDING CELEBRATION', 400, 205);

      ctx.fillStyle = '#D4AF37';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText(`${new Date(event.eventDate).toLocaleDateString()} • ${event.venueName}`, 400, 370);

      // Card Main Details Body Container
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(60, 420, 680, 710);

      // Guest Name & Table Details
      ctx.fillStyle = '#111827';
      ctx.font = 'bold 30px serif';
      ctx.fillText(rsvpGuestName || 'Valued Guest & Family', 400, 485);

      ctx.fillStyle = '#B45309';
      ctx.font = 'bold 18px sans-serif';
      ctx.fillText(`ADMIT: ${currentQuota} PERSON(S) • ${currentTable}`, 400, 530);

      // High-Density Scannable QR Code
      const qrImg = new Image();
      qrImg.crossOrigin = 'anonymous';
      qrImg.onload = () => {
        ctx.drawImage(qrImg, 240, 570, 320, 320);

        ctx.fillStyle = '#111827';
        ctx.font = 'bold 18px monospace';
        ctx.fillText(`PASS CODE: ${activeInviteCode}`, 400, 930);

        // Security Verification Seal Banner
        ctx.fillStyle = '#065F46';
        ctx.fillRect(100, 970, 600, 70);

        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 20px sans-serif';
        ctx.fillText('✓ OFFICIAL GATE SECURITY VERIFIED PASS', 400, 1012);

        ctx.fillStyle = '#6B7280';
        ctx.font = '13px sans-serif';
        ctx.fillText('Present this pass at the gate scanner for usher verification.', 400, 1090);

        const a = document.createElement('a');
        a.download = `Agafari_Royal_Pass_${activeInviteCode}.png`;
        a.href = canvas.toDataURL('image/png');
        a.click();
      };
      qrImg.src = qrImageUrl;
    };
    coupleImg.src = '/images/hero_couple_bg.png';
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white text-gray-900 pb-28 font-sans relative">
      
      {/* ========================================================================= */}
      {/* 1. FULL-SCREEN HERO BANNER (100% FULL WIDTH & HEIGHT - NO ZIGZAG) */}
      {/* ========================================================================= */}
      <section className="relative w-full min-h-screen h-screen bg-stone-950 text-white flex flex-col justify-between p-4 sm:p-8 overflow-hidden shadow-2xl">
        {/* Fixed 100% Full Cover Background Image - No Zigzag Cuts */}
        <img
          src="/images/hero_couple_bg.png"
          alt={`${event.brideName} and ${event.groomName}`}
          className="fixed inset-0 w-full h-full object-cover object-center filter brightness-105 contrast-105 saturate-110 z-0 pointer-events-none"
        />
        {/* Soft Contrast Gradient Overlay for Text Readability Without Darkening Faces */}
        <div className="fixed inset-0 bg-gradient-to-b from-black/50 via-transparent to-stone-950/95 z-0 pointer-events-none" />

        {/* Top Header Bar - Fixed at Very Top (Logo, Music Toggle, Language Switcher) */}
        <nav className="relative z-20 flex items-center justify-between w-full max-w-7xl mx-auto py-2">
          <Link href="/" className="flex items-center gap-3 shrink-0">
            {/* Artboard-15 White/Gold Amharic Logo without background */}
            <img
              src="/branding/artboard-15.png"
              alt="Agafari (አጋፋሪ) Logo"
              className="h-10 sm:h-12 w-auto object-contain filter drop-shadow-md"
            />
          </Link>

          <div className="flex items-center gap-3 shrink-0">
            {/* YouTube Background Mezmur (oVs7dGNBOp8 - ለይኩኑ) & HTML5 Audio Player */}
            {event?.youtubeVideoId || event?.backgroundMusicUrl?.includes('youtube') || event?.backgroundMusicUrl?.includes('youtu.be') ? (
              <iframe
                id="youtube-audio-player"
                src={`https://www.youtube.com/embed/${event?.youtubeVideoId || 'oVs7dGNBOp8'}?enablejsapi=1&autoplay=${isPlayingAudio ? 1 : 0}&loop=1&playlist=${event?.youtubeVideoId || 'oVs7dGNBOp8'}`}
                className="hidden"
                allow="autoplay"
              />
            ) : null}

            <audio
              ref={audioRef}
              loop
              src={event?.backgroundMusicUrl || '/audio/leykunu_mezmur.mp3'}
            />

            {/* Icon-Only Mute / Unmute Button */}
            <button
              onClick={toggleAudio}
              className={`w-9 h-9 rounded-full flex items-center justify-center text-sm transition-all cursor-pointer shadow-md ${
                isPlayingAudio
                  ? 'bg-gold-500 text-black shadow-gold scale-110 border border-gold-300'
                  : 'bg-black/80 text-gold-400 border border-gold-500/40 hover:scale-105'
              }`}
              title={isPlayingAudio ? 'Mute Sound' : 'Unmute Sound'}
            >
              {isPlayingAudio ? '🔊' : '🔇'}
            </button>

            <div className="hidden lg:inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-black/80 backdrop-blur-md text-gold-400 text-xs font-bold border border-gold-500/40 shadow-lg">
              <Crown className="w-4 h-4 text-gold-400" />
              <span>Invitation for <strong>{rsvpGuestName || 'Dear Guest'}</strong></span>
            </div>

            <LanguageSwitcher />
          </div>
        </nav>

        {/* FLOATING TYPOGRAPHY ALIGNED TO THE VERY BOTTOM OF HERO PHOTO */}
        <div className="relative z-20 text-center max-w-3xl mx-auto mt-auto pb-8 sm:pb-12 space-y-2">
          {/* SAVE THE DATE Header */}
          <h2 className="font-serif text-sm sm:text-lg font-bold text-gold-400 tracking-[0.25em] uppercase drop-shadow-md">
            SAVE THE DATE
          </h2>

          {/* CALLIGRAPHIC CURSIVE COUPLE NAMES */}
          <h1 className="font-script text-5xl sm:text-7xl lg:text-8xl font-bold text-white drop-shadow-2xl tracking-wide py-1">
            Sara & Dawit
          </h1>

          {/* EVENT DATE & VENUE */}
          <div className="space-y-0.5 text-xs sm:text-sm font-extrabold uppercase tracking-widest text-gold-200 drop-shadow">
            <p>AUGUST 15TH, 2026</p>
            <p className="text-[11px] sm:text-xs text-white/90 font-bold">AT SHERATON ADDIS, BALLROOM</p>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. MAIN INVITATION LETTER & DETAILS SECTIONS BELOW HERO */}
      {/* ========================================================================= */}
      <section className="relative z-10 px-4 sm:px-6 py-10 max-w-4xl mx-auto space-y-10">
        
        {/* FLOATING INVITATION LETTER BELOW HERO */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="w-full text-white text-center space-y-5 py-4 relative"
        >
          {/* Dear Families and Friends Title */}
          <h3 className="font-script text-3xl sm:text-5xl font-bold text-gold-300 drop-shadow-lg">
            Dear Families and Friends
          </h3>

          {/* Formal Invitation Message */}
          <p className="text-gray-200 text-xs sm:text-sm sm:text-base leading-relaxed font-serif italic max-w-2xl mx-auto px-4 drop-shadow">
            "Together with their families, <strong>Sara & Dawit</strong> joyfully invite you to celebrate their wedding day! Join us as we say <em>'I do'</em> on August 15th at the Sheraton Addis Luxury Ballroom. It will be a beautiful evening filled with love, laughter, and unforgettable memories and we'd be honored to share it with you."
          </p>

          {/* 3D COUNTDOWN TIMER TICKER */}
          <div className="pt-3 pb-2">
            <div className="grid grid-cols-4 gap-2.5 sm:gap-4 max-w-md mx-auto">
              {[
                { label: t('publicEvent.countdown.days'), value: timeLeft.days },
                { label: t('publicEvent.countdown.hours'), value: timeLeft.hours },
                { label: t('publicEvent.countdown.minutes'), value: timeLeft.minutes },
                { label: t('publicEvent.countdown.seconds'), value: timeLeft.seconds },
              ].map((unit, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  className="p-2.5 sm:p-3.5 rounded-2xl border-2 border-gold-500/60 bg-black/80 backdrop-blur-md text-center shadow-2xl"
                >
                  <div className="font-serif text-xl sm:text-3xl font-extrabold text-gold-400 drop-shadow">
                    {String(unit.value).padStart(2, '0')}
                  </div>
                  <div className="text-[9px] text-gold-200 uppercase font-bold tracking-wider mt-0.5">
                    {unit.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* SUPER ATTRACTIVE, MAGNETIC "SHOW THE MAP" BUTTON */}
          <div className="pt-4 border-t border-gold-500/30 flex flex-col sm:flex-row items-center justify-between gap-5 px-2">
            <div className="text-left flex items-center gap-3">
              <MapPin className="w-5 h-5 text-gold-400 shrink-0" />
              <span className="text-xs sm:text-sm text-gray-200 font-medium drop-shadow">
                {event.venueName} • {event.venueAddress}
              </span>
            </div>

            <a
              href={event.venueMapUrl || 'https://maps.google.com/?q=Sheraton+Addis'}
              target="_blank"
              rel="noreferrer"
              className="relative group overflow-hidden w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-gold-400 to-amber-500 hover:from-gold-300 hover:to-amber-400 text-black font-extrabold text-xs sm:text-sm tracking-wider uppercase shadow-[0_0_30px_rgba(234,179,8,0.6)] transition-all duration-300 flex items-center justify-center gap-3 shrink-0 border-2 border-amber-200 cursor-pointer hover:scale-105 active:scale-95"
            >
              <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
              <div className="w-8 h-8 rounded-full bg-black/10 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5 text-black animate-bounce" />
              </div>
              <span className="drop-shadow-sm font-black">📍 TAP TO OPEN VENUE MAP & DIRECTIONS</span>
              <ExternalLink className="w-4 h-4 text-black group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </motion.div>

          {/* FLOATING CULTURAL GOLD PROTOCOL (NO CONTAINER BOX) */}
          <div className="w-full max-w-4xl text-gold-200 text-xs space-y-4 text-left py-4 border-t border-b border-gold-500/30">
            <div className="pb-2 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-gold-400 font-bold uppercase tracking-widest block">
                  Official Event Protocol & Details
                </span>
                <h3 className="font-serif text-lg font-bold text-white mt-0.5 drop-shadow">
                  Ceremony & Celebration Guidelines
                </h3>
              </div>
              <div className="px-3 py-1 rounded-full bg-gold-500/20 text-gold-400 font-bold text-[10px] border border-gold-500/40 backdrop-blur-md">
                VIP RSVP
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-gold-400 shrink-0" />
                <div>
                  <span className="font-bold text-white">Date: August 15, 2026</span>
                  <p className="text-[11px] text-gray-300">Gate check-in starts at 1:00 PM</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-gold-400 shrink-0" />
                <div>
                  <span className="font-bold text-white">Venue: Sheraton Addis Luxury Ballroom</span>
                  <p className="text-[11px] text-gray-300">Taitu Street, Addis Ababa, Ethiopia</p>
                </div>
              </div>

              {event.dressCode && (
                <div className="flex items-center gap-3 sm:col-span-2 border-t border-gold-500/20 pt-3">
                  <Shirt className="w-5 h-5 text-gold-400 shrink-0" />
                  <div>
                    <div className="text-[10px] text-gold-400 font-semibold uppercase">Dress Code</div>
                    <span className="font-bold text-white text-xs">{event.dressCode}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* FLOATING WATCH LIVE BROADCAST BANNER */}
          <div className="w-full max-w-4xl p-6 rounded-3xl bg-gradient-to-r from-rose-950/80 via-black/80 to-rose-950/80 backdrop-blur-xl border-2 border-rose-500/50 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-2xl">
            <div className="flex items-center gap-3 text-left">
              <div className="w-12 h-12 rounded-2xl bg-rose-600/30 text-rose-400 flex items-center justify-center shrink-0 border border-rose-500/40">
                <Video className="w-6 h-6 text-rose-400 animate-pulse" />
              </div>
              <div>
                <div className="text-[10px] text-rose-400 font-bold uppercase tracking-wider">Live Broadcast Stream</div>
                <h3 className="font-serif font-bold text-lg text-white">Watch Sara & Dawit's Wedding Live</h3>
              </div>
            </div>

            <Link
              href={`/event/${slug}`}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-700 to-rose-600 hover:from-rose-600 hover:to-rose-800 text-white font-extrabold text-xs shadow-lg transition-all flex items-center justify-center gap-2 shrink-0 border border-rose-400/40 cursor-pointer hover:scale-105"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
              <span>Watch Live Broadcast</span>
            </Link>
          </div>

          {/* FLOATING ATTENDANCE RSVP BUTTON BAR */}
          <div className="w-full max-w-4xl p-6 sm:p-8 rounded-3xl border-2 border-gold-500/50 bg-black/80 backdrop-blur-xl text-white flex items-center justify-between shadow-2xl">
            <div className="text-left">
              <div className="text-xs text-gold-400 font-bold uppercase tracking-wider mb-1">
                Attendance Confirmation
              </div>
              <div className="font-serif font-bold text-base sm:text-xl text-white">
                {hasAnsweredRsvp ? 'Confirmed for Wedding Celebration ✓' : 'Will you attend our celebration?'}
              </div>
            </div>

            <button
              onClick={() => setRsvpModalOpen(true)}
              className="px-6 py-3.5 rounded-2xl bg-gold-500 hover:bg-gold-600 text-black font-extrabold text-xs sm:text-sm shadow-gold transition-all shrink-0 border border-gold-400 cursor-pointer hover:scale-105"
            >
              {hasAnsweredRsvp ? 'Update RSVP' : 'Submit RSVP'}
            </button>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. QR GATE PASS SECTION (ONLY QR BOX HAS WHITE BG CARD, WORDS & BUTTONS FLOAT) */}
      {/* ========================================================================= */}
      <section className="px-4 sm:px-6 py-8 max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="w-full text-center space-y-6 py-4"
        >
          {/* Invitation Source Detection Pill */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-black/80 backdrop-blur-md text-gold-400 text-[11px] font-bold shadow-md border border-gold-500/40">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>
              {invitationSource === 'CARD'
                ? '🏷️ Physical Invitation Card • Pre-Printed QR Verified'
                : '✨ Direct Link Guest • Dynamic Gate Pass Generated'}
            </span>
          </div>

          <div className="space-y-1">
            <h3 className="font-serif text-2xl sm:text-4xl font-bold text-white tracking-wide drop-shadow-md">
              {t('publicEvent.qrPass.title')}
            </h3>
            <p className="text-xs sm:text-sm text-gray-300 font-light max-w-lg mx-auto leading-relaxed drop-shadow">
              {t('publicEvent.qrPass.subtitle')}
            </p>
          </div>

          {/* Scannable Unique QR Code Card (ONLY THIS HAS WHITE CARD BACKGROUND) */}
          <div className="p-4 sm:p-5 bg-white rounded-3xl border-2 border-gold-500/50 inline-block shadow-2xl relative group my-2">
            <img
              src={qrImageUrl}
              alt={`Personal Entrance QR Pass for ${rsvpGuestName}`}
              className="w-52 h-52 sm:w-64 sm:h-64 mx-auto rounded-2xl"
            />
            <div className="mt-3 flex items-center justify-center gap-1.5 text-[10px] font-extrabold text-gray-900 tracking-wider">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>LIVE TOKEN SIGNATURE: {activeInviteCode}</span>
            </div>
          </div>

          {/* Pass Meta Information */}
          <div className="space-y-1.5">
            <div className="text-xs font-mono font-bold text-gold-300 bg-black/70 backdrop-blur-md py-1.5 px-4 rounded-full inline-block border border-gold-500/40 shadow-md">
              PASS CODE: <span className="text-gold-400 font-extrabold">{activeInviteCode}</span>
            </div>
            <div className="text-xs text-gray-200 font-medium drop-shadow">
              {t('publicEvent.qrPass.quotaAllowed')}: <strong className="text-white font-bold">{currentQuota} {currentQuota > 1 ? t('common.guests') : t('common.guest')}</strong>
            </div>
          </div>

          {/* Pass Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            {/* Download Gate Pass Image with Couple Photo */}
            <button
              type="button"
              onClick={downloadVerificationCard}
              className="px-6 py-3 rounded-full bg-gradient-to-r from-gold-400 to-amber-500 hover:from-gold-300 hover:to-gold-500 text-black font-extrabold text-xs shadow-gold transition-all flex items-center gap-2 border border-amber-200 cursor-pointer active:scale-95 hover:scale-105"
            >
              <Download className="w-4 h-4 text-black" />
              {t('publicEvent.qrPass.downloadPass')}
            </button>

            {/* Copy Personal Guest Deep Link */}
            <button
              onClick={() => {
                const personalLink = `${window.location.origin}/event/${slug}?code=${activeInviteCode}&guest=${encodeURIComponent(rsvpGuestName)}`;
                navigator.clipboard.writeText(personalLink);
                setCopiedPass(true);
                setTimeout(() => setCopiedPass(false), 3000);
              }}
              className="px-6 py-3 rounded-full bg-black/80 backdrop-blur-md text-white hover:bg-black/90 font-bold text-xs border border-gold-500/40 transition-all flex items-center gap-2 cursor-pointer active:scale-95 hover:scale-105 shadow-md"
            >
              {copiedPass ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-gold-400" />}
              {copiedPass ? t('common.copied') : 'Copy Personal Invitation Link'}
            </button>
          </div>
        </motion.div>
      </section>

      {/* ========================================================================= */}
      {/* 4. HONORED VIP PERFORMERS & GUEST SONG RECOMMENDATION SECTION */}
      {/* ========================================================================= */}
      <section className="px-4 sm:px-6 py-8 max-w-4xl mx-auto border-t border-gold-500/20">
        <div className="space-y-6 text-center">
          <div className="flex items-center justify-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gold-500/20 text-gold-400 flex items-center justify-center border border-gold-500/40">
              <Music className="w-5 h-5 text-gold-400" />
            </div>
            <div className="text-left">
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-white drop-shadow">
                Honored VIP Performers & Choirs
              </h3>
              <p className="text-xs text-gray-300 font-light">
                Distinguished musical guests & spiritual choirs performing at our wedding.
              </p>
            </div>
          </div>

          {/* Invited Famous Artists / Choirs Showcase */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { name: 'Ethiopian Orthodox Wedding Choir', role: 'Spiritual Entrance Mezmurs', type: 'CHOIR' },
              { name: 'Addis Cultural Habesha Band', role: 'Traditional Eskista & Merekba Dance', type: 'BAND' },
              { name: 'Acoustic Habesha Ensemble', role: 'Dinner & Royal Vows Serenade', type: 'ACOUSTIC' },
            ].map((artist, idx) => (
              <div key={idx} className="p-5 rounded-2xl bg-black/70 backdrop-blur-md border border-gold-500/30 text-left space-y-1 shadow-md">
                <span className="px-2.5 py-0.5 rounded-full bg-gold-500/20 text-gold-300 font-bold text-[9px] border border-gold-500/30">
                  {artist.type}
                </span>
                <div className="font-serif font-bold text-white text-sm mt-1 drop-shadow">{artist.name}</div>
                <div className="text-[11px] text-gray-300">{artist.role}</div>
              </div>
            ))}
          </div>

          {/* Guest Mezmur / Song Recommendation Box */}
          <div className="p-6 rounded-2xl border border-gold-500/30 bg-black/70 backdrop-blur-md text-left shadow-lg">
            <h4 className="font-serif font-bold text-white text-sm mb-1 drop-shadow">
              Recommend a Mezmur or Song to the Couple
            </h4>
            <p className="text-xs text-gray-300 font-light mb-4">
              Have a favorite spiritual Mezmur or upbeat Eskista song you'd love to hear at the wedding? Suggest it below!
            </p>

            {songSubmittedSuccess ? (
              <div className="p-3 rounded-xl bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                Thank you! Your song recommendation has been sent to Sara & Dawit!
              </div>
            ) : (
              <form onSubmit={handleSongRecommendation} className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                <input
                  type="text"
                  required
                  value={guestSongTitle}
                  onChange={(e) => setGuestSongTitle(e.target.value)}
                  placeholder="Song or Mezmur Title"
                  className="px-3.5 py-2.5 rounded-xl border border-gold-500/40 bg-black/60 text-xs text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                />
                <input
                  type="text"
                  value={guestSongArtist}
                  onChange={(e) => setGuestSongArtist(e.target.value)}
                  placeholder="Choir / Singer (Optional)"
                  className="px-3.5 py-2.5 rounded-xl border border-gold-500/40 bg-black/60 text-xs text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                />
                <button
                  type="submit"
                  className="py-2.5 rounded-xl bg-gold-500 text-black font-extrabold text-xs hover:bg-gold-400 shadow-gold flex items-center justify-center gap-1.5 border border-gold-300 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5 text-black" /> Send Recommendation
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* 5. GUEST BLESSING SECTION (VIDEO BLESSING DEFAULT) */}
      <section className="px-6 py-12 max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="p-8 sm:p-12 rounded-3xl border border-gold-500/30 hover:border-gold-500 transition-all duration-300 bg-white text-gray-900 relative overflow-hidden shadow-sm"
        >
          <div className="text-center mb-8 relative z-10">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-gold-500 via-amber-300 to-gold-600 text-black mx-auto flex items-center justify-center mb-3 shadow-md">
              <MessageSquareHeart className="w-7 h-7 text-black" />
            </div>

            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-black text-gold-400 text-[10px] font-bold uppercase tracking-widest mb-2 shadow-sm border border-gold-500/30">
              <Sparkles className="w-3 h-3 text-gold-400" />
              {t('publicEvent.wishes.badge')}
            </div>

            <h3 className="font-serif text-3xl sm:text-4xl font-bold text-gray-900">
              {t('publicEvent.wishes.title')}
            </h3>
            <p className="text-gray-600 text-xs sm:text-sm mt-1 font-light max-w-lg mx-auto leading-relaxed">
              {t('publicEvent.wishes.subtitle')}
            </p>

            {/* Mode Switcher - Video Blessing Selected First */}
            <div className="flex items-center justify-center gap-2.5 mt-5">
              <button
                type="button"
                onClick={() => setWishType('VIDEO')}
                className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  wishType === 'VIDEO'
                    ? 'bg-black text-gold-400 shadow-md border border-gold-500/40 scale-105'
                    : 'bg-gray-50 border border-gold-500/30 text-gray-900'
                }`}
              >
                <Camera className="w-3.5 h-3.5" /> 📹 Video Blessing (Default)
              </button>
              <button
                type="button"
                onClick={() => setWishType('TEXT')}
                className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  wishType === 'TEXT'
                    ? 'bg-black text-gold-400 shadow-md border border-gold-500/40 scale-105'
                    : 'bg-gray-50 border border-gold-500/30 text-gray-900'
                }`}
              >
                <MessageSquareHeart className="w-3.5 h-3.5" /> ✍️ Text Blessing
              </button>
            </div>
          </div>

          <form onSubmit={handleWishSubmit} className="space-y-4 text-xs relative z-10">
            <div>
              <label className="block text-[10px] font-bold text-gray-900 uppercase tracking-wider mb-1.5">
                {t('publicEvent.wishes.senderName')}
              </label>
              <input
                type="text"
                required
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                placeholder={t('publicEvent.wishes.senderPlaceholder')}
                className="w-full px-4 py-3 rounded-xl border-2 border-gold-500/30 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500 text-xs font-medium"
              />
            </div>

            {wishType === 'VIDEO' ? (
              <div className="space-y-3">
                <label className="block text-[10px] font-bold text-gray-900 uppercase tracking-wider">
                  Upload Video Blessing
                </label>

                {videoPreviewUrl ? (
                  <div className="rounded-2xl overflow-hidden border-2 border-gold-500/40 bg-black/90 p-3 text-center space-y-2">
                    <video
                      src={videoPreviewUrl}
                      controls
                      className="w-full max-h-60 rounded-xl mx-auto"
                    />
                    <div className="flex items-center justify-between text-[11px] text-white px-1">
                      <span>✓ Video ready: {videoFile?.name || 'video_blessing.mp4'}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setVideoFile(null);
                          setVideoPreviewUrl(null);
                        }}
                        className="text-rose-400 hover:text-rose-300 font-bold"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ) : (
                  <label className="border-2 border-dashed border-gold-500/50 rounded-2xl p-8 text-center cursor-pointer hover:border-gold-500 transition-all block bg-gray-50 group shadow-sm">
                    <div className="w-14 h-14 rounded-full bg-gold-500/20 text-gray-900 mx-auto flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
                      <Upload className="w-6 h-6 text-gold-600" />
                    </div>
                    <p className="font-serif font-bold text-sm text-gray-900">Record or Select Video Blessing</p>
                    <p className="text-[11px] text-gray-500 mt-1 font-light">Supports phone video recording up to 60 seconds (Max 50MB)</p>
                    <input
                      type="file"
                      accept="video/*"
                      onChange={handleVideoChange}
                      className="hidden"
                    />
                  </label>
                )}

                <div>
                  <label className="block text-[10px] font-bold text-gray-900 uppercase tracking-wider mb-1">
                    Caption / Personal Message
                  </label>
                  <input
                    type="text"
                    value={wishMessage}
                    onChange={(e) => setWishMessage(e.target.value)}
                    placeholder="e.g. Wishing you endless joy and blessings!"
                    className="w-full px-4 py-2.5 rounded-xl border-2 border-gold-500/30 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500 text-xs font-medium"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-[10px] font-bold text-gray-900 uppercase tracking-wider mb-1.5">
                  {t('publicEvent.wishes.messageLabel')}
                </label>
                <textarea
                  required
                  rows={4}
                  value={wishMessage}
                  onChange={(e) => setWishMessage(e.target.value)}
                  placeholder={t('publicEvent.wishes.messagePlaceholder')}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gold-500/30 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500 text-xs leading-relaxed font-medium"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={submittingWish}
              className="w-full py-4 rounded-full bg-gold-500 hover:bg-gold-600 text-black font-extrabold text-xs sm:text-sm shadow-gold transition-all flex items-center justify-center gap-2 disabled:opacity-50 mt-4 cursor-pointer border border-gold-400/40"
            >
              <Sparkles className="w-4 h-4 text-black" />
              <span>{submittingWish ? t('publicEvent.wishes.sendingButton') : t('publicEvent.wishes.submitButton')}</span>
              <Send className="w-4 h-4 text-black" />
            </button>
          </form>

          <AnimatePresence>
            {wishSubmittedSuccess && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mt-4 p-4 rounded-2xl bg-emerald-950 border border-emerald-500 text-emerald-200 text-center text-xs"
              >
                <CheckCircle className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                <p className="font-bold">{t('publicEvent.wishes.successMsg')}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </section>

      {/* 6. FLOATING BOTTOM NAVIGATION DOCK (4 CHOICES: HOME, HISTORY, PROGRAM, GALLERY) */}
      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-black/90 backdrop-blur-xl border-2 border-gold-500/60 rounded-full px-3 py-2 shadow-2xl flex items-center gap-2 sm:gap-3 text-xs font-bold animate-in slide-in-from-bottom-5">
        {/* 1) Home (ACTIVE) */}
        <Link
          href={`/event/${slug}`}
          className="px-4 py-2 rounded-full bg-gold-500 text-black shadow-gold scale-105 transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Home className="w-4 h-4 shrink-0 fill-black" />
          <span className="hidden sm:inline">Home</span>
        </Link>

        {/* 2) Couple History */}
        <Link
          href={`/event/${slug}/history`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Heart className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">Couple History</span>
          <span className="sm:hidden">History</span>
        </Link>

        {/* 3) Lists of Programs */}
        <Link
          href={`/event/${slug}/program`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Calendar className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">Programs</span>
        </Link>

        {/* 4) Gallery */}
        <Link
          href={`/event/${slug}/gallery`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Camera className="w-4 h-4 shrink-0" />
          <span>Gallery</span>
        </Link>
      </div>

      {/* 7. BOTTOM EVENT ORGANIZER & HAMELMAL CREATIVES PROMOTION */}
      <section className="mt-12 py-10 bg-white border-t border-gray-100 px-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-left">
            <div className="w-12 h-12 rounded-2xl bg-black text-gold-400 flex items-center justify-center font-serif font-bold text-xl shadow-sm shrink-0 border border-gold-500/30">
              H
            </div>
            <div>
              <div className="text-[10px] text-gold-600 font-bold uppercase tracking-wider">
                Event Host & Digital Operations
              </div>
              <h4 className="font-serif font-bold text-gray-900 text-base">
                Yonas Planners & Hamelmal Creatives
              </h4>
              <p className="text-xs text-gray-500 font-light mt-0.5">
                Full-service technical event production, digital gate pass security, and live broadcast engineering.
              </p>
            </div>
          </div>

          <a
            href="https://hamelmal.com"
            target="_blank"
            rel="noreferrer"
            className="px-6 py-3 rounded-full bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-md transition-all flex items-center gap-2 shrink-0 border border-gold-500/40"
          >
            <Sparkles className="w-3.5 h-3.5 text-gold-400" />
            <span>Visit Hamelmal Creatives</span>
            <ExternalLink className="w-3.5 h-3.5 text-gold-400" />
          </a>
        </div>
      </section>

      {/* 8. 5-SECOND "WILL YOU COME?" SMART RSVP POPUP MODAL */}
      <AnimatePresence>
        {rsvpModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 260 }}
              className="p-7 sm:p-9 rounded-3xl border-2 border-gold-500 max-w-lg w-full relative bg-white text-gray-900 shadow-2xl max-h-[90vh] overflow-y-auto"
            >
              <button
                onClick={() => setRsvpModalOpen(false)}
                className="absolute top-5 right-5 text-gray-500 hover:text-gray-900 p-1.5 rounded-full bg-gray-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-center mb-6">
                <div className="w-12 h-12 rounded-full bg-gold-500 text-black mx-auto flex items-center justify-center mb-3 shadow-gold">
                  <Heart className="w-6 h-6 fill-black text-black" />
                </div>
                <span className="text-[10px] text-gold-600 font-bold uppercase tracking-widest block mb-1">
                  Wedding Attendance Confirmation
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900">
                  {rsvpGuestName || 'Dear Guest & Family'}
                </h3>
                <p className="text-gold-700 text-xs mt-1 font-serif italic font-medium">
                  {event.brideName} & {event.groomName} cordially invite you to celebrate our union!
                </p>
              </div>

              {rsvpSuccessMessage ? (
                <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-300 text-center text-emerald-950 text-xs shadow-md">
                  <CheckCircle className="w-9 h-9 text-emerald-600 mx-auto mb-2 animate-bounce" />
                  <p className="font-bold text-sm text-gray-900">
                    {locale === 'am' ? 'ምላሽዎ ተመዝግቧል!' : 'Response Confirmed!'}
                  </p>
                  <p className="text-[11px] text-emerald-800 mt-1">{rsvpSuccessMessage}</p>
                </div>
              ) : (
                <div className="space-y-3 text-xs">
                  {submittingRsvp && (
                    <div className="py-2 text-center text-xs text-gold-600 font-semibold animate-pulse">
                      {t('common.submitting')}
                    </div>
                  )}

                  {/* 3 Instant Choices - Auto Submit on Tap */}
                  <div className="grid grid-cols-1 gap-2.5">
                    {/* 1. YES - Attending */}
                    <motion.button
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      type="button"
                      disabled={submittingRsvp}
                      onClick={() => handleDirectRsvpSelect('ATTENDING')}
                      className="p-4 rounded-2xl border-2 border-gold-500 bg-gold-500 hover:bg-gold-600 text-black font-extrabold text-xs shadow-gold transition-all flex items-center justify-between group disabled:opacity-50 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-black text-gold-400 flex items-center justify-center shadow-sm shrink-0">
                          <CheckCircle2 className="w-5 h-5 text-gold-400" />
                        </div>
                        <div className="text-left">
                          <div className="font-serif font-bold text-sm text-black">
                            {locale === 'am' ? 'በደስታ እገኛለሁ 🥂' : 'Yes, Attending 🥂'}
                          </div>
                          <div className="text-[10px] text-black/80 font-medium">
                            {locale === 'am' ? 'በሰርጉ ላይ እገኛለሁ' : 'I will be there to celebrate with you'}
                          </div>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-black group-hover:translate-x-1 transition-transform" />
                    </motion.button>

                    {/* 2. MAYBE - Undecided */}
                    <motion.button
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      type="button"
                      disabled={submittingRsvp}
                      onClick={() => handleDirectRsvpSelect('MAYBE')}
                      className="p-4 rounded-2xl border-2 border-gray-200 bg-gray-50 hover:bg-gray-100 text-gray-900 font-bold text-xs shadow-sm transition-all flex items-center justify-between group disabled:opacity-50 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-gold-500/20 text-gold-700 flex items-center justify-center shadow-sm shrink-0">
                          <HelpCircle className="w-5 h-5" />
                        </div>
                        <div className="text-left">
                          <div className="font-serif font-bold text-sm text-gray-900">
                            {locale === 'am' ? 'እርግጠኛ አይደለሁም 🤔' : 'Maybe 🤔'}
                          </div>
                          <div className="text-[10px] text-gray-600 font-normal">
                            {locale === 'am' ? 'አልወሰንኩም / ምናልባት እገኛለሁ' : 'Not sure yet / Will try to make it'}
                          </div>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-gray-700 group-hover:translate-x-1 transition-transform" />
                    </motion.button>

                    {/* 3. NO - Declined */}
                    <motion.button
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      type="button"
                      disabled={submittingRsvp}
                      onClick={() => handleDirectRsvpSelect('DECLINED')}
                      className="p-4 rounded-2xl border-2 border-rose-200 bg-rose-50/80 hover:bg-rose-100 text-rose-900 font-bold text-xs shadow-sm transition-all flex items-center justify-between group disabled:opacity-50 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shadow-sm shrink-0">
                          <X className="w-5 h-5" />
                        </div>
                        <div className="text-left">
                          <div className="font-serif font-bold text-sm text-rose-900">
                            {locale === 'am' ? 'አልችልም 💔' : 'Cannot Attend 💔'}
                          </div>
                          <div className="text-[10px] text-rose-700/80 font-normal">
                            {locale === 'am' ? 'በሰርጉ ላይ መገኘት አልችልም' : 'Unable to attend, best wishes'}
                          </div>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-rose-600 group-hover:translate-x-1 transition-transform" />
                    </motion.button>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
