'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  ArrowLeft, 
  Sparkles, 
  Clock, 
  MapPin, 
  Home, 
  Heart, 
  Camera, 
  Crown,
  Music,
  Utensils,
  Camera as CameraIcon,
  Shirt,
  Wine
} from 'lucide-react';
import { useTranslation, LanguageSwitcher } from '@/lib/i18n';

interface EventData {
  brideName: string;
  groomName: string;
  venueName: string;
  venueAddress: string;
  eventDate: string;
}

export default function WeddingProgramPage({ params }: { params: { slug: string } }) {
  const { slug } = params;
  const { t } = useTranslation();
  const [event, setEvent] = useState<EventData | null>(null);
  const [activeDay, setActiveDay] = useState<'MAIN' | 'MELSE'>('MAIN');

  useEffect(() => {
    async function loadEvent() {
      try {
        const res = await fetch(`/api/events/${slug}`);
        if (res.ok) {
          const data = await res.json();
          setEvent(data.event);
        }
      } catch (err) {
        console.error('Failed to load event for program page:', err);
      }
    }
    loadEvent();
  }, [slug]);

  const mainPrograms = [
    {
      time: '11:00 AM',
      title: 'Groom & Groomsmen Arrival & Preparation',
      location: 'Sheraton Addis Executive Suite',
      description: 'Groom dressing, traditional blessing from parents and elders before heading to church.',
      icon: Clock,
      category: 'PREPARATION',
    },
    {
      time: '01:00 PM',
      title: 'Holy Matrimony & Orthodox Church Blessing',
      location: 'Addis Ababa Orthodox Cathedral',
      description: 'Sacred wedding vows, crowning ceremony, and exchange of rings before holy altar.',
      icon: Crown,
      category: 'CEREMONY',
    },
    {
      time: '03:30 PM',
      title: 'Royal Photo Session & Garden Toast',
      location: 'Friendship Park & Entoto Botanic Gardens',
      description: 'Bridal party and family portrait sessions surrounded by breathtaking scenery.',
      icon: CameraIcon,
      category: 'PHOTOSHOOT',
    },
    {
      time: '05:30 PM',
      title: 'Grand Entrance of Bride & Groom',
      location: 'Sheraton Addis Luxury Ballroom',
      description: 'Red carpet reception entrance with traditional Mezmur choirs and trumpet fanfare.',
      icon: Sparkles,
      category: 'ENTRANCE',
    },
    {
      time: '06:30 PM',
      title: 'Royal Wedding Banquet & Dinner',
      location: 'Sheraton Luxury Dining Hall',
      description: 'Exquisite Habesha & international buffet feast accompanied by acoustic live band.',
      icon: Utensils,
      category: 'DINNER',
    },
    {
      time: '08:00 PM',
      title: 'Wedding Cake Cutting & Champagne Toast',
      location: 'Main Ballroom Stage',
      description: 'Parent speeches, formal toasts, and cutting of the 5-tier royal wedding cake.',
      icon: Wine,
      category: 'TOAST',
    },
    {
      time: '09:30 PM',
      title: 'Merekba & Eskista Traditional Dance Celebration',
      location: 'Grand Ballroom Dance Floor',
      description: 'Upbeat traditional Ethiopian dance, live music, and evening celebration with guests.',
      icon: Music,
      category: 'CELEBRATION',
    },
  ];

  const melsePrograms = [
    {
      time: '02:00 PM',
      title: 'Melse Reception & Habesha Kemis Dressing',
      location: 'Residence Luxury Pavilion',
      description: 'Traditional Habesha cultural attire showcase, royal crown headpiece fitting.',
      icon: Shirt,
      category: 'MELSE',
    },
    {
      time: '04:00 PM',
      title: 'Koba & Bread Cutting Cultural Protocol',
      location: 'Cultural Stage',
      description: 'Traditional bread cutting and blessings bestowed by mother and elders.',
      icon: Sparkles,
      category: 'CULTURE',
    },
    {
      time: '06:00 PM',
      title: 'Traditional Feast & Gursha Ceremony',
      location: 'Main Dining Tent',
      description: 'Traditional Ethiopian dishes, honey wine (Tej), and intimate family gathering.',
      icon: Utensils,
      category: 'FEAST',
    },
  ];

  const activePrograms = activeDay === 'MAIN' ? mainPrograms : melsePrograms;

  return (
    <div className="min-h-screen w-full bg-stone-950 text-white font-sans relative pb-32 overflow-x-hidden">
      
      {/* Background Glow Accents */}
      <div className="fixed top-0 right-1/4 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl pointer-events-none z-0" />
      <div className="fixed bottom-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none z-0" />

      {/* 1. TOP HEADER NAVBAR */}
      <header className="sticky top-0 z-40 bg-black/80 backdrop-blur-xl border-b border-gold-500/30 px-4 sm:px-8 py-3 flex items-center justify-between shadow-2xl">
        <div className="flex items-center gap-3">
          <Link
            href={`/event/${slug}`}
            className="w-9 h-9 rounded-full bg-black/60 border border-gold-500/40 text-gold-400 flex items-center justify-center hover:scale-105 transition-transform"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <Link href={`/event/${slug}`}>
            <img
              src="/branding/artboard-15.png"
              alt="Agafari Logo"
              className="h-9 w-auto object-contain"
            />
          </Link>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-500/20 border border-gold-500/40 text-gold-300 text-xs font-bold">
            <Calendar className="w-3.5 h-3.5 text-gold-400" />
            <span>Event Schedule & Programs</span>
          </div>
          <LanguageSwitcher />
        </div>
      </header>

      {/* 2. HERO HEADER SECTION */}
      <main className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 pt-8 space-y-10">
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold-500/20 border border-gold-500/50 text-gold-300 text-xs font-extrabold tracking-widest uppercase shadow-md">
            <Clock className="w-3.5 h-3.5 text-gold-400" />
            <span>OFFICIAL WEDDING TIMELINE</span>
          </div>
          <h1 className="font-script text-5xl sm:text-7xl font-bold text-white drop-shadow-2xl py-1">
            Lists of Programs & Events
          </h1>
          <p className="text-gray-300 font-serif italic text-sm sm:text-base max-w-xl mx-auto leading-relaxed drop-shadow">
            "Join us for each memorable chapter of our wedding celebration, from holy vows to traditional evening dance."
          </p>
          <div className="w-36 h-1 bg-gradient-to-r from-transparent via-gold-500 to-transparent mx-auto rounded-full" />
        </div>

        {/* 3. EVENT DAY SWITCHER (MAIN WEDDING VS MELSE) */}
        <div className="flex justify-center gap-3">
          <button
            onClick={() => setActiveDay('MAIN')}
            className={`px-6 py-3 rounded-2xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer border shadow-lg ${
              activeDay === 'MAIN'
                ? 'bg-gold-500 text-black border-gold-400 shadow-gold scale-105'
                : 'bg-black/70 text-gold-300 border-gold-500/40 hover:bg-black/90'
            }`}
          >
            👑 Main Wedding Day (Aug 15)
          </button>
          <button
            onClick={() => setActiveDay('MELSE')}
            className={`px-6 py-3 rounded-2xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer border shadow-lg ${
              activeDay === 'MELSE'
                ? 'bg-gold-500 text-black border-gold-400 shadow-gold scale-105'
                : 'bg-black/70 text-gold-300 border-gold-500/40 hover:bg-black/90'
            }`}
          >
            ✨ Melse Celebration (Aug 16)
          </button>
        </div>

        {/* 4. PROGRAM LIST ITEMS */}
        <div className="space-y-4">
          {activePrograms.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.08 }}
                className="p-6 sm:p-8 rounded-3xl bg-black/80 backdrop-blur-xl border border-gold-500/40 hover:border-gold-500 transition-all shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-gold-500/20 text-gold-400 flex items-center justify-center shrink-0 border border-gold-500/40 shadow-md mt-1 sm:mt-0">
                    <IconComponent className="w-6 h-6 text-gold-400" />
                  </div>
                  <div className="space-y-1 text-left">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full bg-gold-500/20 text-gold-300 font-bold text-[9px] uppercase tracking-widest border border-gold-500/30">
                        {item.category}
                      </span>
                    </div>
                    <h3 className="font-serif font-bold text-lg sm:text-xl text-white">
                      {item.title}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-gold-400 font-medium">
                      <MapPin className="w-3.5 h-3.5 text-gold-400 shrink-0" />
                      <span>{item.location}</span>
                    </div>
                    <p className="text-gray-300 text-xs sm:text-sm font-light pt-1">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="px-5 py-2.5 rounded-2xl bg-gold-500/20 border border-gold-500/50 text-gold-300 font-mono font-extrabold text-sm sm:text-base shrink-0 self-end sm:self-center shadow-md">
                  {item.time}
                </div>
              </motion.div>
            );
          })}
        </div>
      </main>

      {/* 5. FLOATING BOTTOM NAVIGATION DOCK (4 CHOICES: HOME, HISTORY, PROGRAM, GALLERY) */}
      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-black/90 backdrop-blur-xl border-2 border-gold-500/60 rounded-full px-3 py-2 shadow-2xl flex items-center gap-2 sm:gap-3 text-xs font-bold">
        {/* 1) Home */}
        <Link
          href={`/event/${slug}`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Home className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">Home</span>
        </Link>

        {/* 2) Couple History */}
        <Link
          href={`/event/${slug}/history`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Heart className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">Couple History</span>
          <span className="sm:hidden">History</span>
        </Link>

        {/* 3) Lists of Programs (ACTIVE) */}
        <Link
          href={`/event/${slug}/program`}
          className="px-4 py-2 rounded-full bg-gold-500 text-black shadow-gold scale-105 transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Calendar className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">Lists of Programs</span>
          <span className="sm:hidden">Programs</span>
        </Link>

        {/* 4) Gallery */}
        <Link
          href={`/event/${slug}/gallery`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Camera className="w-4 h-4 shrink-0" />
          <span>Gallery</span>
        </Link>
      </div>

    </div>
  );
}
