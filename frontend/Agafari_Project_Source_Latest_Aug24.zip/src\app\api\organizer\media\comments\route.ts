export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { mockStore } from '@/lib/mockData';

interface MediaCommentRecord {
  id: string;
  mediaId: string;
  senderName: string;
  comment: string;
  createdAt: string;
}

// In-memory store for comments on videos
const mockComments: MediaCommentRecord[] = [
  {
    id: 'c1',
    mediaId: 'med-1',
    senderName: 'Uncle Bekele',
    comment: 'You look so beautiful Sara! Egziabhier Yibarkachihu!',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
  },
  {
    id: 'c2',
    mediaId: 'med-1',
    senderName: 'Helen Girma',
    comment: 'The dress is unbelievable! Best wedding of 2026! 🔥❤️',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
];

// GET comments for a video
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const mediaId = searchParams.get('mediaId');

  let list = mockComments;
  if (mediaId) {
    list = list.filter((c) => c.mediaId === mediaId);
  }

  return NextResponse.json({ comments: list });
}

// POST new comment/wish on a video
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { mediaId, senderName, comment } = body;

    if (!mediaId || !senderName || !comment) {
      return NextResponse.json(
        { error: 'mediaId, senderName, and comment are required.' },
        { status: 400 }
      );
    }

    const newComment: MediaCommentRecord = {
      id: `c-${Date.now()}`,
      mediaId,
      senderName: senderName.trim(),
      comment: comment.trim(),
      createdAt: new Date().toISOString(),
    };

    mockComments.unshift(newComment);

    return NextResponse.json(
      {
        success: true,
        message: 'Comment added successfully.',
        comment: newComment,
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to add comment.' },
      { status: 500 }
    );
  }
}
