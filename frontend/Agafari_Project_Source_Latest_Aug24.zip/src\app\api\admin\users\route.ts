export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getAuthUser, hasRole, hashPassword, UserRole } from '@/lib/auth';
import { mockStore } from '@/lib/mockData';

// GET: Fetch all user accounts across the platform
export async function GET(req: NextRequest) {
  const user = getAuthUser(req);

  if (user && !hasRole(user, ['SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. System Admin access required.' },
      { status: 403 }
    );
  }

  const safeUsers = mockStore.users.map((u) => ({
    id: u.id,
    eventId: u.eventId,
    email: u.email,
    fullName: u.fullName,
    role: u.role,
    temporaryPassword: u.temporaryPassword,
  }));

  return NextResponse.json({ users: safeUsers });
}

// POST: Create a new account and assign role & event scope
export async function POST(req: NextRequest) {
  const adminUser = getAuthUser(req);

  if (adminUser && !hasRole(adminUser, ['SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. System Admin access required.' },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const { email, password, fullName, role, eventId } = body;

    if (!email || !password || !fullName || !role) {
      return NextResponse.json(
        { error: 'Email, password, full name, and role are required.' },
        { status: 400 }
      );
    }

    const existingUser = mockStore.users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase().trim()
    );

    if (existingUser) {
      return NextResponse.json(
        { error: `An account with email '${email}' already exists.` },
        { status: 400 }
      );
    }

    const newUser = {
      id: `usr-${Date.now()}`,
      eventId: eventId || null,
      email: email.toLowerCase().trim(),
      passwordHash: hashPassword(password),
      temporaryPassword: password,
      fullName: fullName.trim(),
      role: role as UserRole,
    };

    mockStore.users.push(newUser);

    return NextResponse.json(
      {
        success: true,
        message: `Account created successfully with role '${role}'.`,
        user: {
          id: newUser.id,
          email: newUser.email,
          fullName: newUser.fullName,
          role: newUser.role,
          eventId: newUser.eventId,
          temporaryPassword: newUser.temporaryPassword,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create user account.' },
      { status: 500 }
    );
  }
}

// PATCH: Reset password or change role
export async function PATCH(req: NextRequest) {
  const adminUser = getAuthUser(req);

  if (adminUser && !hasRole(adminUser, ['SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. System Admin access required.' },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const { userId, newPassword, fullName, role } = body;

    const user = mockStore.users.find((u) => u.id === userId);
    if (!user) {
      return NextResponse.json({ error: 'User not found.' }, { status: 404 });
    }

    if (newPassword) {
      user.passwordHash = hashPassword(newPassword);
      user.temporaryPassword = newPassword;
    }
    if (fullName) user.fullName = fullName.trim();
    if (role) user.role = role as UserRole;

    return NextResponse.json({
      success: true,
      message: 'User account updated successfully.',
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update user account.' },
      { status: 500 }
    );
  }
}

// DELETE: Delete user account
export async function DELETE(req: NextRequest) {
  const adminUser = getAuthUser(req);

  if (adminUser && !hasRole(adminUser, ['SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. System Admin access required.' },
      { status: 403 }
    );
  }

  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID required.' }, { status: 400 });
    }

    const index = mockStore.users.findIndex((u) => u.id === userId);
    if (index === -1) {
      return NextResponse.json({ error: 'User not found.' }, { status: 404 });
    }

    mockStore.users.splice(index, 1);

    return NextResponse.json({
      success: true,
      message: 'User account deleted successfully.',
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to delete user.' },
      { status: 500 }
    );
  }
}
