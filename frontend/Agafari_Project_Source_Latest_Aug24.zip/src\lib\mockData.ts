import { hashPassword, UserRole } from './auth';

export interface MezmurItem {
  id: string;
  title: string;
  artist: string;
  category: 'MEZMUR' | 'TRADITIONAL' | 'DANCE' | 'SLOW';
}

export interface EventData {
  id: string;
  slug: string;
  title: string;
  brideName: string;
  groomName: string;
  eventDate: string; // ISO String
  startTime?: string; // e.g. 14:00
  secondEventDate?: string; // e.g. Melse / Reception Date
  venueName: string;
  venueAddress: string;
  venueMapUrl: string;
  dressCode: string;
  welcomeMessage: string;
  coverImageUrl: string;
  status: 'DRAFT' | 'COMING_SOON' | 'LIVE' | 'COMPLETED' | 'ARCHIVED';
  adminApprovalStatus?: 'PENDING' | 'APPROVED' | 'REJECTED';
  coupleCredentials?: {
    email: string;
    temporaryPassword?: string;
  };
  youtubeStreamUrl?: string;
  youtubeVideoId?: string;
  isLive?: boolean;
  backgroundMusicUrl?: string;
  backgroundMusicTitle?: string;
  mezmurPlaylist?: MezmurItem[];
  thankYouMessage?: string;
  thankYouImageUrl?: string;
}

export interface UserRecord {
  id: string;
  eventId: string | null;
  email: string;
  passwordHash: string;
  temporaryPassword?: string;
  fullName: string;
  role: 'SYSTEM_ADMIN' | 'EVENT_ORGANIZER' | 'BRIDE_GROOM' | 'LIVE_STREAMER' | 'GATE_SCANNER' | 'GUEST';
}

export interface WishData {
  id: string;
  eventId: string;
  senderName: string;
  message: string;
  mediaType?: 'TEXT' | 'VIDEO';
  videoUrl?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

export interface MediaAssetData {
  id: string;
  eventId: string;
  uploaderName: string;
  mediaType: 'VIDEO' | 'IMAGE';
  category?: 'WISHES' | 'BTS' | 'LIVE';
  cdnUrl: string;
  thumbnailUrl?: string;
  caption: string;
  viewsCount?: number;
  likesCount?: number;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

export interface InvitationData {
  id: string;
  eventId: string;
  inviteCode: string;
  inviteType?: 'CARD' | 'LINK';
  rsvpStatus?: 'ATTENDING' | 'DECLINED' | 'PENDING';
  attendingHeadcount?: number;
  guestName: string;
  guestPhone: string;
  maxGuests: number;
  tableNumber?: string;
  scannedCount: number;
  isScanned: boolean;
  scannedAt?: string;
  qrCodeUrl: string;
  createdAt: string;
}

// Global in-memory storage for local runtime persistence
const mockEvents: EventData[] = [
  {
    id: 'evt-sara-dawit-2026',
    slug: 'sara-and-dawit-2026',
    title: "Sara & Dawit's Royal Wedding",
    brideName: 'Sara Tadesse',
    groomName: 'Dawit Alemayehu',
    eventDate: '2026-08-15T14:00:00.000Z',
    startTime: '14:00',
    venueName: 'Sheraton Addis Luxury Ballroom',
    venueAddress: 'Taitu Street, Addis Ababa, Ethiopia',
    venueMapUrl: 'https://maps.google.com/?q=Sheraton+Addis',
    dressCode: 'Traditional Habesha Kemis & Black Tie',
    welcomeMessage: 'We are overjoyed to celebrate the beginning of our forever journey with our beloved family and friends!',
    coverImageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop',
    status: 'COMING_SOON',
    adminApprovalStatus: 'APPROVED',
    coupleCredentials: {
      email: 'couple@sara-dawit.com',
      temporaryPassword: 'couple123',
    },
    youtubeStreamUrl: 'https://youtu.be/oVs7dGNBOp8?si=7m5-BmpPGpOVZUar',
    youtubeVideoId: 'oVs7dGNBOp8',
    isLive: false,
    backgroundMusicUrl: '/audio/leykunu_mezmur.mp3',
    backgroundMusicTitle: 'ለይኩኑ (Leykunu Orthodox Wedding Mezmur)',
    mezmurPlaylist: [
      { id: 'm1', title: 'Meskelene Alene (Serege)', artist: 'Ethiopian Orthodox Wedding Choir', category: 'MEZMUR' },
      { id: 'm2', title: 'Yene Gena & Merekba Dance', artist: 'Traditional Habesha Cultural Ensemble', category: 'TRADITIONAL' },
      { id: 'm3', title: 'Eskista Royal Entrance', artist: 'Addis Cultural Band', category: 'DANCE' },
      { id: 'm4', title: 'Kalkidan (Vows of Forever)', artist: 'Acoustic Habesha Ensemble', category: 'SLOW' },
    ],
  },
  {
    id: 'evt-bethlehem-michael-2026',
    slug: 'bethlehem-and-michael-2026',
    title: "Bethlehem & Michael's Grand Celebration",
    brideName: 'Bethlehem Kassa',
    groomName: 'Michael Haile',
    eventDate: '2026-10-24T15:00:00.000Z',
    startTime: '15:00',
    venueName: 'Ethiopian Skylight Hotel Grand Ballroom',
    venueAddress: 'Bole Airport Road, Addis Ababa',
    venueMapUrl: 'https://maps.google.com/?q=Skylight+Hotel+Addis',
    dressCode: 'Royal Gold & Emerald Habesha Attire',
    welcomeMessage: 'Welcome to our celebration of love, faith, and family harmony!',
    coverImageUrl: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=1200&auto=format&fit=crop',
    status: 'COMING_SOON',
    adminApprovalStatus: 'APPROVED',
    coupleCredentials: {
      email: 'couple@bethlehem-michael.com',
      temporaryPassword: 'bethpass2026',
    },
  },
  {
    id: 'evt-helina-samuel-2026',
    slug: 'helina-and-samuel-2026',
    title: "Helina & Samuel's Autumn Wedding",
    brideName: 'Helina Assefa',
    groomName: 'Samuel Getachew',
    eventDate: '2026-12-12T13:30:00.000Z',
    startTime: '13:30',
    venueName: 'Hilton Addis Ababa Poolside Gardens',
    venueAddress: 'Menelik II Avenue, Addis Ababa',
    venueMapUrl: 'https://maps.google.com/?q=Hilton+Addis',
    dressCode: 'Classic White & Traditional Kemis',
    welcomeMessage: 'Join us as we unite our hearts before God and our loved ones.',
    coverImageUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=1200&auto=format&fit=crop',
    status: 'DRAFT',
    adminApprovalStatus: 'PENDING',
    coupleCredentials: {
      email: 'couple@helina-samuel.com',
      temporaryPassword: 'helipass2026',
    },
  },
  {
    id: 'evt-hanna-yared-2025',
    slug: 'hanna-and-yared-2025',
    title: "Hanna & Yared's Luxury Wedding Archive",
    brideName: 'Hanna Tesfaye',
    groomName: 'Yared Worku',
    eventDate: '2025-01-10T14:00:00.000Z',
    startTime: '14:00',
    venueName: 'Hyatt Regency Addis Ababa',
    venueAddress: 'Meskel Square, Addis Ababa',
    venueMapUrl: 'https://maps.google.com/?q=Hyatt+Regency+Addis',
    dressCode: 'Black Tie & Habesha Cultural',
    welcomeMessage: 'Thank you for being part of our cherished memories!',
    coverImageUrl: 'https://images.unsplash.com/photo-1606800052052-a08af7148866?q=80&w=1200&auto=format&fit=crop',
    status: 'COMPLETED',
    adminApprovalStatus: 'APPROVED',
    coupleCredentials: {
      email: 'couple@hanna-yared.com',
      temporaryPassword: 'hannapass2025',
    },
  },
  {
    id: 'evt-selam-natnael-2024',
    slug: 'selam-and-natnael-2024',
    title: "Selamawit & Natnael's Garden Wedding Archive",
    brideName: 'Selamawit Desta',
    groomName: 'Natnael Girma',
    eventDate: '2024-12-28T14:30:00.000Z',
    startTime: '14:30',
    venueName: 'Ghion Hotel Royal Palm Gardens',
    venueAddress: 'Ras Desta Damtew St, Addis Ababa',
    venueMapUrl: 'https://maps.google.com/?q=Ghion+Hotel',
    dressCode: 'Pastel & Traditional Habesha',
    welcomeMessage: 'A timeless memory of our special union.',
    coverImageUrl: 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?q=80&w=1200&auto=format&fit=crop',
    status: 'COMPLETED',
    adminApprovalStatus: 'APPROVED',
    coupleCredentials: {
      email: 'couple@selam-natnael.com',
      temporaryPassword: 'selampass2024',
    },
  },
];

const mockUsers: UserRecord[] = [
  {
    id: 'usr-admin-1',
    eventId: null,
    email: 'admin@hamelmal.com',
    passwordHash: hashPassword('admin123'),
    temporaryPassword: 'admin123',
    fullName: 'Hamelmal Admin',
    role: 'SYSTEM_ADMIN',
  },
  {
    id: 'usr-org-1',
    eventId: 'evt-sara-dawit-2026',
    email: 'organizer@sara-dawit.com',
    passwordHash: hashPassword('org123'),
    temporaryPassword: 'org123',
    fullName: 'Yonas Planners',
    role: 'EVENT_ORGANIZER',
  },
  {
    id: 'usr-couple-1',
    eventId: 'evt-sara-dawit-2026',
    email: 'couple@sara-dawit.com',
    passwordHash: hashPassword('couple123'),
    temporaryPassword: 'couple123',
    fullName: 'Sara & Dawit',
    role: 'BRIDE_GROOM',
  },
  {
    id: 'usr-streamer-1',
    eventId: 'evt-sara-dawit-2026',
    email: 'streamer@sara-dawit.com',
    passwordHash: hashPassword('stream123'),
    temporaryPassword: 'stream123',
    fullName: 'Abebe Media Operator',
    role: 'LIVE_STREAMER',
  },
  {
    id: 'usr-scanner-1',
    eventId: 'evt-sara-dawit-2026',
    email: 'scanner@sara-dawit.com',
    passwordHash: hashPassword('scan123'),
    temporaryPassword: 'scan123',
    fullName: 'Gate Security Gate 1',
    role: 'GATE_SCANNER',
  },
  // Bethlehem & Michael Users
  {
    id: 'usr-couple-2',
    eventId: 'evt-bethlehem-michael-2026',
    email: 'couple@bethlehem-michael.com',
    passwordHash: hashPassword('bethpass2026'),
    temporaryPassword: 'bethpass2026',
    fullName: 'Bethlehem & Michael',
    role: 'BRIDE_GROOM',
  },
  {
    id: 'usr-streamer-2',
    eventId: 'evt-bethlehem-michael-2026',
    email: 'streamer@bethlehem-michael.com',
    passwordHash: hashPassword('stream2026'),
    temporaryPassword: 'stream2026',
    fullName: 'Skylight Media Team',
    role: 'LIVE_STREAMER',
  },
  {
    id: 'usr-scanner-2',
    eventId: 'evt-bethlehem-michael-2026',
    email: 'scanner@bethlehem-michael.com',
    passwordHash: hashPassword('scan2026'),
    temporaryPassword: 'scan2026',
    fullName: 'Bole Gate Scanner Alpha',
    role: 'GATE_SCANNER',
  },
];

const mockWishes: WishData[] = [
  {
    id: 'wsh-1',
    eventId: 'evt-sara-dawit-2026',
    senderName: 'Uncle Bekele & Family',
    message: 'Wishing you both a lifetime of unconditional love, peace, and endless joy! Egziabhier Yibarkachihu!',
    status: 'APPROVED',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
  },
  {
    id: 'wsh-2',
    eventId: 'evt-sara-dawit-2026',
    senderName: 'Helen Girma',
    message: 'Can’t wait to celebrate with you guys! You look like a fairytale couple!',
    status: 'APPROVED',
    mediaType: 'TEXT',
    createdAt: new Date(Date.now() - 3600000 * 18).toISOString(),
  },
];

const mockMediaAssets: MediaAssetData[] = [
  {
    id: 'med-vid-1',
    eventId: 'evt-sara-dawit-2026',
    uploaderName: 'Bride Maid Team',
    mediaType: 'VIDEO',
    category: 'WISHES',
    cdnUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-couple-walking-in-a-park-on-their-wedding-day-43185-large.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=300&auto=format&fit=crop',
    caption: 'Magical moments and heartfelt blessings for Sara & Dawit! Wishing you endless love and happiness! 💍✨ #SaraAndDawit2026',
    viewsCount: 384,
    likesCount: 192,
    status: 'APPROVED',
    createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
  },
  {
    id: 'med-bts-1',
    eventId: 'evt-sara-dawit-2026',
    uploaderName: 'Best Man Robel',
    mediaType: 'VIDEO',
    category: 'BTS',
    cdnUrl: 'https://assets.mixkit.co/videos/preview/mixkit-bride-and-groom-smiling-and-holding-hands-43183-large.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=300&auto=format&fit=crop',
    caption: 'Behind the scenes: Groomsmen Eskista dance rehearsal before the royal entrance! 💃🕺 #BehindTheScenes',
    viewsCount: 520,
    likesCount: 284,
    status: 'APPROVED',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
  },
  {
    id: 'med-wish-2',
    eventId: 'evt-sara-dawit-2026',
    uploaderName: 'Uncle Bekele & Family',
    mediaType: 'VIDEO',
    category: 'WISHES',
    cdnUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-bride-holding-a-bouquet-43184-large.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=300&auto=format&fit=crop',
    caption: 'Sending our warmest blessings from Atlanta! May your marriage be filled with abundance and joy! 💖🥂 #WeddingWishes',
    viewsCount: 310,
    likesCount: 145,
    status: 'APPROVED',
    createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
  },
  {
    id: 'med-live-1',
    eventId: 'evt-sara-dawit-2026',
    uploaderName: 'Agafari Live Broadcast Team',
    mediaType: 'VIDEO',
    category: 'LIVE',
    cdnUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-couple-walking-in-a-park-on-their-wedding-day-43185-large.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=300&auto=format&fit=crop',
    caption: '🔴 LIVE BROADCAST: Royal Reception & Grand Entrance Ceremony at Sheraton Addis! 👑✨',
    viewsCount: 1240,
    likesCount: 680,
    status: 'APPROVED',
    createdAt: new Date().toISOString(),
  },
];

const mockInvitations: InvitationData[] = [
  {
    id: 'inv-1',
    eventId: 'evt-sara-dawit-2026',
    inviteCode: 'INV-SD2026-001',
    guestName: 'Abebe Kebede & Family',
    guestPhone: '+251911223344',
    maxGuests: 2,
    inviteType: 'CARD',
    rsvpStatus: 'ATTENDING',
    attendingHeadcount: 2,
    tableNumber: 'Table 1: Family VIP',
    scannedCount: 0,
    isScanned: false,
    qrCodeUrl: '/api/qr/INV-SD2026-001',
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
  },
  {
    id: 'inv-2',
    eventId: 'evt-sara-dawit-2026',
    inviteCode: 'INV-SD2026-002',
    guestName: 'Dr. Michael Tesfaye (London)',
    guestPhone: '+251922445566',
    maxGuests: 1,
    inviteType: 'LINK',
    rsvpStatus: 'ATTENDING',
    attendingHeadcount: 1,
    tableNumber: 'Table 3: Diaspora Relatives',
    scannedCount: 1,
    isScanned: true,
    qrCodeUrl: '/api/qr/INV-SD2026-002',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
  },
  {
    id: 'inv-3',
    eventId: 'evt-sara-dawit-2026',
    inviteCode: 'INV-SD2026-003',
    guestName: 'Sara Bekele & Guest',
    guestPhone: '+251933556677',
    maxGuests: 2,
    inviteType: 'CARD',
    rsvpStatus: 'PENDING',
    scannedCount: 0,
    isScanned: false,
    qrCodeUrl: '/api/qr/INV-SD2026-003',
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
  },
  {
    id: 'inv-4',
    eventId: 'evt-sara-dawit-2026',
    inviteCode: 'INV-SD2026-004',
    guestName: 'Yared & Tigist (Diaspora)',
    guestPhone: '+12025550192',
    maxGuests: 2,
    inviteType: 'LINK',
    rsvpStatus: 'DECLINED',
    scannedCount: 0,
    isScanned: false,
    qrCodeUrl: '/api/qr/INV-SD2026-004',
    createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
  },
];

export const mockStore = {
  events: mockEvents,
  users: mockUsers,
  wishes: mockWishes,
  mediaAssets: mockMediaAssets,
  invitations: mockInvitations,
};
