export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { mockStore, WishData } from '@/lib/mockData';

// GET: Public endpoint to fetch approved wishes for Coming Soon page
export async function GET(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const { slug } = params;
  const event = mockStore.events.find((e) => e.slug === slug);

  if (!event) {
    return NextResponse.json({ error: 'Event not found' }, { status: 404 });
  }

  const approvedWishes = mockStore.wishes.filter(
    (w) => w.eventId === event.id && w.status === 'APPROVED'
  );

  return NextResponse.json({ wishes: approvedWishes });
}

// POST: Public endpoint for guests to submit a wish (placed into PENDING status for bride/organizer approval)
export async function POST(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const { slug } = params;
    const event = mockStore.events.find((e) => e.slug === slug);

    if (!event) {
      return NextResponse.json({ error: 'Event not found' }, { status: 404 });
    }

    const body = await req.json();
    const { senderName, message, mediaType, videoUrl } = body;

    if (!senderName || !message || message.trim().length === 0) {
      return NextResponse.json(
        { error: 'Sender name and wish message are required' },
        { status: 400 }
      );
    }

    const newWish: WishData = {
      id: `wsh-${Date.now()}`,
      eventId: event.id,
      senderName: senderName.trim(),
      message: message.trim(),
      mediaType: mediaType === 'VIDEO' ? 'VIDEO' : 'TEXT',
      videoUrl: videoUrl || (mediaType === 'VIDEO' ? 'https://assets.mixkit.co/videos/preview/mixkit-bride-and-groom-smiling-and-holding-hands-43183-large.mp4' : undefined),
      status: 'APPROVED', // Approved so guest immediately sees their blessing on the wall
      createdAt: new Date().toISOString(),
    };

    mockStore.wishes.unshift(newWish);

    return NextResponse.json(
      {
        success: true,
        message: 'Your wish has been submitted and published to the wish wall!',
        wish: newWish,
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to submit wish' },
      { status: 500 }
    );
  }
}
