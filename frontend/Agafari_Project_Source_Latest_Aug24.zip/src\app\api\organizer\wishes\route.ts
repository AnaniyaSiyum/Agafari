export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getAuthUser, hasRole } from '@/lib/auth';
import { mockStore } from '@/lib/mockData';

// GET: Fetch all wishes for event organizer / bride / groom
export async function GET(req: NextRequest) {
  const user = getAuthUser(req);

  if (!hasRole(user, ['EVENT_ORGANIZER', 'BRIDE_GROOM', 'SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. Only organizers and couples can manage wishes.' },
      { status: 403 }
    );
  }

  let wishes = mockStore.wishes;
  if (user?.role !== 'SYSTEM_ADMIN' && user?.eventId) {
    wishes = wishes.filter((w) => w.eventId === user.eventId);
  }

  return NextResponse.json({ wishes });
}

// PATCH: Approve or Reject a wish
export async function PATCH(req: NextRequest) {
  const user = getAuthUser(req);

  if (!hasRole(user, ['EVENT_ORGANIZER', 'BRIDE_GROOM', 'SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. Only organizers and couples can approve wishes.' },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const { wishId, status } = body;

    if (!wishId || !['APPROVED', 'REJECTED'].includes(status)) {
      return NextResponse.json(
        { error: 'Valid wishId and status (APPROVED or REJECTED) are required' },
        { status: 400 }
      );
    }

    const wish = mockStore.wishes.find((w) => w.id === wishId);

    if (!wish) {
      return NextResponse.json({ error: 'Wish not found' }, { status: 404 });
    }

    if (user?.role !== 'SYSTEM_ADMIN' && user?.eventId && wish.eventId !== user.eventId) {
      return NextResponse.json(
        { error: 'Access denied: wish belongs to another event' },
        { status: 403 }
      );
    }

    wish.status = status;

    return NextResponse.json({
      success: true,
      message: `Wish has been ${status.toLowerCase()}`,
      wish,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update wish status' },
      { status: 500 }
    );
  }
}
