import { NextRequest, NextResponse } from 'next/server';
import { mockStore, UserRecord } from '@/lib/mockData';
import { hashPassword } from '@/lib/auth';

// GET: Fetch team members (Live Streamers & QR Gate Scanners) assigned to the event
export async function GET(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const { slug } = params;
  const event = mockStore.events.find((e) => e.slug === slug);

  if (!event) {
    return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
  }

  const teamMembers = mockStore.users.filter(
    (u) =>
      u.eventId === event.id &&
      (u.role === 'LIVE_STREAMER' || u.role === 'GATE_SCANNER')
  );

  return NextResponse.json({
    teamMembers: teamMembers.map((u) => ({
      id: u.id,
      fullName: u.fullName,
      email: u.email,
      role: u.role,
    })),
  });
}

// POST: Couple assigns a new Live Streamer or QR Gate Scanner
export async function POST(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const { slug } = params;
    const event = mockStore.events.find((e) => e.slug === slug);

    if (!event) {
      return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
    }

    const body = await req.json();
    const { fullName, email, password, role } = body;

    if (!fullName || !email || !password || !['LIVE_STREAMER', 'GATE_SCANNER'].includes(role)) {
      return NextResponse.json(
        { error: 'Full name, email, password, and valid role (LIVE_STREAMER or GATE_SCANNER) are required.' },
        { status: 400 }
      );
    }

    // Check if email already exists
    const existing = mockStore.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      return NextResponse.json(
        { error: 'A staff member with this email already exists.' },
        { status: 400 }
      );
    }

    const newUser: UserRecord = {
      id: `usr-staff-${Date.now().toString().slice(-4)}`,
      eventId: event.id,
      email: email.trim().toLowerCase(),
      fullName: fullName.trim(),
      passwordHash: hashPassword(password),
      role,
    };

    mockStore.users.push(newUser);

    return NextResponse.json(
      {
        success: true,
        message: `Assigned ${role === 'LIVE_STREAMER' ? 'Live Streamer' : 'QR Gate Scanner'} successfully!`,
        teamMember: {
          id: newUser.id,
          fullName: newUser.fullName,
          email: newUser.email,
          role: newUser.role,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to assign team member.' },
      { status: 500 }
    );
  }
}

// DELETE: Remove a staff assignment
export async function DELETE(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required.' }, { status: 400 });
    }

    const index = mockStore.users.findIndex((u) => u.id === userId);
    if (index === -1) {
      return NextResponse.json({ error: 'Staff member not found.' }, { status: 404 });
    }

    mockStore.users.splice(index, 1);

    return NextResponse.json({
      success: true,
      message: 'Staff role removed successfully.',
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to remove staff member.' },
      { status: 500 }
    );
  }
}
