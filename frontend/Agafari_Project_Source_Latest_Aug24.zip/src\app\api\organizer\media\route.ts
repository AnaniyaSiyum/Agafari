export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getAuthUser, hasRole } from '@/lib/auth';
import { mockStore } from '@/lib/mockData';

// GET: Fetch all media assets (TikTok video feed items) for moderation
export async function GET(req: NextRequest) {
  const user = getAuthUser(req);

  if (user && !hasRole(user, ['SYSTEM_ADMIN', 'EVENT_ORGANIZER', 'BRIDE_GROOM'])) {
    return NextResponse.json(
      { error: 'Unauthorized access.' },
      { status: 403 }
    );
  }

  const { searchParams } = new URL(req.url);
  const eventId = searchParams.get('eventId');

  let assets = mockStore.mediaAssets;
  if (eventId) {
    assets = assets.filter((m) => m.eventId === eventId);
  }

  return NextResponse.json({ mediaAssets: assets });
}

// PATCH: Approve or Reject a media asset
export async function PATCH(req: NextRequest) {
  const user = getAuthUser(req);

  if (user && !hasRole(user, ['SYSTEM_ADMIN', 'EVENT_ORGANIZER', 'BRIDE_GROOM'])) {
    return NextResponse.json(
      { error: 'Unauthorized.' },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const { mediaId, status } = body;

    if (!mediaId || !['APPROVED', 'REJECTED', 'PENDING'].includes(status)) {
      return NextResponse.json(
        { error: 'Valid mediaId and status required.' },
        { status: 400 }
      );
    }

    const asset = mockStore.mediaAssets.find((m) => m.id === mediaId);
    if (!asset) {
      return NextResponse.json({ error: 'Media asset not found.' }, { status: 404 });
    }

    asset.status = status;

    return NextResponse.json({
      success: true,
      message: `Media asset ${status.toLowerCase()} successfully.`,
      mediaAsset: asset,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update media status.' },
      { status: 500 }
    );
  }
}

// DELETE: Manually purge a rejected file permanently from vault (Bride & Groom request)
export async function DELETE(req: NextRequest) {
  const user = getAuthUser(req);

  if (!hasRole(user, ['SYSTEM_ADMIN', 'EVENT_ORGANIZER', 'BRIDE_GROOM'])) {
    return NextResponse.json(
      { error: 'Unauthorized.' },
      { status: 403 }
    );
  }

  try {
    const { searchParams } = new URL(req.url);
    const mediaId = searchParams.get('mediaId');

    if (!mediaId) {
      return NextResponse.json({ error: 'Media ID required.' }, { status: 400 });
    }

    const index = mockStore.mediaAssets.findIndex((m) => m.id === mediaId);
    if (index === -1) {
      return NextResponse.json({ error: 'Media asset not found.' }, { status: 404 });
    }

    mockStore.mediaAssets.splice(index, 1);

    return NextResponse.json({
      success: true,
      message: 'Media asset permanently deleted from vault.',
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to delete media asset.' },
      { status: 500 }
    );
  }
}
