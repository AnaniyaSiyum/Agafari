export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getAuthUser, hasRole } from '@/lib/auth';
import { mockStore, EventData, UserRecord } from '@/lib/mockData';

// GET: Fetch all wedding events across the platform with full credentials & statistics
export async function GET(req: NextRequest) {
  const user = getAuthUser(req);

  if (user && !hasRole(user, ['SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. System Admin access required.' },
      { status: 403 }
    );
  }

  const enrichedEvents = mockStore.events.map((evt) => {
    const eventUsers = mockStore.users.filter((u) => u.eventId === evt.id);
    const coupleUser = eventUsers.find((u) => u.role === 'BRIDE_GROOM') || {
      fullName: `${evt.brideName} & ${evt.groomName}`,
      email: evt.coupleCredentials?.email || `couple@${evt.slug}.com`,
      temporaryPassword: evt.coupleCredentials?.temporaryPassword || 'couple123',
      role: 'BRIDE_GROOM',
    };
    const organizerUser = eventUsers.find((u) => u.role === 'EVENT_ORGANIZER') || {
      fullName: 'Yonas Planners (Agency)',
      email: `organizer@${evt.slug}.com`,
      temporaryPassword: 'org123',
      role: 'EVENT_ORGANIZER',
    };
    const streamerUser = eventUsers.find((u) => u.role === 'LIVE_STREAMER') || {
      fullName: 'Assigned Streamer',
      email: `streamer@${evt.slug}.com`,
      temporaryPassword: 'stream123',
      role: 'LIVE_STREAMER',
    };
    const scannerUser = eventUsers.find((u) => u.role === 'GATE_SCANNER') || {
      fullName: 'Gate Scanner Team',
      email: `scanner@${evt.slug}.com`,
      temporaryPassword: 'scan123',
      role: 'GATE_SCANNER',
    };

    const totalInvites = mockStore.invitations.filter((i) => i.eventId === evt.id).length;
    const totalWishes = mockStore.wishes.filter((w) => w.eventId === evt.id).length;
    const totalMedia = mockStore.mediaAssets.filter((m) => m.eventId === evt.id).length;

    return {
      ...evt,
      adminApprovalStatus: evt.adminApprovalStatus || 'APPROVED',
      credentials: {
        couple: coupleUser,
        organizer: organizerUser,
        streamer: streamerUser,
        scanner: scannerUser,
      },
      stats: {
        totalInvites,
        totalWishes,
        totalMedia,
      },
    };
  });

  return NextResponse.json({ events: enrichedEvents });
}

// POST: Create a new wedding event (System Admin power)
export async function POST(req: NextRequest) {
  const user = getAuthUser(req);

  if (user && !hasRole(user, ['SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. System Admin access required.' },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const {
      title,
      slug,
      brideName,
      groomName,
      eventDate,
      venueName,
      venueAddress,
      dressCode,
      welcomeMessage,
      coupleEmail,
      youtubeVideoId,
    } = body;

    if (!title || !slug || !brideName || !groomName || !eventDate || !venueName) {
      return NextResponse.json(
        { error: 'Missing required event fields (title, slug, bride, groom, date, venue).' },
        { status: 400 }
      );
    }

    const cleanSlug = slug.toLowerCase().trim().replace(/[^a-z0-9-]/g, '-');

    // Check if slug already exists
    const existing = mockStore.events.find((e) => e.slug === cleanSlug);
    if (existing) {
      return NextResponse.json(
        { error: `An event with slug '${cleanSlug}' already exists.` },
        { status: 400 }
      );
    }

    const tempPassword = `agafari${Math.floor(1000 + Math.random() * 9000)}`;

    const newEvent: EventData = {
      id: `evt-${cleanSlug}`,
      slug: cleanSlug,
      title: title.trim(),
      brideName: brideName.trim(),
      groomName: groomName.trim(),
      eventDate: new Date(eventDate).toISOString(),
      startTime: '14:00',
      venueName: venueName.trim(),
      venueAddress: venueAddress?.trim() || 'Addis Ababa, Ethiopia',
      venueMapUrl: `https://maps.google.com/?q=${encodeURIComponent(venueName)}`,
      dressCode: dressCode?.trim() || 'Traditional Habesha Kemis & Black Tie',
      welcomeMessage: welcomeMessage?.trim() || 'Welcome to our royal wedding celebration!',
      coverImageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop',
      status: 'COMING_SOON',
      adminApprovalStatus: 'APPROVED',
      coupleCredentials: {
        email: coupleEmail?.trim() || `couple@${cleanSlug}.com`,
        temporaryPassword: tempPassword,
      },
      youtubeVideoId: youtubeVideoId || 'dQw4w9WgXcQ',
      isLive: false,
    };

    mockStore.events.unshift(newEvent);

    return NextResponse.json(
      {
        success: true,
        message: 'Wedding event created and licensed successfully!',
        event: newEvent,
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create wedding event.' },
      { status: 500 }
    );
  }
}

// PATCH: Approve / Reject / Update event status or live broadcast
export async function PATCH(req: NextRequest) {
  const user = getAuthUser(req);

  if (user && !hasRole(user, ['SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. System Admin access required.' },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const { eventId, adminApprovalStatus, status, isLive, youtubeVideoId } = body;

    const event = mockStore.events.find((e) => e.id === eventId);
    if (!event) {
      return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
    }

    if (adminApprovalStatus) event.adminApprovalStatus = adminApprovalStatus;
    if (status) event.status = status;
    if (isLive !== undefined) event.isLive = isLive;
    if (youtubeVideoId !== undefined) event.youtubeVideoId = youtubeVideoId;

    return NextResponse.json({
      success: true,
      message: 'Event updated successfully.',
      event,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update event.' },
      { status: 500 }
    );
  }
}

// DELETE: Archive or delete an event
export async function DELETE(req: NextRequest) {
  const user = getAuthUser(req);

  if (user && !hasRole(user, ['SYSTEM_ADMIN'])) {
    return NextResponse.json(
      { error: 'Unauthorized. System Admin access required.' },
      { status: 403 }
    );
  }

  try {
    const { searchParams } = new URL(req.url);
    const eventId = searchParams.get('eventId');

    if (!eventId) {
      return NextResponse.json({ error: 'Event ID required.' }, { status: 400 });
    }

    const index = mockStore.events.findIndex((e) => e.id === eventId);
    if (index === -1) {
      return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
    }

    mockStore.events.splice(index, 1);

    return NextResponse.json({
      success: true,
      message: 'Event deleted successfully.',
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to delete event.' },
      { status: 500 }
    );
  }
}
