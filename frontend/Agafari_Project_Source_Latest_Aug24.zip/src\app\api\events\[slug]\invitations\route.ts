export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getAuthUser, hasRole } from '@/lib/auth';
import { mockStore, InvitationData } from '@/lib/mockData';

// GET: Fetch all unique guest invitations for an event, or single invitation by code
export async function GET(req: NextRequest, { params }: { params: { slug: string } }) {
  const { slug } = params;
  const { searchParams } = new URL(req.url);
  const code = searchParams.get('code');

  const event = mockStore.events.find((e) => e.slug === slug);
  if (!event) {
    return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
  }

  if (code) {
    const invitation = mockStore.invitations.find(
      (i) => i.eventId === event.id && (i.inviteCode === code || i.id === code)
    );
    return NextResponse.json({ invitation: invitation || null });
  }

  const invitations = mockStore.invitations.filter((i) => i.eventId === event.id);
  return NextResponse.json({ invitations });
}

// POST: Generate a new unique guest invitation with headcount quota
export async function POST(req: NextRequest, { params }: { params: { slug: string } }) {
  const { slug } = params;
  const user = getAuthUser(req);

  // In demo / prototype mode, allow couple actions
  if (user && !hasRole(user, ['SYSTEM_ADMIN', 'EVENT_ORGANIZER', 'BRIDE_GROOM'])) {
    return NextResponse.json(
      { error: 'Unauthorized. Couple or Organizer access required.' },
      { status: 403 }
    );
  }

  const event = mockStore.events.find((e) => e.slug === slug);
  if (!event) {
    return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
  }

  try {
    const body = await req.json();
    const { guestName, guestPhone, maxGuests, inviteType } = body;

    if (!guestName || !maxGuests) {
      return NextResponse.json(
        { error: 'Guest name and headcount quota are required.' },
        { status: 400 }
      );
    }

    const uniqueId = `inv-${Date.now().toString().slice(-4)}`;
    const inviteCode = `INV-SD2026-${Math.floor(100 + Math.random() * 900)}`;

    const newInvitation: InvitationData = {
      id: uniqueId,
      eventId: event.id,
      inviteCode,
      guestName: guestName.trim(),
      guestPhone: guestPhone?.trim() || '',
      maxGuests: Number(maxGuests),
      inviteType: inviteType === 'LINK' ? 'LINK' : 'CARD',
      rsvpStatus: 'PENDING',
      scannedCount: 0,
      isScanned: false,
      qrCodeUrl: `/api/qr/${inviteCode}`,
      createdAt: new Date().toISOString(),
    };

    mockStore.invitations.unshift(newInvitation);

    return NextResponse.json(
      {
        success: true,
        message: `${newInvitation.inviteType === 'CARD' ? 'Physical Card QR Pass' : 'Unique Invitation Link'} generated successfully!`,
        invitation: newInvitation,
        shareableUrl: `/event/${slug}?code=${inviteCode}&guest=${encodeURIComponent(guestName.trim())}`,
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to generate unique invitation.' },
      { status: 500 }
    );
  }
}

// PATCH: Gate Security Verification & Atomic Check-In Endpoint
export async function PATCH(req: NextRequest, { params }: { params: { slug: string } }) {
  const { slug } = params;

  const event = mockStore.events.find((e) => e.slug === slug);
  if (!event) {
    return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
  }

  try {
    const body = await req.json();
    const { inviteCode, checkInCount = 1 } = body;

    if (!inviteCode) {
      return NextResponse.json({ error: 'Invite code is required for gate check-in.' }, { status: 400 });
    }

    const codeToMatch = inviteCode.trim().toUpperCase();
    const invitation = mockStore.invitations.find(
      (i) => i.eventId === event.id && i.inviteCode.toUpperCase() === codeToMatch
    );

    if (!invitation) {
      return NextResponse.json(
        {
          status: 'INVALID',
          message: 'Access Denied: Unrecognized or counterfeit QR code signature.',
        },
        { status: 404 }
      );
    }

    // Check if quota is already fully used
    if (invitation.isScanned && invitation.scannedCount >= invitation.maxGuests) {
      return NextResponse.json(
        {
          status: 'ALREADY_SCANNED',
          message: `WARNING: Pass was already fully checked in at ${invitation.scannedAt || 'earlier today'}. Headcount limit reached (${invitation.scannedCount}/${invitation.maxGuests}).`,
          invitation,
        },
        { status: 409 }
      );
    }

    // Perform atomic headcount update
    const increment = Number(checkInCount) || 1;
    invitation.scannedCount = Math.min(invitation.maxGuests, invitation.scannedCount + increment);
    invitation.isScanned = true;
    invitation.scannedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    invitation.rsvpStatus = 'ATTENDING';

    return NextResponse.json({
      status: 'VALID',
      message: `Verified: ${invitation.guestName} (${invitation.scannedCount}/${invitation.maxGuests} Headcount Checked In)`,
      invitation,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to process gate verification.' }, { status: 500 });
  }
}

