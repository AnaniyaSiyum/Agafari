import { createHmac, pbkdf2Sync, randomBytes } from 'crypto';
import { NextRequest } from 'next/server';

export type UserRole = 
  | 'SYSTEM_ADMIN' 
  | 'EVENT_ORGANIZER' 
  | 'BRIDE_GROOM' 
  | 'LIVE_STREAMER' 
  | 'GATE_SCANNER' 
  | 'GUEST';

export interface AuthTokenPayload {
  userId: string;
  email: string;
  role: UserRole;
  eventId?: string | null;
  iat: number;
  exp: number;
}

const JWT_SECRET = process.env.JWT_SECRET || 'agafari_super_secret_jwt_key_2026';

// 1. Password Hashing Utility
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const hash = pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, originalHash] = storedHash.split(':');
  if (!salt || !originalHash) return false;
  const hash = pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return hash === originalHash;
}

// 2. JWT Generation (Base64Url HMAC SHA-256)
function base64UrlEncode(str: string): string {
  return Buffer.from(str)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64UrlDecode(str: string): string {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) {
    str += '=';
  }
  return Buffer.from(str, 'base64').toString();
}

export function generateToken(payload: Omit<AuthTokenPayload, 'iat' | 'exp'>, expiresInHours = 24): string {
  const header = { alg: 'HS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const fullPayload: AuthTokenPayload = {
    ...payload,
    iat: now,
    exp: now + expiresInHours * 3600,
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(fullPayload));
  const signature = createHmac('sha256', JWT_SECRET)
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest('base64url');

  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

export function verifyToken(token: string): AuthTokenPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;

    const [encodedHeader, encodedPayload, signature] = parts;
    const expectedSignature = createHmac('sha256', JWT_SECRET)
      .update(`${encodedHeader}.${encodedPayload}`)
      .digest('base64url');

    if (signature !== expectedSignature) return null;

    const payload: AuthTokenPayload = JSON.parse(base64UrlDecode(encodedPayload));
    const now = Math.floor(Date.now() / 1000);

    if (payload.exp && payload.exp < now) {
      return null; // Expired token
    }

    return payload;
  } catch (error) {
    return null;
  }
}

// 3. Extract Token from Request Header or Cookie
export function getAuthUser(req: NextRequest): AuthTokenPayload | null {
  const authHeader = req.headers.get('authorization');
  let token: string | undefined;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7);
  } else {
    token = req.cookies.get('agafari_token')?.value;
  }

  if (!token) return null;
  return verifyToken(token);
}

// 4. Role Authorization Guard Check
export function hasRole(user: AuthTokenPayload | null, allowedRoles: UserRole[]): boolean {
  if (!user) return false;
  if (user.role === 'SYSTEM_ADMIN') return true; // System Admin has global override
  return allowedRoles.includes(user.role);
}
