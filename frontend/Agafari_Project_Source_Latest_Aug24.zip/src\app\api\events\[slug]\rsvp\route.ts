export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { mockStore } from '@/lib/mockData';

export interface RsvpRecord {
  id: string;
  eventId: string;
  inviteCode?: string;
  guestName: string;
  guestPhone: string;
  attendanceStatus: 'ATTENDING' | 'MAYBE' | 'DECLINED';
  attendingCount: number;
  songRecommendation?: string;
  createdAt: string;
}

// In-memory store for RSVPs
const mockRsvps: RsvpRecord[] = [
  {
    id: 'rsvp-1',
    eventId: 'evt-sara-dawit-2026',
    inviteCode: 'INV-SD2026-001',
    guestName: 'Abebe Kebede & Family',
    guestPhone: '+251911223344',
    attendanceStatus: 'ATTENDING',
    attendingCount: 2,
    songRecommendation: 'Orthodox Wedding Choir - Serege',
    createdAt: new Date().toISOString(),
  },
];

// GET: List RSVPs for an event
export async function GET(req: NextRequest, { params }: { params: { slug: string } }) {
  const { slug } = params;
  const event = mockStore.events.find((e) => e.slug === slug);
  if (!event) {
    return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
  }

  const list = mockRsvps.filter((r) => r.eventId === event.id);
  return NextResponse.json({ rsvps: list });
}

// POST: Submit RSVP response ("Will You Come?")
export async function POST(req: NextRequest, { params }: { params: { slug: string } }) {
  const { slug } = params;
  const event = mockStore.events.find((e) => e.slug === slug);
  if (!event) {
    return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
  }

  try {
    const body = await req.json();
    const status = body.attendanceStatus || body.status;
    const guestName = body.guestName;
    const inviteCode = body.inviteCode;
    const guestPhone = body.guestPhone;
    const attendingCount = body.attendingCount || body.guestCount;

    if (!guestName || !status) {
      return NextResponse.json(
        { error: 'Guest name and attendance status are required.' },
        { status: 400 }
      );
    }

    const newRsvp: RsvpRecord = {
      id: `rsvp-${Date.now()}`,
      eventId: event.id,
      inviteCode: inviteCode || 'GUEST-PUBLIC',
      guestName: guestName.trim(),
      guestPhone: guestPhone?.trim() || '',
      attendanceStatus: status,
      attendingCount: status === 'ATTENDING' ? Number(attendingCount || 1) : 0,
      createdAt: new Date().toISOString(),
    };

    mockRsvps.unshift(newRsvp);

    // If inviteCode matches an existing invitation record, mark it
    if (inviteCode) {
      const inv = mockStore.invitations.find((i) => i.inviteCode === inviteCode);
      if (inv) {
        inv.isScanned = true;
      }
    }

    let feedbackMessage = '✓ Response received!';
    if (status === 'ATTENDING') {
      feedbackMessage = '✓ በደስታ እንጠብቅዎታለን! (Attending Confirmed)';
    } else if (status === 'MAYBE') {
      feedbackMessage = '✓ እናመሰግናለን! ዝርዝሩን በሚወስኑበት ጊዜ ማስተካከል ይችላሉ። (Response Recorded)';
    } else {
      feedbackMessage = '✓ እናመሰግናለን! የሙሽሮቹ መልካም ምኞት ከእርስዎ ጋር ይሁን። (Declined Recorded)';
    }

    return NextResponse.json(
      {
        success: true,
        message: feedbackMessage,
        rsvp: newRsvp,
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to save RSVP.' },
      { status: 500 }
    );
  }
}
