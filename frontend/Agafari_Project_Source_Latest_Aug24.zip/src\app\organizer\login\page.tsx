'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ShieldCheck, Lock, Mail, ArrowRight, AlertCircle, Briefcase } from 'lucide-react';
import { useTranslation, LanguageSwitcher } from '@/lib/i18n';

export default function OrganizerLoginPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const [email, setEmail] = useState('organizer@sara-dawit.com');
  const [password, setPassword] = useState('org123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (res.ok) {
        router.push('/organizer/dashboard');
      } else {
        setError(data.error || t('auth.invalidCreds'));
      }
    } catch (err) {
      setError('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white text-gray-900 flex items-center justify-center p-4 sm:p-6 selection:bg-gold-500 selection:text-black relative font-sans">
      <div className="absolute top-6 right-6">
        <LanguageSwitcher />
      </div>

      <div className="max-w-md w-full glass-panel p-8 md:p-10 rounded-3xl border-2 border-gold-500/40 shadow-xl bg-white">
        <div className="text-center mb-8">
          <img
            src="/branding/artboard-14.png"
            alt="Agafari (አጋፋሪ) Logo"
            className="h-14 w-auto mx-auto mb-4 object-contain"
          />
          <h1 className="font-serif text-2xl md:text-3xl font-bold text-gray-900">
            {t('auth.organizerTitle')}
          </h1>
          <p className="text-xs text-gold-600 font-semibold uppercase tracking-wider mt-1">
            {t('auth.organizerSubtitle')}
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-gray-900 uppercase tracking-wider mb-1.5">
              {t('auth.emailLabel')}
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="organizer@sara-dawit.com"
                className="w-full px-4 py-3 pl-11 rounded-xl border border-gold-500/30 bg-gray-50 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
              />
              <Mail className="w-4 h-4 text-gold-600 absolute left-4 top-3.5" />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-gray-900 uppercase tracking-wider mb-1.5">
              {t('auth.passwordLabel')}
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 pl-11 rounded-xl border border-gold-500/30 bg-gray-50 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
              />
              <Lock className="w-4 h-4 text-gold-600 absolute left-4 top-3.5" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-black hover:bg-gray-800 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 mt-4 border border-gold-500/40 disabled:opacity-50"
          >
            {loading ? t('auth.signingIn') : t('auth.signInBtn')}
            <ArrowRight className="w-4 h-4 text-gold-400" />
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-gray-100 text-center">
          <p className="text-[11px] text-gray-500 font-semibold mb-2">Demo Organizer Login:</p>
          <div className="text-[11px] font-mono text-gray-900 font-bold">
            organizer@sara-dawit.com / org123
          </div>
        </div>
      </div>
    </div>
  );
}
