'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Heart, 
  Eye, 
  CheckCircle2, 
  XCircle, 
  Trash2, 
  ExternalLink, 
  Video, 
  Image as ImageIcon, 
  Download, 
  LogOut, 
  Sparkles, 
  Calendar, 
  MapPin, 
  Users, 
  Film, 
  Radio,
  Send,
  Clock,
  Check,
  Plus,
  Copy,
  Share2,
  QrCode,
  UserCheck,
  ScanLine,
  Crown,
  ShieldCheck,
  Printer,
  Search,
  Menu,
  X,
  Settings,
  Shirt,
  Upload,
  Save,
  Music
} from 'lucide-react';
import { useTranslation, LanguageSwitcher } from '@/lib/i18n';

interface EventData {
  id: string;
  slug: string;
  title: string;
  brideName: string;
  groomName: string;
  eventDate: string;
  startTime?: string;
  venueName: string;
  venueAddress: string;
  venueMapUrl: string;
  dressCode?: string;
  welcomeMessage?: string;
  coverImageUrl?: string;
  status: string;
}

interface WishData {
  id: string;
  eventId: string;
  senderName: string;
  message: string;
  mediaType?: 'TEXT' | 'VIDEO';
  videoUrl?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

interface MediaAssetData {
  id: string;
  eventId: string;
  uploaderName: string;
  mediaType: 'VIDEO' | 'IMAGE';
  cdnUrl: string;
  thumbnailUrl?: string;
  caption: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

interface InvitationRecord {
  id: string;
  inviteCode: string;
  guestName: string;
  guestPhone: string;
  maxGuests: number;
  inviteType: 'CARD' | 'LINK';
  rsvpStatus: 'ATTENDING' | 'DECLINED' | 'PENDING';
  attendingHeadcount?: number;
  scannedCount: number;
  isScanned: boolean;
  qrCodeUrl: string;
  createdAt?: string;
}

interface TeamMember {
  id: string;
  fullName: string;
  email: string;
  role: 'LIVE_STREAMER' | 'GATE_SCANNER';
}

export default function CoupleDashboardPage() {
  const { t } = useTranslation();
  const [event, setEvent] = useState<EventData | null>(null);
  const [wishes, setWishes] = useState<WishData[]>([]);
  const [mediaAssets, setMediaAssets] = useState<MediaAssetData[]>([]);
  const [invitations, setInvitations] = useState<InvitationRecord[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);

  // Active Sidebar Navigation Tab ('SETUP' | 'INVITES' | 'STAFF' | 'MEDIA' | 'BROADCAST' | 'THANK_YOU')
  const [activeTab, setActiveTab] = useState<'SETUP' | 'INVITES' | 'STAFF' | 'MEDIA' | 'BROADCAST' | 'THANK_YOU'>('INVITES');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // 0. Wedding Setup / Creation State
  const [brideName, setBrideName] = useState('Sara Tadesse');
  const [groomName, setGroomName] = useState('Dawit Alemayehu');
  const [coverImageUrl, setCoverImageUrl] = useState('https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop');
  const [coverImageFile, setCoverImageFile] = useState<File | null>(null);
  const [venueName, setVenueName] = useState('Sheraton Addis Luxury Ballroom');
  const [venueAddress, setVenueAddress] = useState('Taitu Street, Addis Ababa, Ethiopia');
  const [venueMapUrl, setVenueMapUrl] = useState('https://maps.google.com/?q=Sheraton+Addis');
  const [eventDate, setEventDate] = useState('2026-08-15');
  const [startTime, setStartTime] = useState('14:00');
  const [dressCode, setDressCode] = useState('Traditional Habesha Kemis & Black Tie');
  const [welcomeMessage, setWelcomeMessage] = useState('We are overjoyed to celebrate the beginning of our forever journey with our beloved family and friends!');
  const [backgroundMusicUrl, setBackgroundMusicUrl] = useState('https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=wedding-march-11226.mp3');
  const [backgroundMusicTitle, setBackgroundMusicTitle] = useState('ለይኩኑ (Leykunu Orthodox Wedding Mezmur)');
  const [backgroundAudioFile, setBackgroundAudioFile] = useState<File | null>(null);
  const [savingSetup, setSavingSetup] = useState(false);
  const [setupSuccessMsg, setSetupSuccessMsg] = useState('');

  const handleAudioFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setBackgroundAudioFile(file);
      const url = URL.createObjectURL(file);
      setBackgroundMusicUrl(url);
    }
  };

  const handleCoverImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCoverImageFile(file);
      const url = URL.createObjectURL(file);
      setCoverImageUrl(url);
    }
  };

  // Search & Filter States for Guests
  const [guestSearchQuery, setGuestSearchQuery] = useState('');
  const [guestRsvpFilter, setGuestRsvpFilter] = useState<'ALL' | 'ATTENDING' | 'DECLINED' | 'PENDING'>('ALL');
  const [selectedInviteForQr, setSelectedInviteForQr] = useState<InvitationRecord | null>(null);

  // 1. Guest Invitation Creation State
  const [inviteMode, setInviteMode] = useState<'CARD' | 'LINK'>('CARD');
  const [inviteGuestName, setInviteGuestName] = useState('');
  const [inviteGuestPhone, setInviteGuestPhone] = useState('');
  const [inviteMaxGuests, setInviteMaxGuests] = useState(2);
  const [inviteSuccess, setInviteSuccess] = useState('');
  const [copiedCode, setCopiedCode] = useState('');
  const [generatingInvite, setGeneratingInvite] = useState(false);

  // 2. Staff Role Assignment State
  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffPassword, setStaffPassword] = useState('pass123');
  const [staffRole, setStaffRole] = useState<'LIVE_STREAMER' | 'GATE_SCANNER'>('GATE_SCANNER');
  const [assigningStaff, setAssigningStaff] = useState(false);
  const [staffSuccessMsg, setStaffSuccessMsg] = useState('');

  // 3. Media Moderation Sub-Tab
  const [mediaFilterTab, setMediaFilterTab] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');

  // 4. Wedding Day Broadcast State
  const [broadcastMessage, setBroadcastMessage] = useState(
    "Warm greetings from Sara & Dawit! Our wedding celebration is this Saturday at Sheraton Addis. Gate check-in starts promptly at 1:00 PM. Please have your QR entrance code ready at the gate!"
  );
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);
  const [broadcasting, setBroadcasting] = useState(false);

  // 5. Post-Wedding Thank You State
  const [thankYouMessage, setThankYouMessage] = useState(
    "Dearest family and friends, thank you from the bottom of our hearts for being part of our special day. Your love, joyous dances, and heartfelt prayers made our wedding unforgettable! - Sara & Dawit"
  );
  const [thankYouImageUrl, setThankYouImageUrl] = useState(
    "https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop"
  );
  const [thankYouImageFile, setThankYouImageFile] = useState<File | null>(null);
  const [thankYouSent, setThankYouSent] = useState(false);
  const [sendingThankYou, setSendingThankYou] = useState(false);

  const handleThankYouImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setThankYouImageFile(file);
      const url = URL.createObjectURL(file);
      setThankYouImageUrl(url);
    }
  };

  useEffect(() => {
    async function loadCoupleData() {
      try {
        const [eventRes, wishesRes, mediaRes, invitesRes, teamRes] = await Promise.all([
          fetch('/api/events/sara-and-dawit-2026'),
          fetch('/api/events/sara-and-dawit-2026/wishes'),
          fetch('/api/events/sara-and-dawit-2026/media'),
          fetch('/api/events/sara-and-dawit-2026/invitations'),
          fetch('/api/events/sara-and-dawit-2026/team'),
        ]);

        if (eventRes.ok) {
          const data = await eventRes.json();
          setEvent(data.event);
          if (data.event) {
            setBrideName(data.event.brideName || 'Sara Tadesse');
            setGroomName(data.event.groomName || 'Dawit Alemayehu');
            setCoverImageUrl(data.event.coverImageUrl || 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop');
            setVenueName(data.event.venueName || 'Sheraton Addis Luxury Ballroom');
            setVenueAddress(data.event.venueAddress || 'Taitu Street, Addis Ababa, Ethiopia');
            setVenueMapUrl(data.event.venueMapUrl || 'https://maps.google.com/?q=Sheraton+Addis');
            setDressCode(data.event.dressCode || 'Traditional Habesha Kemis & Black Tie');
            setWelcomeMessage(data.event.welcomeMessage || 'We are overjoyed to celebrate our wedding with you!');
            if (data.event.backgroundMusicUrl) {
              setBackgroundMusicUrl(data.event.backgroundMusicUrl);
            }
            if (data.event.backgroundMusicTitle) {
              setBackgroundMusicTitle(data.event.backgroundMusicTitle);
            }
            if (data.event.eventDate) {
              setEventDate(data.event.eventDate.split('T')[0]);
            }
            if (data.event.startTime) {
              setStartTime(data.event.startTime);
            }
          }
        }

        if (wishesRes.ok) {
          const data = await wishesRes.json();
          setWishes(data.wishes || []);
        }

        if (mediaRes.ok) {
          const data = await mediaRes.json();
          setMediaAssets(data.mediaAssets || []);
        }

        if (invitesRes.ok) {
          const data = await invitesRes.json();
          setInvitations(data.invitations || []);
        }

        if (teamRes.ok) {
          const data = await teamRes.json();
          setTeamMembers(data.teamMembers || []);
        }
      } catch (err) {
        console.error('Failed to load couple dashboard data:', err);
      } finally {
        setLoading(false);
      }
    }

    loadCoupleData();
  }, []);

  // Save / Update Wedding Celebration Details (Business Logic Step 1)
  const handleSaveWeddingSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brideName.trim() || !groomName.trim()) return;

    setSavingSetup(true);
    try {
      const res = await fetch('/api/events/sara-and-dawit-2026', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          brideName,
          groomName,
          coverImageUrl,
          venueName,
          venueAddress,
          venueMapUrl,
          eventDate: `${eventDate}T${startTime}:00.000Z`,
          startTime,
          dressCode,
          welcomeMessage,
          backgroundMusicUrl,
          backgroundMusicTitle,
        }),
      });

      const data = await res.json();
      if (res.ok && data.event) {
        setEvent(data.event);
        setSetupSuccessMsg(t('coupleDashboard.setup.successMsg'));
        setTimeout(() => setSetupSuccessMsg(''), 5000);
      }
    } catch (err) {
      console.error('Failed to save wedding details:', err);
    } finally {
      setSavingSetup(false);
    }
  };

  // Generate Unique Invitation
  const handleGenerateInvitation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteGuestName || !event) return;

    setGeneratingInvite(true);
    try {
      const res = await fetch(`/api/events/${event.slug}/invitations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestName: inviteGuestName,
          guestPhone: inviteGuestPhone,
          maxGuests: inviteMaxGuests,
          inviteType: inviteMode,
        }),
      });

      const data = await res.json();

      if (res.ok && data.invitation) {
        setInvitations((prev) => [data.invitation, ...prev]);
        setInviteSuccess(
          inviteMode === 'CARD'
            ? `Generated Printable Card QR Pass for "${inviteGuestName}"!`
            : `Generated Digital Link for "${inviteGuestName}"!`
        );
        setInviteGuestName('');
        setInviteGuestPhone('');
        setTimeout(() => setInviteSuccess(''), 5000);
      }
    } catch (err) {
      console.error('Failed to generate invitation:', err);
    } finally {
      setGeneratingInvite(false);
    }
  };

  // Assign Team Member
  const handleAssignStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffName || !staffEmail || !staffPassword || !event) return;

    setAssigningStaff(true);
    try {
      const res = await fetch(`/api/events/${event.slug}/team`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: staffName,
          email: staffEmail,
          password: staffPassword,
          role: staffRole,
        }),
      });

      const data = await res.json();
      if (res.ok && data.teamMember) {
        setTeamMembers((prev) => [...prev, data.teamMember]);
        setStaffSuccessMsg(`Staff member ${data.teamMember.fullName} assigned successfully!`);
        setStaffName('');
        setStaffEmail('');
        setTimeout(() => setStaffSuccessMsg(''), 5000);
      }
    } catch (err) {
      console.error('Failed to assign staff:', err);
    } finally {
      setAssigningStaff(false);
    }
  };

  const handleDeleteStaff = async (userId: string) => {
    if (!confirm('Remove this staff assignment from your wedding crew?')) return;
    if (!event) return;

    try {
      const res = await fetch(`/api/events/${event.slug}/team?userId=${userId}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setTeamMembers((prev) => prev.filter((m) => m.id !== userId));
      }
    } catch (err) {
      console.error('Failed to delete staff:', err);
    }
  };

  const handleCopyLink = (code: string) => {
    const inv = invitations.find((i) => i.inviteCode === code);
    const guestParam = inv?.guestName ? `&guest=${encodeURIComponent(inv.guestName)}` : '';
    const fullUrl = `${window.location.origin}/event/${event?.slug || 'sara-and-dawit-2026'}?code=${code}${guestParam}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(''), 3000);
  };

  const handleMediaStatus = async (mediaId: string, status: 'APPROVED' | 'REJECTED') => {
    try {
      const res = await fetch('/api/organizer/media', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mediaId, status }),
      });

      if (res.ok) {
        setMediaAssets((prev) =>
          prev.map((m) => (m.id === mediaId ? { ...m, status } : m))
        );
      }
    } catch (err) {
      console.error('Failed to update media status:', err);
    }
  };

  const handleSendBroadcast = () => {
    setBroadcasting(true);
    setTimeout(() => {
      setBroadcasting(false);
      setBroadcastSuccess(true);
      setTimeout(() => setBroadcastSuccess(false), 4000);
    }, 1000);
  };

  const handleSendThankYou = () => {
    setSendingThankYou(true);
    setTimeout(() => {
      setSendingThankYou(false);
      setThankYouSent(true);
      setTimeout(() => setThankYouSent(false), 5000);
    }, 1200);
  };

  // Metrics Calculations
  const totalInvited = invitations.length;
  const confirmedAttending = invitations.filter((i) => i.rsvpStatus === 'ATTENDING').length;
  const declinedCount = invitations.filter((i) => i.rsvpStatus === 'DECLINED').length;
  const pendingRsvpCount = invitations.filter((i) => i.rsvpStatus === 'PENDING' || !i.rsvpStatus).length;
  const totalHeadcount = invitations
    .filter((i) => i.rsvpStatus === 'ATTENDING')
    .reduce((acc, curr) => acc + (curr.attendingHeadcount || curr.maxGuests || 1), 0);

  // Filtered Invitations
  const filteredInvitations = invitations.filter((inv) => {
    const matchesSearch = inv.guestName.toLowerCase().includes(guestSearchQuery.toLowerCase()) ||
                          inv.inviteCode.toLowerCase().includes(guestSearchQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (guestRsvpFilter === 'ALL') return true;
    if (guestRsvpFilter === 'ATTENDING') return inv.rsvpStatus === 'ATTENDING';
    if (guestRsvpFilter === 'DECLINED') return inv.rsvpStatus === 'DECLINED';
    if (guestRsvpFilter === 'PENDING') return inv.rsvpStatus === 'PENDING' || !inv.rsvpStatus;
    return true;
  });

  const filteredMedia = mediaAssets.filter((m) => {
    if (mediaFilterTab === 'ALL') return true;
    return m.status === mediaFilterTab;
  });

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white text-gray-900 flex font-sans selection:bg-gold-500 selection:text-black">
      
      {/* =========================================================================
          1. STRUCTURED LUXURY LEFT SIDEBAR
         ========================================================================= */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-72 bg-gray-950 text-white flex flex-col justify-between border-r border-gold-500/30 transition-transform duration-300 ease-in-out
        md:translate-x-0 ${mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div>
          {/* Couple Wedding Brand Header */}
          <div className="p-6 border-b border-gold-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src="/branding/artboard-13.png"
                  alt="Agafari (አጋፋሪ) Logo"
                  className="h-10 w-auto object-contain"
                />
                <div>
                  <h2 className="font-serif font-bold text-base text-gold-400 tracking-wide">
                    {brideName} & {groomName}
                  </h2>
                  <span className="text-[10px] text-gold-400 font-semibold uppercase tracking-widest block">
                    {t('coupleDashboard.header.badge')}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setMobileSidebarOpen(false)}
                className="md:hidden p-1 text-white/70 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Wedding Date & Venue Tag */}
            <div className="mt-4 p-3 rounded-xl bg-black/20 border border-white/5 text-[11px] space-y-1">
              <div className="flex items-center gap-2 text-[#D4AF37]">
                <Calendar className="w-3.5 h-3.5 shrink-0" />
                <span>{eventDate} at {startTime}</span>
              </div>
              <div className="flex items-center gap-2 text-white/70">
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{venueName}</span>
              </div>
            </div>
          </div>

          {/* Navigation Menu Links */}
          <nav className="p-4 space-y-1.5 text-xs font-semibold">
            
            {/* 0. Wedding Setup & Details */}
            <button
              onClick={() => { setActiveTab('SETUP'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'SETUP'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Settings className="w-4 h-4 text-gold-400" />
                <span>{t('coupleDashboard.tabs.setup')}</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                ✓
              </span>
            </button>

            {/* 1. Guest Invites */}
            <button
              onClick={() => { setActiveTab('INVITES'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'INVITES'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <QrCode className="w-4 h-4 text-gold-400" />
                <span>{t('coupleDashboard.tabs.invites')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {invitations.length}
              </span>
            </button>

            {/* 2. Staff Roles */}
            <button
              onClick={() => { setActiveTab('STAFF'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'STAFF'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Users className="w-4 h-4 text-gold-400" />
                <span>{t('coupleDashboard.tabs.staff')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {teamMembers.length}
              </span>
            </button>

            {/* 3. Media Moderation */}
            <button
              onClick={() => { setActiveTab('MEDIA'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'MEDIA'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Film className="w-4 h-4 text-gold-400" />
                <span>{t('coupleDashboard.tabs.media')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {mediaAssets.length}
              </span>
            </button>

            {/* 4. Broadcast */}
            <button
              onClick={() => { setActiveTab('BROADCAST'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeTab === 'BROADCAST'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Radio className="w-4 h-4 text-gold-400" />
              <span>{t('coupleDashboard.tabs.broadcast')}</span>
            </button>

            {/* 5. Thank You */}
            <button
              onClick={() => { setActiveTab('THANK_YOU'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeTab === 'THANK_YOU'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4 text-gold-400" />
              <span>{t('coupleDashboard.tabs.thankYou')}</span>
            </button>
          </nav>
        </div>

        {/* Sidebar Footer Controls */}
        <div className="p-4 border-t border-white/10 space-y-2">
          <Link
            href="/event/sara-and-dawit-2026"
            target="_blank"
            className="w-full py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
          >
            <Eye className="w-4 h-4 text-gold-400" />
            <span>{t('nav.openPublicPage')}</span>
          </Link>

          <Link
            href="/couple/login"
            className="w-full py-2 px-3 rounded-xl hover:bg-rose-950/40 text-rose-300 text-xs font-medium flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{t('nav.signOut')}</span>
          </Link>
        </div>
      </aside>

      {/* Backdrop for Mobile Drawer */}
      {mobileSidebarOpen && (
        <div
          onClick={() => setMobileSidebarOpen(false)}
          className="md:hidden fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
        />
      )}

      {/* =========================================================================
          2. MAIN EXECUTIVE WORKSPACE AREA
         ========================================================================= */}
      <div className="flex-1 md:pl-72 flex flex-col min-w-0">
        
        {/* Top Header Bar */}
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-gold-500/30 px-6 py-4 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="md:hidden p-2 rounded-xl bg-gray-50 border border-gold-500/30 text-gray-900"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              <div className="text-[11px] text-gold-600 font-semibold uppercase tracking-wider">
                {t('coupleDashboard.header.badge')}
              </div>
              <h1 className="font-serif font-bold text-lg sm:text-xl text-gray-900">
                {activeTab === 'SETUP' && t('coupleDashboard.setup.title')}
                {activeTab === 'INVITES' && t('coupleDashboard.invites.tableTitle')}
                {activeTab === 'STAFF' && t('coupleDashboard.staff.title')}
                {activeTab === 'MEDIA' && t('coupleDashboard.media.title')}
                {activeTab === 'BROADCAST' && t('coupleDashboard.broadcast.title')}
                {activeTab === 'THANK_YOU' && t('coupleDashboard.thankYou.title')}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 ml-auto">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-black text-gold-400 text-xs font-bold shadow-sm border border-gold-500/30">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{confirmedAttending} {t('coupleDashboard.header.guestsAttending')}</span>
            </div>

            <LanguageSwitcher />
          </div>
        </header>

        {/* Workspace Body Content */}
        <main className="p-6 max-w-6xl w-full mx-auto space-y-6">
          
          {/* =========================================================================
              TAB 0: WEDDING CELEBRATION PROFILE & SETUP (BUSINESS LOGIC STEP 1)
             ========================================================================= */}
          {activeTab === 'SETUP' && (
            <div className="space-y-6">
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-gold-500/20">
                  <div>
                    <h2 className="font-serif font-bold text-lg sm:text-xl text-gray-900 flex items-center gap-2">
                      <Settings className="w-5 h-5 text-gold-500" />
                      {t('coupleDashboard.setup.title')}
                    </h2>
                    <p className="text-xs text-gray-600 font-light mt-0.5">
                      {t('coupleDashboard.setup.subtitle')}
                    </p>
                  </div>

                  <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700" /> {t('coupleDashboard.setup.platformActive')}
                  </span>
                </div>

                {setupSuccessMsg && (
                  <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span>{setupSuccessMsg}</span>
                  </div>
                )}

                <form onSubmit={handleSaveWeddingSetup} className="space-y-6">
                  {/* Row 1: Bride & Groom Names */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.brideName')}
                      </label>
                      <input
                        type="text"
                        required
                        value={brideName}
                        onChange={(e) => setBrideName(e.target.value)}
                        placeholder="e.g. Sara Tadesse"
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500 font-serif font-bold text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.groomName')}
                      </label>
                      <input
                        type="text"
                        required
                        value={groomName}
                        onChange={(e) => setGroomName(e.target.value)}
                        placeholder="e.g. Dawit Alemayehu"
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500 font-serif font-bold text-sm"
                      />
                    </div>
                  </div>

                  {/* Row 2: Best Photo of Couple (Direct Device File Upload) */}
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('coupleDashboard.setup.photoLabel')}
                    </label>
                    <label className="border-2 border-dashed border-gold-500/30 hover:border-gold-500 rounded-2xl p-5 text-center cursor-pointer transition-all block bg-gray-50 group">
                      <div className="flex flex-col items-center justify-center gap-1.5">
                        <div className="w-10 h-10 rounded-xl bg-black text-gold-400 flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
                          <Upload className="w-5 h-5 text-gold-400" />
                        </div>
                        <div className="font-bold text-xs text-gray-900">
                          {coverImageFile ? `✓ Selected: ${coverImageFile.name}` : t('coupleDashboard.setup.photoPrompt')}
                        </div>
                        <p className="text-[10px] text-gray-500 font-light">
                          {t('coupleDashboard.setup.photoHelp')}
                        </p>
                      </div>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleCoverImageChange}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* Row 3: Location of the Wedding */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.venueName')}
                      </label>
                      <input
                        type="text"
                        required
                        value={venueName}
                        onChange={(e) => setVenueName(e.target.value)}
                        placeholder="Sheraton Addis Luxury Ballroom"
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.venueAddress')}
                      </label>
                      <input
                        type="text"
                        required
                        value={venueAddress}
                        onChange={(e) => setVenueAddress(e.target.value)}
                        placeholder="Taitu Street, Addis Ababa"
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.mapLink')}
                      </label>
                      <input
                        type="text"
                        value={venueMapUrl}
                        onChange={(e) => setVenueMapUrl(e.target.value)}
                        placeholder="https://maps.google.com/..."
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                      />
                    </div>
                  </div>

                  {/* Row 4: Date & Time of Wedding */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.eventDate')}
                      </label>
                      <input
                        type="date"
                        required
                        value={eventDate}
                        onChange={(e) => setEventDate(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.startTime')}
                      </label>
                      <input
                        type="time"
                        required
                        value={startTime}
                        onChange={(e) => setStartTime(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                      />
                    </div>
                  </div>

                  {/* Row 5: Dress Code & Welcome Message */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.dressCode')}
                      </label>
                      <input
                        type="text"
                        value={dressCode}
                        onChange={(e) => setDressCode(e.target.value)}
                        placeholder="e.g. Traditional Habesha Kemis & Black Tie"
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-gray-900 mb-1">
                        {t('coupleDashboard.setup.welcomeMsg')}
                      </label>
                      <input
                        type="text"
                        value={welcomeMessage}
                        onChange={(e) => setWelcomeMessage(e.target.value)}
                        placeholder="We are overjoyed to celebrate our wedding with you!"
                        className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                      />
                    </div>
                  </div>

                  {/* Row 6: Upload Real Audio File (MP3 / WAV / M4A) */}
                  <div className="border-t border-gold-500/20 pt-4">
                    <label className="block text-[11px] font-bold text-gray-900 mb-2">
                      🎵 Upload Real Wedding Mezmur / Song File (.MP3, .WAV, .M4A)
                    </label>
                    <label className="border-2 border-dashed border-gold-500/30 hover:border-gold-500 rounded-2xl p-6 text-center cursor-pointer transition-all block bg-gray-50 group shadow-sm">
                      <div className="flex flex-col items-center justify-center gap-2">
                        <div className="w-12 h-12 rounded-2xl bg-black text-gold-400 flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
                          <Music className="w-6 h-6 text-gold-400" />
                        </div>
                        <div className="font-bold text-xs sm:text-sm text-gray-900">
                          {backgroundAudioFile ? `✓ Selected Audio File: ${backgroundAudioFile.name}` : 'Click or Drag to Upload Real Audio File (MP3, WAV, M4A)'}
                        </div>
                        <p className="text-[10px] text-gray-500 font-light">
                          Select a real audio file from your phone or computer.
                        </p>
                      </div>
                      <input
                        type="file"
                        accept="audio/*"
                        onChange={handleAudioFileChange}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="flex justify-end pt-4 border-t border-gray-100">
                    <button
                      type="submit"
                      disabled={savingSetup}
                      className="px-8 py-3.5 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-md transition-all flex items-center gap-2 border border-gold-500/40"
                    >
                      <Save className="w-4 h-4 text-gold-400" />
                      <span>{savingSetup ? t('coupleDashboard.setup.savingBtn') : t('coupleDashboard.setup.saveBtn')}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 1: GUEST INVITATIONS & QR PASS MANAGEMENT
             ========================================================================= */}
          {activeTab === 'INVITES' && (
            <div className="space-y-6">
              
              {/* Top Executive KPI Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-2xl bg-white border border-gold-500/30 shadow-sm">
                  <div className="text-[11px] text-gray-500 font-bold uppercase tracking-wider">{t('coupleDashboard.invites.kpiTotal')}</div>
                  <div className="text-3xl font-serif font-bold text-gray-900 mt-1">{totalInvited}</div>
                  <div className="text-[11px] text-gray-500 mt-0.5">Card QRs + Direct Links</div>
                </div>

                <div className="p-5 rounded-2xl bg-white border border-gold-500/30 shadow-sm">
                  <div className="text-[11px] text-emerald-800 font-bold uppercase tracking-wider">{t('coupleDashboard.invites.kpiAttending')}</div>
                  <div className="text-3xl font-serif font-bold text-emerald-800 mt-1">
                    {confirmedAttending} <span className="text-sm font-normal text-gray-500">({totalHeadcount} {t('common.heads')})</span>
                  </div>
                  <div className="text-[11px] text-emerald-700 font-medium mt-0.5">✓ {t('coupleDashboard.invites.attending')}</div>
                </div>

                <div className="p-5 rounded-2xl bg-white border border-gold-500/30 shadow-sm">
                  <div className="text-[11px] text-amber-800 font-bold uppercase tracking-wider">{t('coupleDashboard.invites.kpiPending')}</div>
                  <div className="text-3xl font-serif font-bold text-amber-800 mt-1">{pendingRsvpCount}</div>
                  <div className="text-[11px] text-amber-700 font-medium mt-0.5">{t('coupleDashboard.invites.pendingRsvp')}</div>
                </div>

                <div className="p-5 rounded-2xl bg-white border border-gold-500/30 shadow-sm">
                  <div className="text-[11px] text-rose-800 font-bold uppercase tracking-wider">{t('coupleDashboard.invites.kpiDeclined')}</div>
                  <div className="text-3xl font-serif font-bold text-rose-800 mt-1">{declinedCount}</div>
                  <div className="text-[11px] text-rose-700 font-medium mt-0.5">{t('coupleDashboard.invites.declined')}</div>
                </div>
              </div>

              {/* Invitation Generator Card */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-gray-100">
                  <div>
                    <h2 className="font-serif font-bold text-lg sm:text-xl text-gray-900">
                      {t('coupleDashboard.invites.genTitle')}
                    </h2>
                    <p className="text-xs text-gray-500 font-light mt-0.5">
                      {t('coupleDashboard.invites.genSubtitle')}
                    </p>
                  </div>

                  {/* Dual Mode Switcher */}
                  <div className="flex items-center p-1 rounded-xl bg-gray-50 border border-gold-500/30 text-xs">
                    <button
                      type="button"
                      onClick={() => setInviteMode('CARD')}
                      className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                        inviteMode === 'CARD'
                          ? 'bg-black text-gold-400 shadow-sm'
                          : 'text-gray-700 hover:text-gray-900'
                      }`}
                    >
                      <Printer className="w-3.5 h-3.5" /> {t('coupleDashboard.invites.modeCard')}
                    </button>
                    <button
                      type="button"
                      onClick={() => setInviteMode('LINK')}
                      className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                        inviteMode === 'LINK'
                          ? 'bg-black text-gold-400 shadow-sm'
                          : 'text-gray-700 hover:text-gray-900'
                      }`}
                    >
                      <Share2 className="w-3.5 h-3.5" /> {t('coupleDashboard.invites.modeLink')}
                    </button>
                  </div>
                </div>

                {inviteSuccess && (
                  <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span>{inviteSuccess}</span>
                  </div>
                )}

                <form onSubmit={handleGenerateInvitation} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('coupleDashboard.invites.guestName')}
                    </label>
                    <input
                      type="text"
                      required
                      value={inviteGuestName}
                      onChange={(e) => setInviteGuestName(e.target.value)}
                      placeholder="e.g. Uncle Bekele & Family"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('coupleDashboard.invites.quota')}
                    </label>
                    <select
                      value={inviteMaxGuests}
                      onChange={(e) => setInviteMaxGuests(Number(e.target.value))}
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500 font-medium"
                    >
                      <option value={1}>1 {t('common.guest')} (Single Entry)</option>
                      <option value={2}>2 {t('common.guests')} (Couple VIP Entry)</option>
                      <option value={3}>3 {t('common.guests')} (Family Entry)</option>
                      <option value={4}>4 {t('common.guests')} (Family VIP Entry)</option>
                      <option value={5}>5+ {t('common.guests')} (Full Family Pass)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('coupleDashboard.invites.phone')}
                    </label>
                    <input
                      type="text"
                      value={inviteGuestPhone}
                      onChange={(e) => setInviteGuestPhone(e.target.value)}
                      placeholder="+251 91 122 3344"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div className="sm:col-span-3 flex justify-end pt-2">
                    <button
                      type="submit"
                      disabled={generatingInvite}
                      className="px-6 py-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-md transition-all flex items-center gap-2 border border-gold-500/40"
                    >
                      <Plus className="w-4 h-4 text-gold-400" />
                      <span>
                        {generatingInvite
                          ? t('common.loading')
                          : inviteMode === 'CARD'
                          ? t('coupleDashboard.invites.genCardBtn')
                          : t('coupleDashboard.invites.genLinkBtn')}
                      </span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Guest Directory & RSVP Table */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
                  <div>
                    <h2 className="font-serif font-bold text-lg text-gray-900">
                      {t('coupleDashboard.invites.tableTitle')} ({invitations.length})
                    </h2>
                    <p className="text-xs text-gray-500 font-light">
                      {t('coupleDashboard.invites.tableSubtitle')}
                    </p>
                  </div>

                  {/* Search Bar & Filter */}
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={guestSearchQuery}
                        onChange={(e) => setGuestSearchQuery(e.target.value)}
                        placeholder={t('common.search')}
                        className="pl-8 pr-3 py-1.5 rounded-xl border border-gold-500/30 text-xs text-gray-900 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gold-500"
                      />
                    </div>

                    <div className="flex items-center gap-1 text-[11px]">
                      <button
                        onClick={() => setGuestRsvpFilter('ALL')}
                        className={`px-3 py-1 rounded-lg font-bold border transition-all ${
                          guestRsvpFilter === 'ALL'
                            ? 'bg-black text-gold-400 border-black'
                            : 'bg-white text-gray-900 border-gray-200 hover:bg-gray-50'
                        }`}
                      >
                        {t('common.all')}
                      </button>
                      <button
                        onClick={() => setGuestRsvpFilter('ATTENDING')}
                        className={`px-3 py-1 rounded-lg font-bold border transition-all ${
                          guestRsvpFilter === 'ATTENDING'
                            ? 'bg-emerald-800 text-white border-emerald-800'
                            : 'bg-white text-emerald-800 border-gray-200 hover:bg-emerald-50'
                        }`}
                      >
                        {t('coupleDashboard.invites.attending')} ({confirmedAttending})
                      </button>
                      <button
                        onClick={() => setGuestRsvpFilter('PENDING')}
                        className={`px-3 py-1 rounded-lg font-bold border transition-all ${
                          guestRsvpFilter === 'PENDING'
                            ? 'bg-amber-800 text-white border-amber-800'
                            : 'bg-white text-amber-800 border-gray-200 hover:bg-amber-50'
                        }`}
                      >
                        {t('coupleDashboard.invites.pendingRsvp')} ({pendingRsvpCount})
                      </button>
                      <button
                        onClick={() => setGuestRsvpFilter('DECLINED')}
                        className={`px-3 py-1 rounded-lg font-bold border transition-all ${
                          guestRsvpFilter === 'DECLINED'
                            ? 'bg-rose-800 text-white border-rose-800'
                            : 'bg-white text-rose-800 border-gray-200 hover:bg-rose-50'
                        }`}
                      >
                        {t('coupleDashboard.invites.declined')} ({declinedCount})
                      </button>
                    </div>
                  </div>
                </div>

                {/* Table */}
                {filteredInvitations.length === 0 ? (
                  <div className="text-center py-12 text-gray-500 text-xs">
                    No guest invitations match your search filter.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-gray-100 text-[10px] text-gray-500 font-bold uppercase tracking-wider bg-gray-50">
                          <th className="py-3 px-4 rounded-l-xl">{t('coupleDashboard.invites.thGuest')}</th>
                          <th className="py-3 px-4">{t('coupleDashboard.invites.thType')}</th>
                          <th className="py-3 px-4">{t('coupleDashboard.invites.thQuota')}</th>
                          <th className="py-3 px-4">{t('coupleDashboard.invites.thRsvp')}</th>
                          <th className="py-3 px-4">{t('coupleDashboard.invites.thGate')}</th>
                          <th className="py-3 px-4 text-right rounded-r-xl">{t('coupleDashboard.invites.thActions')}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {filteredInvitations.map((inv) => (
                          <tr key={inv.id} className="hover:bg-gray-50/80 transition-colors">
                            <td className="py-3.5 px-4">
                              <div className="font-serif font-bold text-gray-900 text-sm">{inv.guestName}</div>
                              <div className="text-[11px] text-gray-500 font-mono">{inv.inviteCode}</div>
                            </td>
                            <td className="py-3.5 px-4">
                              {inv.inviteType === 'CARD' ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                                  <Printer className="w-3 h-3 text-amber-700" /> {t('coupleDashboard.invites.modeCard')}
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-900 text-[10px] font-bold">
                                  <Share2 className="w-3 h-3 text-blue-700" /> {t('coupleDashboard.invites.modeLink')}
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 font-bold text-gray-900">
                              {inv.maxGuests} {inv.maxGuests === 1 ? t('common.guest') : t('common.guests')}
                            </td>
                            <td className="py-3.5 px-4">
                              {inv.rsvpStatus === 'ATTENDING' ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600" /> {t('coupleDashboard.invites.attending')}
                                </span>
                              ) : inv.rsvpStatus === 'DECLINED' ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold text-[10px]">
                                  <XCircle className="w-3 h-3 text-rose-600" /> {t('coupleDashboard.invites.declined')}
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold text-[10px]">
                                  <Clock className="w-3 h-3 text-amber-600" /> {t('coupleDashboard.invites.pendingRsvp')}
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4">
                              {inv.isScanned ? (
                                <span className="text-emerald-700 font-bold text-[11px] flex items-center gap-1">
                                  <Check className="w-3.5 h-3.5 text-emerald-600" /> {t('coupleDashboard.invites.checkedIn')}
                                </span>
                              ) : (
                                <span className="text-gray-500 font-light text-[11px]">
                                  {t('coupleDashboard.invites.awaitingGate')}
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => setSelectedInviteForQr(inv)}
                                  className="px-3 py-1.5 rounded-lg bg-black hover:bg-gray-800 text-gold-400 text-xs font-bold flex items-center gap-1 shadow-sm transition-all border border-gold-500/30"
                                  title="View QR Pass"
                                >
                                  <QrCode className="w-3.5 h-3.5 text-gold-400" />
                                  <span>{t('coupleDashboard.invites.viewQr')}</span>
                                </button>

                                <button
                                  onClick={() => handleCopyLink(inv.inviteCode)}
                                  className="p-1.5 rounded-lg border border-gold-500/30 bg-white hover:bg-gray-50 text-gray-900 transition-colors"
                                  title="Copy Link"
                                >
                                  {copiedCode === inv.inviteCode ? (
                                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                                  ) : (
                                    <Copy className="w-3.5 h-3.5 text-gold-600" />
                                  )}
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 2: TECHNICAL STAFF ROLES (LIVE STREAMER & GATE SCANNER)
             ========================================================================= */}
          {activeTab === 'STAFF' && (
            <div className="space-y-6">
              {/* Form Card */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm">
                <div className="mb-6 pb-4 border-b border-gray-100">
                  <h2 className="font-serif font-bold text-lg sm:text-xl text-gray-900">
                    {t('coupleDashboard.staff.title')}
                  </h2>
                  <p className="text-xs text-gray-500 font-light mt-0.5">
                    {t('coupleDashboard.staff.subtitle')}
                  </p>
                </div>

                {staffSuccessMsg && (
                  <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span>{staffSuccessMsg}</span>
                  </div>
                )}

                <form onSubmit={handleAssignStaff} className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('coupleDashboard.staff.fullName')}
                    </label>
                    <input
                      type="text"
                      required
                      value={staffName}
                      onChange={(e) => setStaffName(e.target.value)}
                      placeholder="e.g. Abebe Media Operator"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('coupleDashboard.staff.email')}
                    </label>
                    <input
                      type="email"
                      required
                      value={staffEmail}
                      onChange={(e) => setStaffEmail(e.target.value)}
                      placeholder="streamer@sara-dawit.com"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('coupleDashboard.staff.password')}
                    </label>
                    <input
                      type="text"
                      required
                      value={staffPassword}
                      onChange={(e) => setStaffPassword(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('coupleDashboard.staff.role')}
                    </label>
                    <select
                      value={staffRole}
                      onChange={(e) => setStaffRole(e.target.value as any)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500 font-bold"
                    >
                      <option value="GATE_SCANNER">{t('coupleDashboard.staff.roleScanner')}</option>
                      <option value="LIVE_STREAMER">{t('coupleDashboard.staff.roleStreamer')}</option>
                    </select>
                  </div>

                  <div className="sm:col-span-4 flex justify-end pt-2">
                    <button
                      type="submit"
                      disabled={assigningStaff}
                      className="px-6 py-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-md transition-all flex items-center gap-2 border border-gold-500/40"
                    >
                      <UserCheck className="w-4 h-4 text-gold-400" />
                      <span>{assigningStaff ? t('common.loading') : t('coupleDashboard.staff.assignBtn')}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Staff Roster Card */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm">
                <h2 className="font-serif font-bold text-lg text-gray-900 mb-4">
                  {t('coupleDashboard.staff.activeCrew')} ({teamMembers.length})
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {teamMembers.map((member) => (
                    <div
                      key={member.id}
                      className="p-5 rounded-2xl border border-gold-500/20 bg-gray-50 flex items-center justify-between shadow-sm"
                    >
                      <div className="flex items-center gap-3.5">
                        <div className="w-12 h-12 rounded-2xl bg-black text-gold-400 flex items-center justify-center font-bold text-lg shadow-sm shrink-0 border border-gold-500/30">
                          {member.role === 'LIVE_STREAMER' ? <Video className="w-6 h-6 text-gold-400" /> : <ScanLine className="w-6 h-6 text-gold-400" />}
                        </div>
                        <div>
                          <div className="font-serif font-bold text-gray-900 text-sm">{member.fullName}</div>
                          <div className="text-xs text-gray-500 font-mono">{member.email}</div>
                          <div className="mt-1">
                            {member.role === 'LIVE_STREAMER' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-900 text-[10px] font-bold">
                                {t('coupleDashboard.staff.roleStreamer')}
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                                {t('coupleDashboard.staff.roleScanner')}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Link
                          href={member.role === 'LIVE_STREAMER' ? '/event/sara-and-dawit-2026' : '/scanner'}
                          target="_blank"
                          className="px-3 py-1.5 rounded-lg bg-white border border-gold-500/30 hover:bg-gray-50 text-gray-900 text-xs font-bold flex items-center gap-1 shadow-sm"
                        >
                          <span>{t('coupleDashboard.staff.openPortal')}</span>
                          <ExternalLink className="w-3 h-3 text-gold-600" />
                        </Link>

                        <button
                          onClick={() => handleDeleteStaff(member.id)}
                          className="p-2 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors"
                          title="Revoke Role"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 3: RECEIVED MEDIA & VAULT MODERATION
             ========================================================================= */}
          {activeTab === 'MEDIA' && (
            <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
                <div>
                  <h2 className="font-serif font-bold text-lg sm:text-xl text-gray-900">
                    {t('coupleDashboard.media.title')} ({mediaAssets.length})
                  </h2>
                  <p className="text-xs text-gray-500 font-light">
                    {t('coupleDashboard.media.subtitle')}
                  </p>
                </div>

                {/* Filter Tabs */}
                <div className="flex items-center gap-1.5 p-1 rounded-xl bg-gray-50 border border-gold-500/30 text-xs font-bold">
                  <button
                    onClick={() => setMediaFilterTab('ALL')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      mediaFilterTab === 'ALL'
                        ? 'bg-black text-gold-400 shadow-sm'
                        : 'text-gray-700 hover:text-gray-900'
                    }`}
                  >
                    {t('coupleDashboard.media.tabAll')} ({mediaAssets.length})
                  </button>
                  <button
                    onClick={() => setMediaFilterTab('APPROVED')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      mediaFilterTab === 'APPROVED'
                        ? 'bg-emerald-800 text-white shadow-sm'
                        : 'text-emerald-800 hover:bg-emerald-50'
                    }`}
                  >
                    {t('coupleDashboard.media.tabPosted')} ({mediaAssets.filter((m) => m.status === 'APPROVED').length})
                  </button>
                  <button
                    onClick={() => setMediaFilterTab('PENDING')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      mediaFilterTab === 'PENDING'
                        ? 'bg-amber-800 text-white shadow-sm'
                        : 'text-amber-800 hover:bg-amber-50'
                    }`}
                  >
                    {t('coupleDashboard.media.tabPending')} ({mediaAssets.filter((m) => m.status === 'PENDING').length})
                  </button>
                  <button
                    onClick={() => setMediaFilterTab('REJECTED')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      mediaFilterTab === 'REJECTED'
                        ? 'bg-rose-800 text-white shadow-sm'
                        : 'text-rose-800 hover:bg-rose-50'
                    }`}
                  >
                    {t('coupleDashboard.media.tabRejected')} ({mediaAssets.filter((m) => m.status === 'REJECTED').length})
                  </button>
                </div>
              </div>

              {filteredMedia.length === 0 ? (
                <div className="text-center py-12 text-gray-500 text-xs">
                  {t('coupleDashboard.media.empty')}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredMedia.map((asset) => (
                    <div
                      key={asset.id}
                      className="p-4 rounded-2xl border border-gold-500/20 bg-gray-50 flex flex-col justify-between shadow-sm"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-bold text-gray-500 uppercase">
                            {new Date(asset.createdAt).toLocaleDateString()}
                          </span>
                          {asset.status === 'APPROVED' ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                              {t('coupleDashboard.media.tabPosted')}
                            </span>
                          ) : asset.status === 'REJECTED' ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-900 text-[10px] font-bold">
                              {t('coupleDashboard.media.tabRejected')}
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                              {t('coupleDashboard.media.tabPending')}
                            </span>
                          )}
                        </div>

                        {/* Player */}
                        <div className="h-44 rounded-xl overflow-hidden bg-black mb-3 flex items-center justify-center">
                          {asset.mediaType === 'VIDEO' || asset.cdnUrl.includes('.mp4') ? (
                            <video
                              src={asset.cdnUrl}
                              controls
                              playsInline
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <img
                              src={asset.cdnUrl}
                              alt={asset.caption}
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>

                        <div className="font-serif font-bold text-gray-900 text-sm">
                          {asset.uploaderName}
                        </div>
                        <p className="text-xs text-gray-500 font-light italic mt-1 line-clamp-2">
                          "{asset.caption}"
                        </p>
                      </div>

                      <div className="flex items-center gap-2 border-t border-gray-100 pt-3 mt-3">
                        {asset.status !== 'APPROVED' && (
                          <button
                            onClick={() => handleMediaStatus(asset.id, 'APPROVED')}
                            className="flex-1 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-1"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" /> {t('coupleDashboard.media.approve')}
                          </button>
                        )}

                        {asset.status !== 'REJECTED' && (
                          <button
                            onClick={() => handleMediaStatus(asset.id, 'REJECTED')}
                            className="flex-1 py-2 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-900 font-bold text-xs transition-all flex items-center justify-center gap-1"
                          >
                            <XCircle className="w-3.5 h-3.5" /> {t('coupleDashboard.media.reject')}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* =========================================================================
              TAB 4: WEDDING DAY BROADCAST CENTER
             ========================================================================= */}
          {activeTab === 'BROADCAST' && (
            <div className="max-w-3xl mx-auto p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-6">
              <div>
                <h2 className="font-serif font-bold text-xl text-gray-900">
                  {t('coupleDashboard.broadcast.title')}
                </h2>
                <p className="text-xs text-gray-500 font-light mt-0.5">
                  {t('coupleDashboard.broadcast.subtitle')}
                </p>
              </div>

              {broadcastSuccess && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span>{t('coupleDashboard.broadcast.successMsg')}</span>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-[11px] font-bold text-gray-900 mb-1">
                    {t('coupleDashboard.broadcast.label')}
                  </label>
                  <textarea
                    rows={4}
                    value={broadcastMessage}
                    onChange={(e) => setBroadcastMessage(e.target.value)}
                    className="w-full p-4 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 leading-relaxed focus:outline-none focus:ring-2 focus:ring-gold-500"
                  />
                </div>

                <div className="p-4 rounded-2xl bg-gray-50 border border-gold-500/20 text-xs">
                  <div className="text-[10px] text-gold-600 font-bold uppercase mb-1">{t('coupleDashboard.broadcast.previewTitle')}</div>
                  <div className="font-serif font-bold text-gray-900">📢 {t('publicEvent.hero.announcementFrom')} {brideName} & {groomName}:</div>
                  <p className="italic text-gray-600 mt-1">"{broadcastMessage}"</p>
                </div>

                <button
                  type="button"
                  onClick={handleSendBroadcast}
                  disabled={broadcasting}
                  className="w-full py-3.5 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 border border-gold-500/40"
                >
                  <Send className="w-4 h-4 text-gold-400" />
                  <span>{broadcasting ? t('coupleDashboard.broadcast.publishingBtn') : t('coupleDashboard.broadcast.publishBtn')}</span>
                </button>
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 5: POST-WEDDING THANK YOU CAPSULE
             ========================================================================= */}
          {activeTab === 'THANK_YOU' && (
            <div className="max-w-3xl mx-auto p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-6">
              <div>
                <h2 className="font-serif font-bold text-xl text-gray-900">
                  {t('coupleDashboard.thankYou.title')}
                </h2>
                <p className="text-xs text-gray-500 font-light mt-0.5">
                  {t('coupleDashboard.thankYou.subtitle')}
                </p>
              </div>

              {thankYouSent && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span>{t('coupleDashboard.thankYou.successMsg')}</span>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-[11px] font-bold text-gray-900 mb-1">
                    {t('coupleDashboard.thankYou.messageLabel')}
                  </label>
                  <textarea
                    rows={4}
                    value={thankYouMessage}
                    onChange={(e) => setThankYouMessage(e.target.value)}
                    className="w-full p-4 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 leading-relaxed focus:outline-none focus:ring-2 focus:ring-gold-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-900 mb-1">
                    {t('coupleDashboard.thankYou.photoLabel')}
                  </label>
                  <label className="border-2 border-dashed border-gold-500/30 hover:border-gold-500 rounded-2xl p-5 text-center cursor-pointer transition-all block bg-gray-50 group">
                    <div className="flex flex-col items-center justify-center gap-1.5">
                      <div className="w-10 h-10 rounded-xl bg-black text-gold-400 flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
                        <Upload className="w-5 h-5 text-gold-400" />
                      </div>
                      <div className="font-bold text-xs text-gray-900">
                        {thankYouImageFile ? `✓ Selected: ${thankYouImageFile.name}` : t('coupleDashboard.thankYou.photoPrompt')}
                      </div>
                      <p className="text-[10px] text-gray-500 font-light">
                        {t('coupleDashboard.setup.photoHelp')}
                      </p>
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleThankYouImageChange}
                      className="hidden"
                    />
                  </label>
                </div>

                {thankYouImageUrl && (
                  <div className="h-52 rounded-2xl overflow-hidden border border-gold-500/30 shadow-sm relative">
                    <img
                      src={thankYouImageUrl}
                      alt="Thank you portrait"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4 text-white">
                      <div className="text-xs">
                        <div className="font-serif font-bold text-sm">Thank You from {brideName} & {groomName}</div>
                        <p className="italic text-white/90 line-clamp-2 mt-0.5">"{thankYouMessage}"</p>
                      </div>
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleSendThankYou}
                  disabled={sendingThankYou}
                  className="w-full py-3.5 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 border border-gold-500/40"
                >
                  <Send className="w-4 h-4 text-gold-400" />
                  <span>{sendingThankYou ? t('coupleDashboard.thankYou.sendingBtn') : t('coupleDashboard.thankYou.sendBtn')}</span>
                </button>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* =========================================================================
          3. HIGH-RES QR MODAL (VIEW & PRINT)
         ========================================================================= */}
      <AnimatePresence>
        {selectedInviteForQr && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="w-full max-w-sm bg-white rounded-3xl p-6 sm:p-8 border-2 border-gold-500 text-center relative shadow-2xl">
              <button
                onClick={() => setSelectedInviteForQr(null)}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-900"
              >
                ✕
              </button>

              <div className="inline-flex items-center gap-1 px-3 py-0.5 rounded-full bg-black text-gold-400 text-[10px] font-bold uppercase mb-3 border border-gold-500/30">
                <Crown className="w-3 h-3 text-gold-400" />
                {selectedInviteForQr.inviteType === 'CARD' ? t('coupleDashboard.invites.modeCard') : t('coupleDashboard.invites.modeLink')}
              </div>

              <h3 className="font-serif font-bold text-xl text-gray-900">
                {selectedInviteForQr.guestName}
              </h3>
              <p className="text-xs text-gray-500 mb-4">
                {t('coupleDashboard.invites.thQuota')}: <strong className="text-gray-900 font-bold">{selectedInviteForQr.maxGuests} {selectedInviteForQr.maxGuests === 1 ? t('common.guest') : t('common.guests')}</strong>
              </p>

              {/* Scannable High-Res QR */}
              <div className="p-4 bg-gray-50 rounded-2xl border border-gold-500/20 inline-block shadow-sm mb-4">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(
                    `${typeof window !== 'undefined' ? window.location.origin : ''}/event/${event?.slug || 'sara-and-dawit-2026'}?code=${selectedInviteForQr.inviteCode}&guest=${encodeURIComponent(selectedInviteForQr.guestName)}`
                  )}`}
                  alt="Guest QR Code"
                  className="w-48 h-48 mx-auto"
                />
                <div className="font-mono text-[11px] font-bold text-gray-900 mt-2 tracking-wider">
                  {selectedInviteForQr.inviteCode}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(
                      `${window.location.origin}/event/${event?.slug || 'sara-and-dawit-2026'}?code=${selectedInviteForQr.inviteCode}&guest=${encodeURIComponent(selectedInviteForQr.guestName)}`
                    )}`;
                    link.download = `QR-${selectedInviteForQr.inviteCode}-${selectedInviteForQr.guestName.replace(/\s+/g, '_')}.png`;
                    link.click();
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 border border-gold-500/30"
                >
                  <Download className="w-3.5 h-3.5 text-gold-400" /> {t('publicEvent.qrPass.downloadPass')}
                </button>

                <button
                  onClick={() => window.print()}
                  className="p-2.5 rounded-xl bg-gray-50 hover:bg-gray-100 text-gray-900 border border-gold-500/30 shadow-sm"
                  title="Print Pass"
                >
                  <Printer className="w-4 h-4 text-gold-600" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
