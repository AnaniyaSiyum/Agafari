'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { 
  Heart, 
  ArrowLeft, 
  Sparkles, 
  Calendar, 
  MapPin, 
  Home, 
  Camera, 
  Clock, 
  Crown,
  Quote
} from 'lucide-react';
import { useTranslation, LanguageSwitcher } from '@/lib/i18n';

interface EventData {
  brideName: string;
  groomName: string;
  venueName: string;
  eventDate: string;
}

export default function CoupleHistoryPage({ params }: { params: { slug: string } }) {
  const { slug } = params;
  const { t } = useTranslation();
  const [event, setEvent] = useState<EventData | null>(null);

  useEffect(() => {
    async function loadEvent() {
      try {
        const res = await fetch(`/api/events/${slug}`);
        if (res.ok) {
          const data = await res.json();
          setEvent(data.event);
        }
      } catch (err) {
        console.error('Failed to load event for history page:', err);
      }
    }
    loadEvent();
  }, [slug]);

  const timelineEvents = [
    {
      year: '2021',
      title: 'A Chance Encounter in Addis Ababa',
      subtitle: 'First Meeting at Tomoca Coffee',
      description: 'Sara and Dawit first crossed paths on a sunny afternoon in Addis Ababa. What began as a simple coffee conversation turned into hours of deep dialogue about faith, family traditions, and their shared vision for the future.',
      image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=800&auto=format&fit=crop',
      badge: 'THE BEGINNING',
    },
    {
      year: '2022',
      title: 'Sunset Walks & Deepening Connection',
      subtitle: 'Mount Entoto & Unity Park Memories',
      description: 'Over weekend walks amidst the aromatic eucalyptus trees of Entoto, their bond blossomed into a deep romantic commitment. They discovered a shared passion for community service, music, and travel.',
      image: 'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?q=80&w=800&auto=format&fit=crop',
      badge: 'GROWING IN LOVE',
    },
    {
      year: '2025',
      title: 'Under the Stars at Lake Tana',
      subtitle: 'The Candlelight Proposal',
      description: 'During a weekend retreat near Lake Tana, Dawit surprised Sara with a romantic candlelight dinner by the water. With violin serenade playing in the background, he got down on one knee and proposed. Sara joyfully answered "YES!"',
      image: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=800&auto=format&fit=crop',
      badge: 'THE PROPOSAL',
    },
    {
      year: '2026',
      title: 'Our Royal Wedding Covenant',
      subtitle: 'August 15, 2026 • Sheraton Addis Luxury Ballroom',
      description: 'Surrounded by our beloved family, respected elders, and cherished friends, we unite our lives in holy matrimony and celebrate the beginning of our forever journey together.',
      image: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=800&auto=format&fit=crop',
      badge: 'FOREVER TOGETHER',
    },
  ];

  return (
    <div className="min-h-screen w-full bg-stone-950 text-white font-sans relative pb-32 overflow-x-hidden">
      
      {/* Background Glow Accents */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl pointer-events-none z-0" />
      <div className="fixed bottom-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none z-0" />

      {/* 1. TOP HEADER NAVBAR */}
      <header className="sticky top-0 z-40 bg-black/80 backdrop-blur-xl border-b border-gold-500/30 px-4 sm:px-8 py-3 flex items-center justify-between shadow-2xl">
        <div className="flex items-center gap-3">
          <Link
            href={`/event/${slug}`}
            className="w-9 h-9 rounded-full bg-black/60 border border-gold-500/40 text-gold-400 flex items-center justify-center hover:scale-105 transition-transform"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <Link href={`/event/${slug}`}>
            <img
              src="/branding/artboard-15.png"
              alt="Agafari Logo"
              className="h-9 w-auto object-contain"
            />
          </Link>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-500/20 border border-gold-500/40 text-gold-300 text-xs font-bold">
            <Crown className="w-3.5 h-3.5 text-gold-400" />
            <span>Love Story & Journey</span>
          </div>
          <LanguageSwitcher />
        </div>
      </header>

      {/* 2. HERO SECTION */}
      <main className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 pt-8 space-y-12">
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold-500/20 border border-gold-500/50 text-gold-300 text-xs font-extrabold tracking-widest uppercase shadow-md">
            <Heart className="w-3.5 h-3.5 fill-gold-400 text-gold-400" />
            <span>SARA & DAWIT'S LOVE STORY</span>
          </div>
          <h1 className="font-script text-5xl sm:text-7xl font-bold text-white drop-shadow-2xl py-1">
            How Our Journey Began
          </h1>
          <p className="text-gray-300 font-serif italic text-sm sm:text-base max-w-xl mx-auto leading-relaxed drop-shadow">
            "Two lives, two hearts, joined together by faith, grace, and an everlasting love story."
          </p>
          <div className="w-36 h-1 bg-gradient-to-r from-transparent via-gold-500 to-transparent mx-auto rounded-full" />
        </div>

        {/* 3. TIMELINE CARDS */}
        <div className="relative border-l-2 border-gold-500/40 ml-4 sm:ml-32 space-y-12 pl-6 sm:pl-10">
          {timelineEvents.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative group"
            >
              {/* Timeline Gold Node */}
              <div className="absolute -left-[31px] sm:-left-[47px] top-1.5 w-6 h-6 rounded-full bg-stone-950 border-4 border-gold-500 group-hover:scale-125 transition-transform shadow-gold" />

              {/* Year Badge (Desktop Side Indicator) */}
              <div className="hidden sm:block absolute -left-36 top-1 text-right font-mono font-extrabold text-gold-400 text-base">
                {item.year}
              </div>

              {/* Content Card */}
              <div className="p-6 sm:p-8 rounded-3xl bg-black/80 backdrop-blur-xl border border-gold-500/40 hover:border-gold-500 transition-all shadow-2xl space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gold-500/20 pb-3">
                  <span className="px-3 py-1 rounded-full bg-gold-500/20 text-gold-300 font-bold text-[10px] uppercase tracking-widest border border-gold-500/30">
                    {item.badge}
                  </span>
                  <span className="sm:hidden font-mono text-xs font-bold text-gold-400">
                    {item.year}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                  <div className="md:col-span-2 space-y-2 text-left">
                    <h3 className="font-serif font-extrabold text-xl sm:text-2xl text-white">
                      {item.title}
                    </h3>
                    <div className="text-xs text-gold-400 font-semibold uppercase tracking-wider">
                      {item.subtitle}
                    </div>
                    <p className="text-gray-300 text-xs sm:text-sm leading-relaxed font-light">
                      {item.description}
                    </p>
                  </div>

                  <div className="overflow-hidden rounded-2xl border border-gold-500/30 shadow-md">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-48 md:h-36 object-cover hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* 4. LOVE QUOTE CARD */}
        <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-amber-950/80 via-black/80 to-amber-950/80 backdrop-blur-xl border-2 border-gold-500/50 text-center space-y-3 shadow-2xl">
          <Quote className="w-10 h-10 text-gold-400 mx-auto opacity-60" />
          <p className="font-serif italic text-base sm:text-xl text-gold-200 max-w-2xl mx-auto">
            "Love is patient, love is kind. It always protects, always trusts, always hopes, always perseveres."
          </p>
          <div className="text-xs text-gold-400 font-bold uppercase tracking-widest pt-2">
            1 Corinthians 13:4-7
          </div>
        </div>
      </main>

      {/* 5. FLOATING BOTTOM NAVIGATION DOCK (4 CHOICES: HOME, HISTORY, PROGRAM, GALLERY) */}
      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-black/90 backdrop-blur-xl border-2 border-gold-500/60 rounded-full px-3 py-2 shadow-2xl flex items-center gap-2 sm:gap-3 text-xs font-bold">
        {/* 1) Home */}
        <Link
          href={`/event/${slug}`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Home className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">Home</span>
        </Link>

        {/* 2) Couple History (ACTIVE) */}
        <Link
          href={`/event/${slug}/history`}
          className="px-4 py-2 rounded-full bg-gold-500 text-black shadow-gold scale-105 transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Heart className="w-4 h-4 shrink-0 fill-black" />
          <span className="hidden sm:inline">Couple History</span>
          <span className="sm:hidden">History</span>
        </Link>

        {/* 3) Lists of Programs */}
        <Link
          href={`/event/${slug}/program`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Calendar className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">Programs</span>
        </Link>

        {/* 4) Gallery */}
        <Link
          href={`/event/${slug}/gallery`}
          className="px-3.5 py-2 rounded-full text-gold-300 hover:bg-gold-500/20 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Camera className="w-4 h-4 shrink-0" />
          <span>Gallery</span>
        </Link>
      </div>

    </div>
  );
}
