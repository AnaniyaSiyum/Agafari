'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Crown, 
  Calendar, 
  Users, 
  Video, 
  Plus, 
  ExternalLink, 
  CheckCircle2, 
  XCircle, 
  ShieldCheck, 
  LogOut, 
  Search, 
  Check, 
  X, 
  Sparkles, 
  Layers, 
  KeyRound, 
  FileText, 
  UserPlus, 
  Briefcase, 
  QrCode, 
  Eye, 
  EyeOff, 
  Lock, 
  ChevronRight, 
  Activity, 
  DollarSign, 
  Film, 
  ScanLine, 
  Share2, 
  Radio, 
  Trash2, 
  Clock, 
  Archive, 
  MapPin, 
  Send, 
  Copy, 
  Menu, 
  AlertCircle, 
  Settings, 
  RefreshCw,
  Building2
} from 'lucide-react';
import { useTranslation, LanguageSwitcher } from '@/lib/i18n';

interface EventCredential {
  fullName: string;
  email: string;
  temporaryPassword?: string;
  role: string;
}

interface EventData {
  id: string;
  slug: string;
  title: string;
  brideName: string;
  groomName: string;
  eventDate: string;
  startTime?: string;
  venueName: string;
  venueAddress?: string;
  dressCode?: string;
  coverImageUrl?: string;
  status: 'DRAFT' | 'COMING_SOON' | 'LIVE' | 'COMPLETED' | 'ARCHIVED';
  adminApprovalStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  coupleCredentials?: {
    email: string;
    temporaryPassword?: string;
  };
  youtubeVideoId?: string;
  isLive?: boolean;
  credentials?: {
    couple: EventCredential;
    organizer: EventCredential;
    streamer: EventCredential;
    scanner: EventCredential;
  };
  stats?: {
    totalInvites: number;
    totalWishes: number;
    totalMedia: number;
  };
}

interface UserData {
  id: string;
  email: string;
  fullName: string;
  role: 'SYSTEM_ADMIN' | 'EVENT_ORGANIZER' | 'BRIDE_GROOM' | 'LIVE_STREAMER' | 'GATE_SCANNER' | 'GUEST';
  eventId?: string | null;
  temporaryPassword?: string;
}

interface MediaAssetData {
  id: string;
  eventId: string;
  uploaderName: string;
  mediaType: 'VIDEO' | 'IMAGE';
  cdnUrl: string;
  caption: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

export default function SystemAdminDashboardPage() {
  const { t } = useTranslation();
  // Navigation: 'APPROVALS' | 'EVENTS' | 'ORGANIZERS' | 'USERS' | 'MEDIA'
  const [activeTab, setActiveTab] = useState<'APPROVALS' | 'EVENTS' | 'ORGANIZERS' | 'USERS' | 'MEDIA'>('APPROVALS');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const [events, setEvents] = useState<EventData[]>([]);
  const [users, setUsers] = useState<UserData[]>([]);
  const [mediaAssets, setMediaAssets] = useState<MediaAssetData[]>([]);
  const [loading, setLoading] = useState(true);

  // Selected Drill-Down Event & Impersonation Hub
  const [selectedEvent, setSelectedEvent] = useState<EventData | null>(null);

  // Event Fleet Directory Filters
  const [fleetFilter, setFleetFilter] = useState<'ALL' | 'ACTIVE' | 'ARCHIVE' | 'PENDING'>('ALL');
  const [searchFleetQuery, setSearchFleetQuery] = useState('');

  // User Management State
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<string>('ALL');
  const [resettingUser, setResettingUser] = useState<UserData | null>(null);
  const [newPasswordVal, setNewPasswordVal] = useState('');

  // New Event Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newBrideName, setNewBrideName] = useState('');
  const [newGroomName, setNewGroomName] = useState('');
  const [newEventDate, setNewEventDate] = useState('2026-11-25');
  const [newVenueName, setNewVenueName] = useState('');
  const [newVenueAddress, setNewVenueAddress] = useState('Addis Ababa, Ethiopia');
  const [newCoupleEmail, setNewCoupleEmail] = useState('');
  const [creatingEvent, setCreatingEvent] = useState(false);

  // New Organizer Agency Onboarding State
  const [orgAgencyName, setOrgAgencyName] = useState('');
  const [orgContactEmail, setOrgContactEmail] = useState('');
  const [orgPassword, setOrgPassword] = useState('org123');
  const [creatingOrg, setCreatingOrg] = useState(false);
  const [orgSuccessMsg, setOrgSuccessMsg] = useState('');

  // Password Visibility & Copy Feedback
  const [copiedKey, setCopiedKey] = useState<string>('');
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});

  useEffect(() => {
    fetchAdminData();
  }, []);

  async function fetchAdminData() {
    try {
      const [eventsRes, usersRes, mediaRes] = await Promise.all([
        fetch('/api/admin/events'),
        fetch('/api/admin/users'),
        fetch('/api/organizer/media'),
      ]);

      if (eventsRes.ok) {
        const eventsData = await eventsRes.json();
        const loadedEvents: EventData[] = eventsData.events || [];
        setEvents(loadedEvents);
        if (loadedEvents.length > 0) {
          setSelectedEvent(loadedEvents[0]);
        }
      }

      if (usersRes.ok) {
        const usersData = await usersRes.json();
        setUsers(usersData.users || []);
      }

      if (mediaRes.ok) {
        const mediaData = await mediaRes.json();
        setMediaAssets(mediaData.mediaAssets || []);
      }
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  }

  // 1-Click Approve Organizer Wedding Request (Module 1)
  const handleApproveEventRequest = async (eventId: string) => {
    try {
      const res = await fetch('/api/admin/events', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId, adminApprovalStatus: 'APPROVED', status: 'COMING_SOON' }),
      });

      if (res.ok) {
        setEvents((prev) =>
          prev.map((e) => (e.id === eventId ? { ...e, adminApprovalStatus: 'APPROVED', status: 'COMING_SOON' } : e))
        );
        if (selectedEvent && selectedEvent.id === eventId) {
          setSelectedEvent((prev) => prev ? { ...prev, adminApprovalStatus: 'APPROVED', status: 'COMING_SOON' } : null);
        }
      }
    } catch (err) {
      console.error('Failed to approve event:', err);
    }
  };

  // 1-Click Reject Organizer Wedding Request
  const handleRejectEventRequest = async (eventId: string) => {
    if (!confirm('Reject this wedding licensing request?')) return;
    try {
      const res = await fetch('/api/admin/events', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId, adminApprovalStatus: 'REJECTED' }),
      });

      if (res.ok) {
        setEvents((prev) =>
          prev.map((e) => (e.id === eventId ? { ...e, adminApprovalStatus: 'REJECTED' } : e))
        );
      }
    } catch (err) {
      console.error('Failed to reject event:', err);
    }
  };

  // Toggle Live Broadcast Stream State
  const handleToggleLiveStream = async (eventId: string, currentIsLive: boolean) => {
    const nextIsLive = !currentIsLive;
    try {
      const res = await fetch('/api/admin/events', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId, isLive: nextIsLive, status: nextIsLive ? 'LIVE' : 'COMING_SOON' }),
      });

      if (res.ok) {
        setEvents((prev) =>
          prev.map((e) => (e.id === eventId ? { ...e, isLive: nextIsLive, status: nextIsLive ? 'LIVE' : 'COMING_SOON' } : e))
        );
        if (selectedEvent && selectedEvent.id === eventId) {
          setSelectedEvent((prev) => prev ? { ...prev, isLive: nextIsLive, status: nextIsLive ? 'LIVE' : 'COMING_SOON' } : null);
        }
      }
    } catch (err) {
      console.error('Failed to toggle live stream:', err);
    }
  };

  // Direct Admin Creation of a Wedding
  const handleCreateWeddingEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBrideName || !newGroomName || !newVenueName || !newCoupleEmail) return;

    setCreatingEvent(true);
    const cleanSlug = `${newBrideName.toLowerCase().replace(/[^a-z0-9]/g, '')}-and-${newGroomName.toLowerCase().replace(/[^a-z0-9]/g, '')}-${new Date(newEventDate).getFullYear()}`;

    try {
      const res = await fetch('/api/admin/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: `${newBrideName} & ${newGroomName}'s Royal Wedding`,
          slug: cleanSlug,
          brideName: newBrideName,
          groomName: newGroomName,
          eventDate: newEventDate,
          venueName: newVenueName,
          venueAddress: newVenueAddress,
          coupleEmail: newCoupleEmail,
        }),
      });

      const data = await res.json();
      if (res.ok && data.event) {
        setEvents((prev) => [data.event, ...prev]);
        setSelectedEvent(data.event);
        setShowCreateModal(false);
        setNewBrideName('');
        setNewGroomName('');
        setNewVenueName('');
        setNewCoupleEmail('');
      }
    } catch (err) {
      console.error('Failed to create wedding:', err);
    } finally {
      setCreatingEvent(false);
    }
  };

  // Create New Verified Event Organizer Agency
  const handleCreateOrganizerAgency = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!orgAgencyName || !orgContactEmail || !orgPassword) return;

    setCreatingOrg(true);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: orgAgencyName,
          email: orgContactEmail,
          password: orgPassword,
          role: 'EVENT_ORGANIZER',
        }),
      });

      const data = await res.json();
      if (res.ok && data.user) {
        setUsers((prev) => [data.user, ...prev]);
        setOrgSuccessMsg(`Agency "${orgAgencyName}" onboarded successfully!`);
        setOrgAgencyName('');
        setOrgContactEmail('');
        setTimeout(() => setOrgSuccessMsg(''), 5000);
      }
    } catch (err) {
      console.error('Failed to onboard organizer:', err);
    } finally {
      setCreatingOrg(false);
    }
  };

  // Password Reset Handler
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resettingUser || !newPasswordVal) return;

    try {
      const res = await fetch('/api/admin/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: resettingUser.id, newPassword: newPasswordVal }),
      });

      if (res.ok) {
        setUsers((prev) =>
          prev.map((u) => (u.id === resettingUser.id ? { ...u, temporaryPassword: newPasswordVal } : u))
        );
        setResettingUser(null);
        setNewPasswordVal('');
      }
    } catch (err) {
      console.error('Failed to reset password:', err);
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(''), 3000);
  };

  const toggleShowPassword = (key: string) => {
    setShowPasswords((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Metric Computations
  const pendingApprovals = events.filter((e) => e.adminApprovalStatus === 'PENDING');
  const activeHosting = events.filter((e) => e.status !== 'COMPLETED' && e.status !== 'ARCHIVED' && e.adminApprovalStatus === 'APPROVED');
  const hostedArchives = events.filter((e) => e.status === 'COMPLETED' || e.status === 'ARCHIVED');
  const organizerUsers = users.filter((u) => u.role === 'EVENT_ORGANIZER');

  // Filtered Fleet
  const filteredEvents = events.filter((evt) => {
    const matchesSearch = evt.title.toLowerCase().includes(searchFleetQuery.toLowerCase()) ||
                          evt.venueName.toLowerCase().includes(searchFleetQuery.toLowerCase()) ||
                          evt.brideName.toLowerCase().includes(searchFleetQuery.toLowerCase()) ||
                          evt.groomName.toLowerCase().includes(searchFleetQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (fleetFilter === 'ALL') return true;
    if (fleetFilter === 'ACTIVE') return evt.status !== 'COMPLETED' && evt.status !== 'ARCHIVED' && evt.adminApprovalStatus === 'APPROVED';
    if (fleetFilter === 'ARCHIVE') return evt.status === 'COMPLETED' || evt.status === 'ARCHIVED';
    if (fleetFilter === 'PENDING') return evt.adminApprovalStatus === 'PENDING';
    return true;
  });

  // Filtered Users
  const filteredUsers = users.filter((u) => {
    const matchesSearch = u.fullName.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
                          u.email.toLowerCase().includes(userSearchQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (userRoleFilter === 'ALL') return true;
    return u.role === userRoleFilter;
  });

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white text-gray-900 flex font-sans selection:bg-gold-500 selection:text-black">
      
      {/* =========================================================================
          1. SYSTEM ADMIN EXECUTIVE SIDEBAR
         ========================================================================= */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-72 bg-gray-950 text-white flex flex-col justify-between border-r border-gold-500/30 transition-transform duration-300 ease-in-out
        md:translate-x-0 ${mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div>
          {/* Brand Header */}
          <div className="p-6 border-b border-gold-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src="/branding/artboard-13.png"
                  alt="Agafari (አጋፋሪ) Logo"
                  className="h-10 w-auto object-contain"
                />
                <div>
                  <h2 className="font-serif font-bold text-base text-gold-400 tracking-wide">
                    {t('adminDashboard.brand')}
                  </h2>
                  <span className="text-[10px] text-gold-500/80 font-semibold uppercase tracking-widest block">
                    {t('adminDashboard.subtitle')}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setMobileSidebarOpen(false)}
                className="md:hidden p-1 text-white/70 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="mt-4 grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2.5 rounded-xl bg-black/20 border border-white/5">
                <div className="text-amber-300 font-bold text-base">{pendingApprovals.length}</div>
                <div className="text-white/70 text-[10px]">{t('adminDashboard.kpiPending')}</div>
              </div>
              <div className="p-2.5 rounded-xl bg-black/20 border border-white/5">
                <div className="text-emerald-400 font-bold text-base">{activeHosting.length}</div>
                <div className="text-white/70 text-[10px]">{t('adminDashboard.kpiActive')}</div>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="p-4 space-y-1.5 text-xs font-semibold">
            
            {/* 1. Licensing & Approvals */}
            <button
              onClick={() => { setActiveTab('APPROVALS'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'APPROVALS'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4 text-gold-400" />
                <span>{t('adminDashboard.tabs.approvals')}</span>
              </div>
              {pendingApprovals.length > 0 ? (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400 text-amber-950 font-bold animate-pulse">
                  {pendingApprovals.length}
                </span>
              ) : (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                  0
                </span>
              )}
            </button>

            {/* 2. Global Weddings Fleet & Role Command */}
            <button
              onClick={() => { setActiveTab('EVENTS'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'EVENTS'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Layers className="w-4 h-4 text-gold-400" />
                <span>{t('adminDashboard.tabs.events')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {events.length}
              </span>
            </button>

            {/* 3. Event Organizing Agencies */}
            <button
              onClick={() => { setActiveTab('ORGANIZERS'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'ORGANIZERS'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Building2 className="w-4 h-4 text-gold-400" />
                <span>{t('adminDashboard.tabs.organizers')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {organizerUsers.length}
              </span>
            </button>

            {/* 4. Platform Users & RBAC */}
            <button
              onClick={() => { setActiveTab('USERS'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'USERS'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Users className="w-4 h-4 text-gold-400" />
                <span>{t('adminDashboard.tabs.users')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {users.length}
              </span>
            </button>

            {/* 5. Global Media Vault Moderation */}
            <button
              onClick={() => { setActiveTab('MEDIA'); setMobileSidebarOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                activeTab === 'MEDIA'
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-black font-bold shadow-md'
                  : 'text-white/80 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Film className="w-4 h-4 text-gold-400" />
                <span>{t('adminDashboard.tabs.media')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gold-300 font-bold">
                {mediaAssets.length}
              </span>
            </button>
          </nav>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 space-y-2">
          <Link
            href="/admin/login"
            className="w-full py-2.5 px-3 rounded-xl hover:bg-rose-950/40 text-rose-300 text-xs font-medium flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>{t('nav.signOut')}</span>
          </Link>
        </div>
      </aside>

      {/* Mobile Drawer Backdrop */}
      {mobileSidebarOpen && (
        <div
          onClick={() => setMobileSidebarOpen(false)}
          className="md:hidden fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
        />
      )}

      {/* =========================================================================
          2. MAIN EXECUTIVE WORKSPACE
         ========================================================================= */}
      <div className="flex-1 md:pl-72 flex flex-col min-w-0">
        
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-gold-500/30 px-6 py-4 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="md:hidden p-2 rounded-xl bg-gray-50 border border-gold-500/30 text-gray-900"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              <div className="text-[11px] text-gold-600 font-semibold uppercase tracking-wider">
                {t('adminDashboard.header.tag')}
              </div>
              <h1 className="font-serif font-bold text-lg sm:text-xl text-gray-900">
                {activeTab === 'APPROVALS' && t('adminDashboard.approvals.title')}
                {activeTab === 'EVENTS' && t('adminDashboard.fleet.title')}
                {activeTab === 'ORGANIZERS' && t('adminDashboard.agencies.title')}
                {activeTab === 'USERS' && t('adminDashboard.users.title')}
                {activeTab === 'MEDIA' && t('coupleDashboard.media.title')}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 ml-auto">
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-4 py-2 rounded-xl bg-black hover:bg-gray-800 text-gold-400 text-xs font-bold shadow-md transition-all flex items-center gap-1.5 border border-gold-500/40"
            >
              <Plus className="w-3.5 h-3.5 text-gold-400" />
              <span className="hidden sm:inline">{t('adminDashboard.header.createBtn')}</span>
            </button>

            <LanguageSwitcher />
          </div>
        </header>

        {/* Workspace Main Area */}
        <main className="p-6 max-w-7xl w-full mx-auto space-y-6">
          
          {/* =========================================================================
              TAB 1: LICENSING & APPROVALS PIPELINE
             ========================================================================= */}
          {activeTab === 'APPROVALS' && (
            <div className="space-y-6">
              
              {/* Header Box */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
                  <div>
                    <h2 className="font-serif font-bold text-xl text-gray-900 flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-gold-500" />
                      {t('adminDashboard.approvals.title')} ({pendingApprovals.length})
                    </h2>
                    <p className="text-xs text-gray-500 font-light mt-0.5">
                      {t('adminDashboard.approvals.subtitle')}
                    </p>
                  </div>

                  <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-700" />
                    {pendingApprovals.length} Awaiting Verification
                  </span>
                </div>

                {pendingApprovals.length === 0 ? (
                  <div className="text-center py-12 text-gray-500 text-xs">
                    🎉 All wedding onboarding requests have been reviewed and approved!
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    {pendingApprovals.map((evt) => (
                      <div
                        key={evt.id}
                        className="p-5 rounded-2xl border-[1.5px] border-amber-300 bg-amber-50/40 flex flex-col justify-between space-y-4 shadow-sm"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-200 text-amber-950 text-[10px] font-bold">
                              🟡 Pending Review
                            </span>
                            <span className="text-[11px] font-mono text-gray-500 font-bold">
                              {new Date(evt.eventDate).toLocaleDateString()}
                            </span>
                          </div>

                          <h3 className="font-serif font-bold text-base text-gray-900">
                            {evt.brideName} & {evt.groomName}
                          </h3>
                          <div className="text-xs text-gray-500 flex items-center gap-1.5 mt-1">
                            <MapPin className="w-3.5 h-3.5 text-gold-500" />
                            <span>{evt.venueName}</span>
                          </div>

                          <div className="mt-3 p-3 rounded-xl bg-white border border-amber-200 text-xs space-y-1">
                            <div className="flex justify-between">
                              <span className="text-gray-500 text-[11px]">Couple Email:</span>
                              <span className="font-mono font-bold text-gray-900">
                                {evt.coupleCredentials?.email || `couple@${evt.slug}.com`}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500 text-[11px]">Proposed Slug:</span>
                              <span className="font-mono text-gray-900 text-[11px]">/event/{evt.slug}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 pt-2 border-t border-amber-200">
                          <button
                            onClick={() => handleApproveEventRequest(evt.id)}
                            className="flex-1 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>{t('adminDashboard.approvals.approveBtn')}</span>
                          </button>

                          <button
                            onClick={() => handleRejectEventRequest(evt.id)}
                            className="py-2.5 px-3 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-900 text-xs font-bold transition-colors"
                            title="Reject Request"
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Approved & Active Licenses Table */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-4">
                <h3 className="font-serif font-bold text-lg text-gray-900">
                  {t('adminDashboard.approvals.approvedTableTitle')} ({events.filter((e) => e.adminApprovalStatus === 'APPROVED').length})
                </h3>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-gray-100 text-[10px] text-gray-500 font-bold uppercase tracking-wider bg-gray-50">
                        <th className="py-3 px-4 rounded-l-xl">Wedding Instance</th>
                        <th className="py-3 px-4">Couple Credentials</th>
                        <th className="py-3 px-4">License Status</th>
                        <th className="py-3 px-4">Live Broadcast</th>
                        <th className="py-3 px-4 text-right rounded-r-xl">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {events.filter((e) => e.adminApprovalStatus === 'APPROVED').map((evt) => (
                        <tr key={evt.id} className="hover:bg-gray-50/80 transition-colors">
                          <td className="py-3.5 px-4">
                            <div className="font-serif font-bold text-gray-900">{evt.title}</div>
                            <div className="text-[11px] text-gray-500">{evt.venueName} • {new Date(evt.eventDate).toLocaleDateString()}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-mono font-bold text-gray-900">
                              {evt.credentials?.couple.email || evt.coupleCredentials?.email || `couple@${evt.slug}.com`}
                            </div>
                            <div className="text-[10px] text-gray-500 font-mono">
                              Pass: {evt.credentials?.couple.temporaryPassword || evt.coupleCredentials?.temporaryPassword || 'couple123'}
                            </div>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                              <CheckCircle2 className="w-3 h-3 text-emerald-700" /> Active License
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            {evt.isLive ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-900 text-[10px] font-bold animate-pulse">
                                <Radio className="w-3 h-3 text-rose-700" /> LIVE NOW
                              </span>
                            ) : (
                              <span className="text-gray-500 text-[11px]">Offline</span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <button
                              onClick={() => {
                                setSelectedEvent(evt);
                                setActiveTab('EVENTS');
                              }}
                              className="px-3 py-1.5 rounded-lg bg-black hover:bg-gray-800 text-gold-400 text-xs font-bold shadow-sm border border-gold-500/30"
                            >
                              {t('adminDashboard.approvals.openCommand')}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* =========================================================================
              TAB 2: GLOBAL WEDDINGS FLEET & 1-CLICK ROLE COMMAND (PILLAR 2)
             ========================================================================= */}
          {activeTab === 'EVENTS' && (
            <div className="space-y-6">
              
              {/* Filter Pills & Search */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-gold-500/30 shadow-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setFleetFilter('ALL')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      fleetFilter === 'ALL'
                        ? 'bg-black text-gold-400 shadow-sm'
                        : 'bg-gray-50 text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    {t('organizerDashboard.fleet.all')} ({events.length})
                  </button>

                  <button
                    onClick={() => setFleetFilter('ACTIVE')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      fleetFilter === 'ACTIVE'
                        ? 'bg-emerald-800 text-white shadow-sm'
                        : 'bg-gray-50 text-emerald-900 hover:bg-emerald-50'
                    }`}
                  >
                    {t('organizerDashboard.fleet.active')} ({activeHosting.length})
                  </button>

                  <button
                    onClick={() => setFleetFilter('ARCHIVE')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      fleetFilter === 'ARCHIVE'
                        ? 'bg-blue-800 text-white shadow-sm'
                        : 'bg-gray-50 text-blue-900 hover:bg-blue-50'
                    }`}
                  >
                    {t('organizerDashboard.fleet.archive')} ({hostedArchives.length})
                  </button>

                  <button
                    onClick={() => setFleetFilter('PENDING')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      fleetFilter === 'PENDING'
                        ? 'bg-amber-800 text-white shadow-sm'
                        : 'bg-gray-50 text-amber-900 hover:bg-amber-50'
                    }`}
                  >
                    {t('organizerDashboard.fleet.pending')} ({pendingApprovals.length})
                  </button>
                </div>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchFleetQuery}
                    onChange={(e) => setSearchFleetQuery(e.target.value)}
                    placeholder={t('organizerDashboard.fleet.searchPlaceholder')}
                    className="pl-8 pr-4 py-1.5 rounded-xl border border-gold-500/30 text-xs text-gray-900 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gold-500"
                  />
                </div>
              </div>

              {/* Fleet Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredEvents.map((evt) => {
                  const isSelected = selectedEvent?.id === evt.id;
                  const isArchive = evt.status === 'COMPLETED' || evt.status === 'ARCHIVED';

                  return (
                    <div
                      key={evt.id}
                      onClick={() => setSelectedEvent(evt)}
                      className={`
                        rounded-3xl p-5 border cursor-pointer transition-all flex flex-col justify-between relative overflow-hidden bg-white
                        ${isSelected ? 'border-gold-500 ring-2 ring-gold-500/50 shadow-lg' : 'border-gold-500/30 hover:border-gold-500 shadow-sm'}
                      `}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          {evt.adminApprovalStatus === 'PENDING' ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                              🟡 Pending Admin
                            </span>
                          ) : isArchive ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-800 text-[10px] font-bold">
                              📜 Hosted Archive
                            </span>
                          ) : evt.isLive ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-900 text-[10px] font-bold animate-pulse">
                              🔴 LIVE NOW
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                              🟢 Active Instance
                            </span>
                          )}

                          <span className="text-[10px] font-mono text-gray-500 font-bold">
                            {new Date(evt.eventDate).toLocaleDateString()}
                          </span>
                        </div>

                        <div className="h-32 rounded-2xl overflow-hidden mb-3 relative bg-black/10">
                          {evt.coverImageUrl ? (
                            <img
                              src={evt.coverImageUrl}
                              alt={evt.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-black text-gold-400 font-serif font-bold border border-gold-500/30">
                              {evt.brideName} & {evt.groomName}
                            </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3 text-white">
                            <div>
                              <div className="font-serif font-bold text-sm">{evt.brideName} & {evt.groomName}</div>
                              <div className="text-[10px] text-gold-400 flex items-center gap-1">
                                <MapPin className="w-3 h-3 text-gold-400" /> {evt.venueName}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-gray-100 flex items-center justify-between text-xs font-bold">
                        <span className="text-gray-900">
                          {isSelected ? '✓ Selected in Command Room' : 'Click to Inspect Roles'}
                        </span>
                        <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'rotate-90 text-gold-500' : 'text-gray-400'}`} />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* =========================================================================
                  MASTER EVENT COMMAND ROOM & MULTI-ROLE 1-CLICK LAUNCH
                 ========================================================================= */}
              {selectedEvent && (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-6 sm:p-8 rounded-3xl bg-white border-2 border-gold-500 shadow-xl space-y-6"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-100">
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black text-gold-400 text-xs font-bold mb-2 border border-gold-500/30">
                        <Crown className="w-3.5 h-3.5 text-gold-400" />
                        {t('adminDashboard.header.tag')}
                      </div>
                      <h2 className="font-serif font-bold text-2xl text-gray-900">
                        {selectedEvent.title}
                      </h2>
                      <div className="text-xs text-gray-500 flex flex-wrap items-center gap-3 mt-1">
                        <span>Date: <strong>{new Date(selectedEvent.eventDate).toLocaleDateString()}</strong></span>
                        <span>•</span>
                        <span>Venue: <strong>{selectedEvent.venueName}</strong></span>
                        <span>•</span>
                        <span>Slug: <strong>/event/{selectedEvent.slug}</strong></span>
                      </div>
                    </div>

                    {/* Stream Live Broadcaster Switcher */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleLiveStream(selectedEvent.id, !!selectedEvent.isLive)}
                        className={`px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1.5 ${
                          selectedEvent.isLive
                            ? 'bg-rose-800 hover:bg-rose-900 text-white animate-pulse'
                            : 'bg-black hover:bg-gray-800 text-gold-400 border border-gold-500/40'
                        }`}
                      >
                        <Radio className="w-4 h-4" />
                        <span>{selectedEvent.isLive ? t('adminDashboard.fleet.streamLive') : t('adminDashboard.fleet.startStream')}</span>
                      </button>
                    </div>
                  </div>

                  {/* 4 Multi-Role Impersonation Cards */}
                  <div>
                    <h3 className="font-serif font-bold text-base text-gray-900 mb-3 flex items-center gap-2">
                      <KeyRound className="w-4 h-4 text-gold-500" />
                      {t('adminDashboard.fleet.rolesTitle')}
                    </h3>
                    <p className="text-xs text-gray-500 mb-4">
                      Directly launch into any role portal for this wedding without entering passwords:
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      
                      {/* 1. Couple Dashboard */}
                      <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/50 flex flex-col justify-between space-y-3">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="w-8 h-8 rounded-lg bg-black text-gold-400 flex items-center justify-center font-bold border border-gold-500/30">
                              <Crown className="w-4 h-4 text-gold-400" />
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900">
                              👑 Couple
                            </span>
                          </div>
                          <div className="font-serif font-bold text-sm text-gray-900">
                            {selectedEvent.brideName} & {selectedEvent.groomName}
                          </div>
                          <div className="text-[11px] font-mono text-gray-500 truncate">
                            {selectedEvent.credentials?.couple.email || `couple@${selectedEvent.slug}.com`}
                          </div>
                        </div>

                        <Link
                          href="/couple/dashboard"
                          className="w-full py-2 px-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs flex items-center justify-center gap-1 shadow-sm border border-gold-500/30"
                        >
                          <span>Launch Couple Suite</span>
                          <ExternalLink className="w-3 h-3" />
                        </Link>
                      </div>

                      {/* 2. Event Organizer Dashboard */}
                      <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/50 flex flex-col justify-between space-y-3">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="w-8 h-8 rounded-lg bg-black text-gold-400 flex items-center justify-center font-bold border border-gold-500/30">
                              <Briefcase className="w-4 h-4 text-gold-400" />
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900">
                              👔 Organizer
                            </span>
                          </div>
                          <div className="font-serif font-bold text-sm text-gray-900">
                            {selectedEvent.credentials?.organizer.fullName || 'Yonas Planners'}
                          </div>
                          <div className="text-[11px] font-mono text-gray-500 truncate">
                            {selectedEvent.credentials?.organizer.email || `organizer@${selectedEvent.slug}.com`}
                          </div>
                        </div>

                        <Link
                          href="/organizer/dashboard"
                          className="w-full py-2 px-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs flex items-center justify-center gap-1 shadow-sm border border-gold-500/30"
                        >
                          <span>Launch Organizer Suite</span>
                          <ExternalLink className="w-3 h-3" />
                        </Link>
                      </div>

                      {/* 3. Live Streamer Studio */}
                      <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/50 flex flex-col justify-between space-y-3">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="w-8 h-8 rounded-lg bg-black text-gold-400 flex items-center justify-center font-bold border border-gold-500/30">
                              <Video className="w-4 h-4 text-gold-400" />
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-900">
                              📹 Streamer
                            </span>
                          </div>
                          <div className="font-serif font-bold text-sm text-gray-900">
                            {selectedEvent.credentials?.streamer.fullName || 'Stream Operator'}
                          </div>
                          <div className="text-[11px] font-mono text-gray-500 truncate">
                            {selectedEvent.credentials?.streamer.email || `streamer@${selectedEvent.slug}.com`}
                          </div>
                        </div>

                        <Link
                          href={`/event/${selectedEvent.slug}`}
                          target="_blank"
                          className="w-full py-2 px-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs flex items-center justify-center gap-1 shadow-sm border border-gold-500/30"
                        >
                          <span>Launch Live Studio</span>
                          <ExternalLink className="w-3 h-3" />
                        </Link>
                      </div>

                      {/* 4. Gate Scanner Terminal */}
                      <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/50 flex flex-col justify-between space-y-3">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="w-8 h-8 rounded-lg bg-black text-gold-400 flex items-center justify-center font-bold border border-gold-500/30">
                              <ScanLine className="w-4 h-4 text-gold-400" />
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-900">
                              📱 Scanner
                            </span>
                          </div>
                          <div className="font-serif font-bold text-sm text-gray-900">
                            {selectedEvent.credentials?.scanner.fullName || 'Gate Security Team'}
                          </div>
                          <div className="text-[11px] font-mono text-gray-500 truncate">
                            {selectedEvent.credentials?.scanner.email || `scanner@${selectedEvent.slug}.com`}
                          </div>
                        </div>

                        <Link
                          href="/scanner"
                          target="_blank"
                          className="w-full py-2 px-3 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs flex items-center justify-center gap-1 shadow-sm border border-gold-500/30"
                        >
                          <span>Launch Gate Terminal</span>
                          <ExternalLink className="w-3 h-3" />
                        </Link>
                      </div>

                    </div>
                  </div>

                  {/* Public Guest Hub Links */}
                  <div className="pt-4 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs text-gray-500">
                      Public celebration links for <strong>{selectedEvent.title}</strong>:
                    </div>

                    <div className="flex items-center gap-2">
                      <Link
                        href={`/event/${selectedEvent.slug}`}
                        target="_blank"
                        className="px-4 py-2 rounded-xl bg-white border border-gray-200 hover:bg-gray-50 text-gray-900 text-xs font-bold flex items-center gap-1.5 shadow-sm"
                      >
                        <Eye className="w-3.5 h-3.5 text-gold-500" />
                        <span>Public Celebration Hub</span>
                      </Link>

                      <Link
                        href={`/event/${selectedEvent.slug}/feed`}
                        target="_blank"
                        className="px-4 py-2 rounded-xl bg-white border border-gray-200 hover:bg-gray-50 text-gray-900 text-xs font-bold flex items-center gap-1.5 shadow-sm"
                      >
                        <Film className="w-3.5 h-3.5 text-gold-500" />
                        <span>TikTok Reel Feed</span>
                      </Link>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          )}

          {/* =========================================================================
              TAB 3: EVENT ORGANIZING AGENCY PARTNERS
             ========================================================================= */}
          {activeTab === 'ORGANIZERS' && (
            <div className="space-y-6">
              
              {/* Form to Onboard New Agency */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-gray-100">
                  <div>
                    <h2 className="font-serif font-bold text-xl text-gray-900 flex items-center gap-2">
                      <Building2 className="w-5 h-5 text-gold-500" />
                      {t('adminDashboard.agencies.title')}
                    </h2>
                    <p className="text-xs text-gray-500 font-light mt-0.5">
                      {t('adminDashboard.agencies.subtitle')}
                    </p>
                  </div>
                </div>

                {orgSuccessMsg && (
                  <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span>{orgSuccessMsg}</span>
                  </div>
                )}

                <form onSubmit={handleCreateOrganizerAgency} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('adminDashboard.agencies.agencyName')}
                    </label>
                    <input
                      type="text"
                      required
                      value={orgAgencyName}
                      onChange={(e) => setOrgAgencyName(e.target.value)}
                      placeholder="e.g. Addis Royal Wedding Planners"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('adminDashboard.agencies.contactEmail')}
                    </label>
                    <input
                      type="email"
                      required
                      value={orgContactEmail}
                      onChange={(e) => setOrgContactEmail(e.target.value)}
                      placeholder="agency@addisroyal.com"
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">
                      {t('adminDashboard.agencies.password')}
                    </label>
                    <input
                      type="text"
                      required
                      value={orgPassword}
                      onChange={(e) => setOrgPassword(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gold-500/30 bg-gray-50 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <div className="sm:col-span-3 flex justify-end pt-2">
                    <button
                      type="submit"
                      disabled={creatingOrg}
                      className="px-8 py-3.5 rounded-xl bg-black hover:bg-gray-800 text-gold-400 font-bold text-xs shadow-md transition-all flex items-center gap-2 border border-gold-500/40"
                    >
                      <UserPlus className="w-4 h-4 text-gold-400" />
                      <span>{creatingOrg ? t('common.loading') : t('adminDashboard.agencies.onboardBtn')}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Agency List */}
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-4">
                <h3 className="font-serif font-bold text-lg text-gray-900">
                  {t('adminDashboard.agencies.listTitle')} ({organizerUsers.length})
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {organizerUsers.map((org) => (
                    <div
                      key={org.id}
                      className="p-5 rounded-2xl border border-gray-200 bg-gray-50/50 flex items-center justify-between shadow-sm"
                    >
                      <div className="flex items-center gap-3.5">
                        <div className="w-12 h-12 rounded-2xl bg-black text-gold-400 flex items-center justify-center font-bold text-lg shadow-sm shrink-0 border border-gold-500/30">
                          <Briefcase className="w-6 h-6 text-gold-400" />
                        </div>
                        <div>
                          <div className="font-serif font-bold text-gray-900 text-sm">{org.fullName}</div>
                          <div className="text-xs text-gray-500 font-mono">{org.email}</div>
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-bold mt-1">
                            ✓ Certified Organizer
                          </span>
                        </div>
                      </div>

                      <Link
                        href="/organizer/dashboard"
                        className="px-3.5 py-2 rounded-xl bg-white border border-gray-200 hover:bg-gray-50 text-gray-900 text-xs font-bold flex items-center gap-1 shadow-sm"
                      >
                        <span>Open Portal</span>
                        <ExternalLink className="w-3 h-3" />
                      </Link>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* =========================================================================
              TAB 4: PLATFORM USERS & RBAC DIRECTORY
             ========================================================================= */}
          {activeTab === 'USERS' && (
            <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
                <div>
                  <h2 className="font-serif font-bold text-xl text-gray-900">
                    {t('adminDashboard.users.title')} ({users.length})
                  </h2>
                  <p className="text-xs text-gray-500 font-light mt-0.5">
                    {t('adminDashboard.users.subtitle')}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={userSearchQuery}
                      onChange={(e) => setUserSearchQuery(e.target.value)}
                      placeholder={t('common.search')}
                      className="pl-8 pr-3 py-1.5 rounded-xl border border-gold-500/30 text-xs text-gray-900 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>

                  <select
                    value={userRoleFilter}
                    onChange={(e) => setUserRoleFilter(e.target.value)}
                    className="px-3 py-1.5 rounded-xl border border-gold-500/30 text-xs text-gray-900 bg-white font-medium focus:outline-none focus:ring-2 focus:ring-gold-500"
                  >
                    <option value="ALL">All Roles</option>
                    <option value="SYSTEM_ADMIN">👑 System Admins</option>
                    <option value="EVENT_ORGANIZER">👔 Event Organizers</option>
                    <option value="BRIDE_GROOM">💍 Bride & Groom</option>
                    <option value="LIVE_STREAMER">📹 Live Streamers</option>
                    <option value="GATE_SCANNER">📱 Gate Scanners</option>
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-gray-100 text-[10px] text-gray-500 font-bold uppercase tracking-wider bg-gray-50">
                      <th className="py-3 px-4 rounded-l-xl">User / Organization</th>
                      <th className="py-3 px-4">Email</th>
                      <th className="py-3 px-4">System Role</th>
                      <th className="py-3 px-4">Active Password</th>
                      <th className="py-3 px-4 text-right rounded-r-xl">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-gray-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-serif font-bold text-gray-900">
                          {u.fullName}
                        </td>
                        <td className="py-3.5 px-4 font-mono text-gray-500">
                          {u.email}
                        </td>
                        <td className="py-3.5 px-4">
                          {u.role === 'SYSTEM_ADMIN' && (
                            <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-900 text-[10px] font-bold">
                              👑 Master Admin
                            </span>
                          )}
                          {u.role === 'EVENT_ORGANIZER' && (
                            <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-900 text-[10px] font-bold">
                              👔 Organizer
                            </span>
                          )}
                          {u.role === 'BRIDE_GROOM' && (
                            <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                              💍 Bride & Groom
                            </span>
                          )}
                          {u.role === 'LIVE_STREAMER' && (
                            <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-900 text-[10px] font-bold">
                              📹 Streamer
                            </span>
                          )}
                          {u.role === 'GATE_SCANNER' && (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                              📱 Gate Scanner
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 font-mono text-[11px] text-gray-900">
                          {u.temporaryPassword || '••••••••'}
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => {
                              setResettingUser(u);
                              setNewPasswordVal('newpass123');
                            }}
                            className="px-3 py-1 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-900 text-[11px] font-bold shadow-sm"
                          >
                            {t('adminDashboard.users.resetPassword')}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 5: GLOBAL CONTENT & MEDIA VAULT MODERATION
             ========================================================================= */}
          {activeTab === 'MEDIA' && (
            <div className="p-6 sm:p-8 rounded-3xl bg-white border border-gold-500/30 shadow-sm space-y-6">
              <div className="pb-4 border-b border-gray-100">
                <h2 className="font-serif font-bold text-xl text-gray-900">
                  {t('coupleDashboard.media.title')} ({mediaAssets.length})
                </h2>
                <p className="text-xs text-gray-500 font-light mt-0.5">
                  Platform-wide compliance and media moderation across all hosted weddings.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {mediaAssets.map((asset) => (
                  <div
                    key={asset.id}
                    className="p-4 rounded-2xl border border-gray-200 bg-gray-50/50 flex flex-col justify-between shadow-sm"
                  >
                    <div>
                      <div className="h-44 rounded-xl overflow-hidden bg-black mb-3 flex items-center justify-center">
                        {asset.mediaType === 'VIDEO' || asset.cdnUrl.includes('.mp4') ? (
                          <video
                            src={asset.cdnUrl}
                            controls
                            playsInline
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <img
                            src={asset.cdnUrl}
                            alt={asset.caption}
                            className="w-full h-full object-cover"
                          />
                        )}
                      </div>
                      <div className="font-serif font-bold text-sm text-gray-900">{asset.uploaderName}</div>
                      <p className="text-xs text-gray-500 italic mt-1 line-clamp-2">"{asset.caption}"</p>
                    </div>

                    <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs font-bold">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px]">
                        🟢 {t('coupleDashboard.media.tabPosted')}
                      </span>
                      <span className="text-[10px] text-gray-500">
                        {new Date(asset.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </main>
      </div>

      {/* =========================================================================
          MODAL 1: DIRECT CREATE & LICENSE WEDDING
         ========================================================================= */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="w-full max-w-lg bg-white rounded-3xl p-6 sm:p-8 border-2 border-gold-500 relative shadow-2xl space-y-4">
              <button
                onClick={() => setShowCreateModal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-900"
              >
                ✕
              </button>

              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-black text-gold-400 flex items-center justify-center border border-gold-500/30">
                  <Crown className="w-4 h-4 text-gold-400" />
                </div>
                <h3 className="font-serif font-bold text-xl text-gray-900">
                  {t('adminDashboard.header.createBtn')}
                </h3>
              </div>

              <form onSubmit={handleCreateWeddingEvent} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">{t('coupleDashboard.setup.brideName')}</label>
                    <input
                      type="text"
                      required
                      value={newBrideName}
                      onChange={(e) => setNewBrideName(e.target.value)}
                      placeholder="Sara Tadesse"
                      className="w-full px-3 py-2 rounded-xl border border-gold-500/30 bg-gray-50 text-xs focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">{t('coupleDashboard.setup.groomName')}</label>
                    <input
                      type="text"
                      required
                      value={newGroomName}
                      onChange={(e) => setNewGroomName(e.target.value)}
                      placeholder="Dawit Alemayehu"
                      className="w-full px-3 py-2 rounded-xl border border-gold-500/30 bg-gray-50 text-xs focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">{t('coupleDashboard.setup.eventDate')}</label>
                    <input
                      type="date"
                      required
                      value={newEventDate}
                      onChange={(e) => setNewEventDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-gold-500/30 bg-gray-50 text-xs focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-gray-900 mb-1">{t('organizerDashboard.credentials.email')}</label>
                    <input
                      type="email"
                      required
                      value={newCoupleEmail}
                      onChange={(e) => setNewCoupleEmail(e.target.value)}
                      placeholder="couple@sara-dawit.com"
                      className="w-full px-3 py-2 rounded-xl border border-gold-500/30 bg-gray-50 text-xs focus:outline-none focus:ring-2 focus:ring-gold-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-900 mb-1">{t('coupleDashboard.setup.venueName')}</label>
                  <input
                    type="text"
                    required
                    value={newVenueName}
                    onChange={(e) => setNewVenueName(e.target.value)}
                    placeholder="Sheraton Addis Luxury Ballroom"
                    className="w-full px-3 py-2 rounded-xl border border-gold-500/30 bg-gray-50 text-xs focus:outline-none focus:ring-2 focus:ring-gold-500"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="px-4 py-2 rounded-xl border border-gray-200 text-xs font-bold text-gray-700 hover:bg-gray-50"
                  >
                    {t('common.cancel')}
                  </button>
                  <button
                    type="submit"
                    disabled={creatingEvent}
                    className="px-6 py-2 rounded-xl bg-black hover:bg-gray-800 text-gold-400 text-xs font-bold shadow-md border border-gold-500/30"
                  >
                    {creatingEvent ? t('common.loading') : 'Create & License Wedding 💍'}
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          MODAL 2: RESET PASSWORD MODAL
         ========================================================================= */}
      <AnimatePresence>
        {resettingUser && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="w-full max-w-sm bg-white rounded-3xl p-6 border-2 border-gold-500 relative shadow-2xl space-y-4">
              <button
                onClick={() => setResettingUser(null)}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-900"
              >
                ✕
              </button>

              <h3 className="font-serif font-bold text-lg text-gray-900">
                {t('adminDashboard.users.resetPassword')} for {resettingUser.fullName}
              </h3>
              <p className="text-xs text-gray-500">
                Account: <strong>{resettingUser.email}</strong>
              </p>

              <form onSubmit={handleResetPassword} className="space-y-4">
                <div>
                  <label className="block text-[11px] font-bold text-gray-900 mb-1">
                    {t('adminDashboard.users.newPassword')}
                  </label>
                  <input
                    type="text"
                    required
                    value={newPasswordVal}
                    onChange={(e) => setNewPasswordVal(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-gold-500/30 text-xs focus:outline-none focus:ring-2 focus:ring-gold-500"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setResettingUser(null)}
                    className="px-4 py-2 rounded-xl border border-gray-200 text-xs font-bold text-gray-700 hover:bg-gray-50"
                  >
                    {t('common.cancel')}
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-black text-gold-400 text-xs font-bold shadow-md border border-gold-500/30"
                  >
                    {t('adminDashboard.users.updatePasswordBtn')}
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
