-- =============================================================================
-- AGAFARI (አጋፋሪ) WEDDING CELEBRATION PLATFORM
-- Standard PostgreSQL Relational Database Schema
-- Compatible with: PostgreSQL 14+, Supabase, Neon, AWS RDS, Railway
-- =============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================================
-- ENUM TYPES
-- =============================================================================

CREATE TYPE event_status_enum AS ENUM (
    'DRAFT',
    'COMING_SOON',]
    'LIVE',
    'COMPLETED',
    'ARCHIVED'
);

CREATE TYPE admin_approval_enum AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);

CREATE TYPE user_role_enum AS ENUM (
    'SYSTEM_ADMIN',
    'EVENT_ORGANIZER',
    'BRIDE_GROOM',
    'LIVE_STREAMER',
    'GATE_SCANNER',
    'GUEST'
);

CREATE TYPE rsvp_status_enum AS ENUM (
    'ATTENDING',
    'MAYBE',
    'DECLINED',
    'PENDING'
);

CREATE TYPE invitation_type_enum AS ENUM (
    'CARD',
    'LINK'
);

CREATE TYPE media_category_enum AS ENUM (
    'WISHES',
    'BTS',
    'LIVE'
);

CREATE TYPE media_type_enum AS ENUM (
    'VIDEO',
    'IMAGE'
);

-- =============================================================================
-- 1. WEDDING EVENTS TABLE
-- =============================================================================

CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug VARCHAR(120) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    bride_name VARCHAR(150) NOT NULL,
    groom_name VARCHAR(150) NOT NULL,
    event_date TIMESTAMPTZ NOT NULL,
    start_time VARCHAR(20) DEFAULT '14:00',
    second_event_date TIMESTAMPTZ,
    venue_name VARCHAR(255) NOT NULL,
    venue_address TEXT,
    venue_map_url TEXT,
    dress_code VARCHAR(255),
    welcome_message TEXT,
    cover_image_url TEXT,
    status event_status_enum DEFAULT 'COMING_SOON' NOT NULL,
    admin_approval_status admin_approval_enum DEFAULT 'APPROVED' NOT NULL,
    youtube_video_id VARCHAR(50) DEFAULT 'dQw4w9WgXcQ',
    is_live BOOLEAN DEFAULT FALSE NOT NULL,
    thank_you_message TEXT,
    thank_you_image_url TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_events_slug ON events(slug);
CREATE INDEX idx_events_status ON events(status);
CREATE INDEX idx_events_date ON events(event_date);

-- =============================================================================
-- 2. USER ACCOUNTS & RBAC TABLE
-- =============================================================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id UUID REFERENCES events(id) ON DELETE CASCADE,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    temporary_password VARCHAR(100),
    full_name VARCHAR(150) NOT NULL,
    role user_role_enum DEFAULT 'GUEST' NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_event_id ON users(event_id);

-- =============================================================================
-- 3. DIGITAL GUEST INVITATIONS & QR PASSES TABLE
-- =============================================================================

CREATE TABLE invitations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    invite_code VARCHAR(50) UNIQUE NOT NULL,
    invite_type invitation_type_enum DEFAULT 'CARD' NOT NULL,
    guest_name VARCHAR(150) NOT NULL,
    guest_phone VARCHAR(50),
    max_guests INT DEFAULT 1 NOT NULL,
    table_number VARCHAR(100),
    rsvp_status rsvp_status_enum DEFAULT 'PENDING' NOT NULL,
    attending_headcount INT DEFAULT 0 NOT NULL,
    is_scanned BOOLEAN DEFAULT FALSE NOT NULL,
    scanned_count INT DEFAULT 0 NOT NULL,
    scanned_at TIMESTAMPTZ,
    scanned_by UUID REFERENCES users(id) ON DELETE SET NULL,
    qr_code_url TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_invitations_code ON invitations(invite_code);
CREATE INDEX idx_invitations_event ON invitations(event_id);
CREATE INDEX idx_invitations_is_scanned ON invitations(is_scanned);

-- =============================================================================
-- 4. 1-CLICK INSTANT RSVPS TABLE
-- =============================================================================

CREATE TABLE rsvps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    invitation_id UUID REFERENCES invitations(id) ON DELETE SET NULL,
    invite_code VARCHAR(50),
    guest_name VARCHAR(150) NOT NULL,
    guest_phone VARCHAR(50),
    attendance_status rsvp_status_enum NOT NULL,
    attending_count INT DEFAULT 1 NOT NULL,
    song_recommendation TEXT,
    dietary_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_rsvps_event_id ON rsvps(event_id);
CREATE INDEX idx_rsvps_status ON rsvps(attendance_status);

-- =============================================================================
-- 5. GUEST WISHES & BLESSINGS WALL TABLE
-- =============================================================================

CREATE TABLE wishes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    sender_name VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    media_type media_type_enum DEFAULT 'IMAGE' NOT NULL,
    video_url TEXT,
    status admin_approval_enum DEFAULT 'APPROVED' NOT NULL,
    is_featured BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_wishes_event_id ON wishes(event_id);
CREATE INDEX idx_wishes_status ON wishes(status);

-- =============================================================================
-- 6. TIKTOK-STYLE VIDEO MEMORY REEL ASSETS TABLE
-- =============================================================================

CREATE TABLE media_assets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    uploader_name VARCHAR(150) NOT NULL,
    media_type media_type_enum DEFAULT 'VIDEO' NOT NULL,
    category media_category_enum DEFAULT 'WISHES' NOT NULL,
    cdn_url TEXT NOT NULL,
    thumbnail_url TEXT,
    caption TEXT,
    views_count INT DEFAULT 0 NOT NULL,
    likes_count INT DEFAULT 0 NOT NULL,
    status admin_approval_enum DEFAULT 'APPROVED' NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_media_event_id ON media_assets(event_id);
CREATE INDEX idx_media_category ON media_assets(category);
CREATE INDEX idx_media_status ON media_assets(status);

-- =============================================================================
-- 7. VIDEO REEL COMMENTS TABLE
-- =============================================================================

CREATE TABLE media_comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    media_id UUID NOT NULL REFERENCES media_assets(id) ON DELETE CASCADE,
    sender_name VARCHAR(150) NOT NULL,
    comment TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_comments_media_id ON media_comments(media_id);

-- =============================================================================
-- 8. MEZMUR & WEDDING MUSIC PLAYLIST TABLE
-- =============================================================================

CREATE TABLE mezmur_playlist (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    artist VARCHAR(150) NOT NULL,
    category VARCHAR(50) DEFAULT 'MEZMUR' NOT NULL,
    order_index INT DEFAULT 0 NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_mezmur_event_id ON mezmur_playlist(event_id);

-- =============================================================================
-- AUTOMATIC TIMESTAMP TRIGGER
-- =============================================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE 'plpgsql';

CREATE TRIGGER trg_events_updated_at BEFORE UPDATE ON events FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER trg_invitations_updated_at BEFORE UPDATE ON invitations FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
