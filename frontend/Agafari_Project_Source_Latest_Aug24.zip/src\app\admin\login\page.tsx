'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Crown, Lock, Mail, ArrowRight, AlertCircle, ShieldCheck } from 'lucide-react';
import { useTranslation, LanguageSwitcher } from '@/lib/i18n';

export default function AdminLoginPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const [email, setEmail] = useState('admin@hamelmal.com');
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (res.ok && data.user?.role === 'SYSTEM_ADMIN') {
        router.push('/admin/dashboard');
      } else if (res.ok) {
        setError('Access denied. Only System Admins can access this master control portal.');
      } else {
        setError(data.error || t('auth.invalidCreds'));
      }
    } catch (err) {
      setError('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white text-gray-900 flex items-center justify-center p-4 sm:p-6 selection:bg-gold-500 selection:text-black relative font-sans">
      <div className="absolute top-6 right-6">
        <LanguageSwitcher />
      </div>

      <div className="max-w-md w-full glass-panel p-8 sm:p-10 rounded-3xl border-2 border-gold-500/40 shadow-xl bg-white">
        <div className="text-center mb-8">
          <img
            src="/branding/artboard-14.png"
            alt="Agafari (አጋፋሪ) Logo"
            className="h-14 w-auto mx-auto mb-4 object-contain"
          />
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900">
            {t('auth.adminTitle')}
          </h1>
          <p className="text-[10px] text-gold-600 font-semibold uppercase tracking-widest mt-1">
            {t('auth.adminSubtitle')}
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-gray-900 uppercase tracking-wider mb-1.5">
              {t('auth.emailLabel')}
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@hamelmal.com"
                className="w-full px-4 py-3 pl-11 rounded-xl border border-gold-500/30 bg-gray-50 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
              />
              <Mail className="w-4 h-4 text-gold-600 absolute left-4 top-3.5" />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-gray-900 uppercase tracking-wider mb-1.5">
              {t('auth.passwordLabel')}
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 pl-11 rounded-xl border border-gold-500/30 bg-gray-50 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-gold-500"
              />
              <Lock className="w-4 h-4 text-gold-600 absolute left-4 top-3.5" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-gold-500 hover:bg-gold-600 text-black font-extrabold text-xs shadow-gold transition-all flex items-center justify-center gap-2 mt-4 border border-gold-400/40 disabled:opacity-50"
          >
            {loading ? t('auth.signingIn') : t('auth.signInBtn')}
            <ArrowRight className="w-4 h-4 text-black" />
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-gray-100 text-center">
          <p className="text-[11px] text-gray-500 font-semibold mb-1">Pre-configured Admin Login:</p>
          <div className="text-[11px] font-mono text-gray-900 font-bold">
            admin@hamelmal.com / admin123
          </div>
        </div>
      </div>
    </div>
  );
}
