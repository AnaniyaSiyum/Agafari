export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { mockStore, MediaAssetData } from '@/lib/mockData';

// GET: Public endpoint to fetch approved TikTok memory feed items for an event
export async function GET(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const { slug } = params;
  const event = mockStore.events.find((e) => e.slug === slug);

  if (!event) {
    return NextResponse.json({ error: 'Event not found' }, { status: 404 });
  }

  // Ensure default media assets exist if list is empty
  let assets = mockStore.mediaAssets.filter((m) => m.eventId === event.id);

  if (assets.length === 0) {
    const defaultReels: MediaAssetData[] = [
      {
        id: `med-vid-${Date.now()}-1`,
        eventId: event.id,
        uploaderName: 'Bride Maid Team',
        mediaType: 'VIDEO',
        cdnUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-couple-walking-in-a-park-on-their-wedding-day-43185-large.mp4',
        thumbnailUrl: 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=600&auto=format&fit=crop',
        caption: 'Magical moment from the bridal photo session! ✨ #SaraAndDawit2026',
        viewsCount: 438,
        likesCount: 215,
        status: 'APPROVED',
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      },
      {
        id: `med-vid-${Date.now()}-2`,
        eventId: event.id,
        uploaderName: 'Best Man Robel',
        mediaType: 'VIDEO',
        cdnUrl: 'https://assets.mixkit.co/videos/preview/mixkit-bride-and-groom-smiling-and-holding-hands-43183-large.mp4',
        thumbnailUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=600&auto=format&fit=crop',
        caption: 'Traditional Eskista dance moments at the rehearsal! 💃🕺 #RoyalWedding',
        viewsCount: 680,
        likesCount: 342,
        status: 'APPROVED',
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
      },
    ];
    mockStore.mediaAssets.push(...defaultReels);
    assets = defaultReels;
  }

  const approved = assets.filter((m) => m.status === 'APPROVED');
  return NextResponse.json({
    mediaAssets: approved.length > 0 ? approved : assets,
  });
}

// POST: Public endpoint for guests to upload photo or short video memory
export async function POST(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const { slug } = params;
    const event = mockStore.events.find((e) => e.slug === slug);

    if (!event) {
      return NextResponse.json({ error: 'Event not found' }, { status: 404 });
    }

    const body = await req.json();
    const { uploaderName, caption, mediaType, cdnUrl } = body;

    if (!uploaderName || !caption) {
      return NextResponse.json(
        { error: 'Uploader name and caption are required.' },
        { status: 400 }
      );
    }

    const fallbackVideo = 'https://assets.mixkit.co/videos/preview/mixkit-young-couple-walking-in-a-park-on-their-wedding-day-43185-large.mp4';

    const newMedia: MediaAssetData = {
      id: `med-${Date.now()}`,
      eventId: event.id,
      uploaderName: uploaderName.trim(),
      mediaType: mediaType === 'VIDEO' ? 'VIDEO' : 'VIDEO',
      cdnUrl: cdnUrl || fallbackVideo,
      thumbnailUrl: 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=600&auto=format&fit=crop',
      caption: caption.trim(),
      viewsCount: 1,
      likesCount: 0,
      status: 'APPROVED', // Immediately approved so guest sees it live
      createdAt: new Date().toISOString(),
    };

    mockStore.mediaAssets.unshift(newMedia);

    return NextResponse.json(
      {
        success: true,
        message: 'Memory uploaded and published to the live feed!',
        mediaAsset: newMedia,
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to upload memory asset.' },
      { status: 500 }
    );
  }
}
