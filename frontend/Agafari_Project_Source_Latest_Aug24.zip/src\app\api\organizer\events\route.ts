export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { mockStore, EventData, UserRecord } from '@/lib/mockData';
import { hashPassword } from '@/lib/auth';

// GET: Fetch all weddings for the Event Organizer (with credentials and approval status)
export async function GET(req: NextRequest) {
  // Enrich events with their associated role credentials
  const enrichedEvents = mockStore.events.map((evt) => {
    const eventUsers = mockStore.users.filter((u) => u.eventId === evt.id);
    const coupleUser = eventUsers.find((u) => u.role === 'BRIDE_GROOM') || {
      fullName: `${evt.brideName} & ${evt.groomName}`,
      email: evt.coupleCredentials?.email || `couple@${evt.slug}.com`,
      temporaryPassword: evt.coupleCredentials?.temporaryPassword || 'couple123',
      role: 'BRIDE_GROOM',
    };
    const streamerUser = eventUsers.find((u) => u.role === 'LIVE_STREAMER') || {
      fullName: 'Assigned Streamer',
      email: `streamer@${evt.slug}.com`,
      temporaryPassword: 'stream123',
      role: 'LIVE_STREAMER',
    };
    const scannerUser = eventUsers.find((u) => u.role === 'GATE_SCANNER') || {
      fullName: 'Gate Scanner Team',
      email: `scanner@${evt.slug}.com`,
      temporaryPassword: 'scan123',
      role: 'GATE_SCANNER',
    };

    const totalInvites = mockStore.invitations.filter((i) => i.eventId === evt.id).length;
    const totalWishes = mockStore.wishes.filter((w) => w.eventId === evt.id).length;
    const totalMedia = mockStore.mediaAssets.filter((m) => m.eventId === evt.id).length;

    return {
      ...evt,
      adminApprovalStatus: evt.adminApprovalStatus || 'APPROVED',
      credentials: {
        couple: coupleUser,
        streamer: streamerUser,
        scanner: scannerUser,
      },
      stats: {
        totalInvites,
        totalWishes,
        totalMedia,
      },
    };
  });

  return NextResponse.json({ events: enrichedEvents });
}

// POST: Organizer requests creation of a new Wedding & Couple Credentials (Requires Admin Approval)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      brideName,
      groomName,
      eventDate,
      venueName,
      venueAddress,
      coupleEmail,
      packageTier,
      notes,
    } = body;

    if (!brideName || !groomName || !eventDate || !venueName || !coupleEmail) {
      return NextResponse.json(
        { error: 'Missing required wedding information (Bride, Groom, Date, Venue, Couple Email).' },
        { status: 400 }
      );
    }

    const cleanSlug = `${brideName.toLowerCase().replace(/[^a-z0-9]/g, '')}-and-${groomName.toLowerCase().replace(/[^a-z0-9]/g, '')}-${new Date(eventDate).getFullYear()}`;

    // Check if slug exists
    const existing = mockStore.events.find((e) => e.slug === cleanSlug);
    if (existing) {
      return NextResponse.json(
        { error: `A wedding event with slug '${cleanSlug}' already exists.` },
        { status: 400 }
      );
    }

    const tempPassword = `agafari${Math.floor(1000 + Math.random() * 9000)}`;

    const newEvent: EventData = {
      id: `evt-${cleanSlug}`,
      slug: cleanSlug,
      title: `${brideName.trim()} & ${groomName.trim()}'s Royal Wedding`,
      brideName: brideName.trim(),
      groomName: groomName.trim(),
      eventDate: new Date(eventDate).toISOString(),
      startTime: '14:00',
      venueName: venueName.trim(),
      venueAddress: venueAddress?.trim() || 'Addis Ababa, Ethiopia',
      venueMapUrl: `https://maps.google.com/?q=${encodeURIComponent(venueName)}`,
      dressCode: 'Traditional Habesha Kemis & Black Tie',
      welcomeMessage: `Welcome to the royal wedding celebration of ${brideName} and ${groomName}!`,
      coverImageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop',
      status: 'COMING_SOON',
      adminApprovalStatus: 'PENDING', // Awaiting Admin Approval
      coupleCredentials: {
        email: coupleEmail.trim().toLowerCase(),
        temporaryPassword: tempPassword,
      },
      isLive: false,
    };

    // Create Couple User Account
    const newCoupleUser: UserRecord = {
      id: `usr-couple-${Date.now()}`,
      eventId: newEvent.id,
      email: coupleEmail.trim().toLowerCase(),
      passwordHash: hashPassword(tempPassword),
      temporaryPassword: tempPassword,
      fullName: `${brideName.trim()} & ${groomName.trim()}`,
      role: 'BRIDE_GROOM',
    };

    mockStore.events.unshift(newEvent);
    mockStore.users.push(newCoupleUser);

    return NextResponse.json(
      {
        success: true,
        message: 'Wedding onboard request submitted for System Admin approval!',
        event: newEvent,
        credentials: {
          email: coupleEmail,
          temporaryPassword: tempPassword,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to process event creation request.' },
      { status: 500 }
    );
  }
}

// PATCH: Approve / Update Event Approval Status (Simulated Admin Approval for Organizer demo)
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { eventId, adminApprovalStatus } = body;

    const event = mockStore.events.find((e) => e.id === eventId);
    if (!event) {
      return NextResponse.json({ error: 'Event not found.' }, { status: 404 });
    }

    if (adminApprovalStatus) {
      event.adminApprovalStatus = adminApprovalStatus;
    }

    return NextResponse.json({
      success: true,
      message: `Event approval status updated to ${adminApprovalStatus}!`,
      event,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update approval status.' },
      { status: 500 }
    );
  }
}
